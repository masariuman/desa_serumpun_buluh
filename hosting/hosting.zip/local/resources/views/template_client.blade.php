﻿<!DOCTYPE html>
<html dir="ltr" xmlns="http://www.w3.org/1999/xhtml" xmlns:b="http://www.google.com/2005/gml/b" xmlns:data="http://www.google.com/2005/gml/data" xmlns:expr="http://www.google.com/2005/gml/expr" class=" js"><head>
<!--[if lt IE 9]> <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"> </script> <![endif]-->
<meta content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1" name="viewport">
<meta content="text/html;charset=UTF-8" http-equiv="Content-Type">
<meta content="IE=edge,chrome=1" http-equiv="X-UA-Compatible">
<meta content="text/html; charset=UTF-8" http-equiv="Content-Type">
<meta content="blogger" name="generator">
<link type="text/css" rel="stylesheet" href="http://cdn.embedly.com/css/social.2eb5062a.css">
<link href="{{url('icon/bambu.png')}}" rel="icon" type="image/x-icon">
<link href="http://tampanblog.blogspot.com/" rel="canonical">
<link rel="alternate" type="application/atom+xml" title="TAMPAN  DAN MENAWAN - Atom" href="http://tampanblog.blogspot.com/feeds/posts/default">
<link rel="alternate" type="application/rss+xml" title="TAMPAN  DAN MENAWAN - RSS" href="http://tampanblog.blogspot.com/feeds/posts/default?alt=rss">
<link rel="service.post" type="application/atom+xml" title="TAMPAN  DAN MENAWAN - Atom" href="https://www.blogger.com/feeds/8330366638304275318/posts/default">
<link rel="me" href="https://plus.google.com/102010048021703559872">
<link rel="openid.server" href="https://www.blogger.com/openid-server.g">
<link rel="openid.delegate" href="http://tampanblog.blogspot.com/">
<!--[if IE]><script type="text/javascript" src="https://www.blogger.com/static/v1/jsbin/4135384701-ieretrofit.js"></script>
	<![endif]-->
	<link href="https://plus.google.com/102010048021703559872" rel="publisher">
	<meta content="http://tampanblog.blogspot.com/" property="og:url">
	<meta content="TAMPAN  DAN MENAWAN" property="og:title">
	<meta content="" property="og:description">
	<!--[if IE]> <script> (function() { var html5 = ("abbr,article,aside,audio,canvas,datalist,details," + "figure,footer,header,hgroup,mark,menu,meter,nav,output," + "progress,section,time,video").split(','); for (var i = 0; i < html5.length; i++) { document.createElement(html5[i]); } try { document.execCommand('BackgroundImageCache', false, true); } catch(e) {} })(); </script> <![endif]-->
	<title>
		Desa Serumpun Buluh
	</title>
	<!-- Description and Keywords (start) -->
	<meta content="YOUR DESCRIPTION HERE" name="description">
	<meta content="YOUR KEYWORDS HERE" name="keywords">
	<!-- Description and Keywords (end) -->
	<meta content="TAMPAN  DAN MENAWAN" property="og:site_name">
	<meta content="http://tampanblog.blogspot.com/" name="twitter:domain">
	<meta content="" name="twitter:title">
	<meta content="summary" name="twitter:card">
	<meta content="" name="twitter:title">
	<!-- Social Media meta tag need customer customization -->
	<meta content="Facebook App ID here" property="fb:app_id">
	<meta content="Facebook Admin ID here" property="fb:admins">
	<meta content="@username" name="twitter:site">
	<meta content="@username" name="twitter:creator">
	<link href="http://fonts.googleapis.com/css?family=Fjalla+One" rel="stylesheet" type="text/css">
	<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css" rel="stylesheet">
	<link href="//fonts.googleapis.com/css?family=Oswald%3A400%2C300%2C700&amp;ver=3.8.4" id="kopa-default-heading-font-css" media="all" rel="stylesheet" type="text/css">
	<link href="http://fonts.googleapis.com/css?family=Raleway:300,400,500,600" rel="stylesheet" type="text/css">
	<link href="http://fonts.googleapis.com/css?family=Arimo%3A400%2C700%2C400italic%2C700italic%7CMontserrat%3A400%2C700%7CRoboto%3A400%2C700%7CRoboto+Condensed%3A400&amp;ver=1408323976" id="redux-google-fonts-css" media="all" rel="stylesheet" type="text/css">
	<link href="https://fonts.googleapis.com/css?family=Lora:400,700" rel="stylesheet" type="text/css">
	<link href="http://fonts.googleapis.com/css?family=Oswald%3A400%2C700%7CLato%3A400%2C400italic%2C700%7CPT+Serif%3A400italic&amp;subset" id="motive-fonts-css" media="all" rel="stylesheet" type="text/css">
	<link type="text/css" rel="stylesheet" href="https://www.blogger.com/static/v1/widgets/162936943-css_bundle_v2.css">
	<link type="text/css" rel="stylesheet" href="https://www.blogger.com/dyn-css/authorization.css?targetBlogID=8330366638304275318&amp;zx=9883e330-b7e2-4f58-92f2-5049cccd29cb">

    <!-- custom -->
    <link href="{{asset('assets/css/custom.css')}}" rel="stylesheet">

    <!-- Bootstrap -->
    <link href="{{asset('gantella/vendors/bootstrap/dist/css/bootstrap.min.css')}}" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="{{asset('gantella/vendors/font-awesome/css/font-awesome.min.css')}}" rel="stylesheet">
    <!-- NProgress -->
    <link href="{{asset('gantella/vendors/nprogress/nprogress.css')}}" rel="stylesheet">
    <!-- iCheck -->
    <link href="{{asset('gantella/vendors/iCheck/skins/flat/green.css')}}" rel="stylesheet">
    <!-- bootstrap-progressbar -->
    <link href="{{asset('gantella/vendors/bootstrap-progressbar/css/bootstrap-progressbar-3.3.4.min.css')}}" rel="stylesheet">
    <!-- JQVMap -->
    <link href="{{asset('gantella/vendors/jqvmap/dist/jqvmap.min.css')}}" rel="stylesheet"/>
    <!-- bootstrap-daterangepicker -->
    <link href="{{asset('gantella/vendors/bootstrap-daterangepicker/daterangepicker.css')}}" rel="stylesheet">
    <link href="{{asset('js/sweetalert.css')}}" rel="stylesheet">

    

	<style id="page-skin-1" type="text/css"><!--
/*
-----------------------------------------------
Blogger Template Style
Name:        Motive Mag
Author :     http://www.soratemplates.com
License:     Free Version
----------------------------------------------- */
/* Variable definitions
====================
<Variable name="maincolor" description="Main Color" type="color" default="#c32700"/>
*/
html,body,div,span,applet,object,iframe,h1,h2,h3,h4,h5,h6,p,blockquote,pre,a,abbr,acronym,address,big,cite,code,del,dfn,em,img,ins,kbd,q,s,samp,small,strike,strong,sub,sup,tt,var,b,u,i,center,dl,dt,dd,ol,ul,li,fieldset,form,label,legend,table,caption,tbody,tfoot,thead,tr,th,td,article,aside,canvas,details,embed,figure,figcaption,footer,header,hgroup,menu,nav,output,ruby,section,summary,time,mark,audio,video{margin:0;padding:0;border:0;font-size:100%;font:inherit;vertical-align:baseline;}
/* HTML5 display-role reset for older browsers */
article,aside,details,figcaption,figure,footer,header,hgroup,menu,nav,section{display:block;}body{line-height:1;display:block;}*{margin:0;padding:0;}html{display:block;}ol,ul{list-style:none;}blockquote,q{quotes:none;}blockquote:before,blockquote:after,q:before,q:after{content:&#39;&#39;;content:none;}table{border-collapse:collapse;border-spacing:0;}
/* FRAMEWORK */
a.quickedit img {width: 18px!important; height: 18px!important; padding: 0!important; border: 0!important;}
a.quickedit {background: transparent!important;}
.navbar,.post-feeds,.feed-links{display:none;
}

a.kategori:hover {
	color: red;
}
.table>tbody>tr>td, .table>tbody>tr>th, .table>tfoot>tr>td, .table>tfoot>tr>th, .table>thead>tr>td, .table>thead>tr>th {
	vertical-align: middle;
}
th.orgcenter{
	text-align: center;
}
.section,.widget{margin:0 0 0 0;padding:0 0 0 0;
}
strong,b{font-weight:bold;
}
cite,em,i{font-style:italic;
}
a:link{color:#383838;text-decoration:none;outline:none;transition:all 0.25s;-moz-transition:all 0.25s;-webkit-transition:all 0.25s;
}
a:visited{color:#333333;text-decoration:none;
}
a:hover{color:#c32700;text-decoration:none;
}
a img{border:none;border-width:0;outline:none;
}
abbr,acronym{
}
sup,sub{vertical-align:baseline;position:relative;top:-.4em;font-size:86%;
}
sub{top:.4em;}small{font-size:86%;
}
kbd{font-size:80%;border:1px solid #999;padding:2px 5px;border-bottom-width:2px;border-radius:3px;
}
mark{background-color:#ffce00;color:black;
}
p,blockquote,pre,table,figure,hr,form,ol,ul,dl{margin:1.5em 0;
}
hr{height:1px;border:none;background-color:#666;
}
/* heading */
h1,h2,h3,h4,h5,h6{font-weight:bold;line-height:normal;margin:0 0 0.6em;
}
h1{font-size:200%
}
h2{font-size:180%
}
h3{font-size:160%
}
h4{font-size:140%
}
h5{font-size:120%
}
h6{font-size:100%
}
/* list */
ol,ul,dl{margin:.5em 0em .5em 3em
}
ol{list-style:decimal outside
}
ul{list-style:disc outside
}
li{margin:.5em 0
}
dt{font-weight:bold
}
dd{margin:0 0 .5em 2em
}
/* form */
input,button,select,textarea{font:inherit;font-size:100%;line-height:normal;vertical-align:baseline;
}
textarea{display:block;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;
}
/* code blockquote */
pre,code{font-family:&quot;Courier New&quot;,Courier,Monospace;color:inherit;
}
pre{white-space:pre;word-wrap:normal;overflow:auto;
}
.post-body blockquote {
	background: url(https://lh6.googleusercontent.com/-6UyQr7E0nTU/UVRWwhvPScI/AAAAAAAAFUU/15cIvW74xwg/s50/quote.png) no-repeat scroll left 18px transparent;
	font-family: Monaco,Georgia,&quot;
	font-size: 100%;
	font-style: italic;
	line-height: 22px;
	margin: 20px 0 30px 20px;
	min-height: 60px;
	padding: 0 0 0 60px;
}
/* table */
.post-body table[border=&quot;1&quot;] th, .post-body table[border=&quot;1&quot;] td, .post-body table[border=&quot;1&quot;] caption{border:1px solid;padding:.2em .5em;text-align:left;vertical-align:top;
}
.post-body table.tr-caption-container {border:1px solid #e5e5e5;
}
.post-body th{font-weight:bold;
}
.post-body table[border=&quot;1&quot;] caption{border:none;font-style:italic;
}
.post-body table{
}
.post-body td, .post-body th{vertical-align:middle;text-align:left;font-size:13px;padding:3px 5px;border:2px solid #e5e5e5;
} 
.post-body2 td, .post-body2 th {
	vertical-align:top;text-align:left;font-size:13px;padding:3px 5px;border:1px solid #e5e5e5;
}
.post-body th{background:#f0f0f0;
}
.post-body table.tr-caption-container td {border:none;padding:8px;
}
.post-body table.tr-caption-container, .post-body table.tr-caption-container img, .post-body img {max-width:100%;height:auto;
}
.post-body td.tr-caption {color:#666;font-size:80%;padding:0px 8px 8px !important;
}
img {
	max-width:100%;
	height:auto;
	border:0;
}
table {
	max-width:100%;
}
.clear {
	clear:both;
}
.clear:after {
	visibility:hidden;
	display:block;
	font-size:0;
	content:" ";
	clear:both;
	height:0;
}
body#layout #mywrapper{
	width: 60%;
	float: left;
}
body#layout #post-wrapper {
	width: 100%;
	float: left;
}
body#layout div#main {
	width: 100%;
}
body#layout #header-wrapper {
	min-height: 0px 30px;
	margin-top: 70px;
}
body#layout div#category-one {
	width: 48%;
	float: left;
}
body#layout div#category-two {
	width: 48%;
	float: right;
}
body#layout .container {
	width: 725px;
	margin: 0 auto;
}
body#layout div#header-right {
	width: 70%;
}
body#layout  #bottombar .left {
	float: left;
	width: 30%;
}
body#layout  #bottombar .center {
	float: left;
	width: 30%;
}
body#layout  #bottombar .right {
	float: left;
	width: 30%;
}
body {
	background: #fff none repeat scroll top left;
	margin: 0 0 0 0;
	padding: 0 0 0 0;
	color: #575757;
	font: 16px/1.71429 Lora, Georgia, serif;
	text-align: left;
	background-image: url({{asset('client/bg2.jpg')}});
	background-repeat: no-repeat;
	background-attachment: fixed;
	background-position: center center;
	-webkit-background-size: cover;
	-moz-background-size: cover;
	-o-background-size: cover;
	background-size: cover;
}
/* outer-wrapper */
#outer-wrapper {
	overflow: hidden;
	background: #ffffff none repeat center top;
	background-size: auto;
	position: relative;
	box-shadow: 0 0 1px rgba(0,0,0,.4);
	max-width: 1200px;
	margin: 0px auto;
	padding: 0px 0px 00px;
}
/* NAVIGATION MENU */
.top-menu {
	font: normal normal 12px Arial, sans-serif;
	margin: 0 auto;
	height: 38px;
	border-bottom: 1px solid #e6e6e6;
	border-top: #c32700 2px solid;
	background: #151108;
	border-color: #444;
	color: #FFF;
	padding: 0 40px;
}
.menubar {
	list-style-type:none;
	margin:0 0 0 0;
	padding:0 0 0 0;
}
.menubar li {
	display:block;
	float:left;
	line-height:38px;
	margin:0 0 0 0;
	padding:0 0 0 0;
}
.menubar li a {
	color: #fff;
	display: block;
	padding: 0 12px;
	font-size: 12px;
	text-transform: uppercase;
	font-family: 'Oswald', sans-serif;
}
.menubar li a:hover {
	color:#ff5b4d;
}
/* HEADER WRAPPER mengatur tinggi header */
#header-wrapper {
	margin:0 auto;
	padding: 0px 40px;
	min-height: 100px;
}
.header {
	float:left;
	width:100%;
	max-width:400px;
	height: 130px;
	margin: 0px 0 0PX;
}
.header h1.title,.header p.title {
	font:normal bold 40px Fjalla One, Arial, Helvetica, sans-serif;
	margin:0 0 0 0;
	text-transform:uppercase;
}
.titlewrapper h1 {
	padding: 40px 0;
}
.header .description {
	color:#555555;
}
.header a {
	color:#333333;
}
.header a:hover {
	color:#999;
}
.header img {
	display:block;
	padding: 40px 0px;
}
.header-right { /* mengatur ads */
	float: right;
	padding: 0;
	margin: 15px 0px 0 0;
	width: 50%;
	max-width: 728px;
	max-height: 90px;
}
.header-right img {
	display:block;
}
#nav {
	font: normal bold 12px Arial, sans-serif;
	text-transform: uppercase;
	height: 50px;
	line-height: 50px;
	padding: 0 10px;
	background-color: #151108;
	padding: 0 40px;
}
.menubar2 {
	list-style: none;
	margin:0 0 0 0;
	*zoom: 1;
	float:left;
	width: 100%;
}
.menubar2:before,
.menubar2:after {
	content: " ";
	display: table;
}
.menubar2:after {
	clear: both;
}
.menubar2 ul {
	list-style: none;
	margin:0 0 0 0;
	width:12em;
}
.menubar2 a {
	display:block;
	padding:0 15px;
}
.menubar2 li {
	position: relative;
	margin:0 0;
	padding: 0 1px 0 0;
	border-color: #222222;
	border-image: none;
	border-width: 0 0 0 1px;
}
.menubar2 > li {
	float: left;
}
.menubar2 > li > a {
	display: block;
	height: 50px;
	text-decoration: none;
	color: #fff;
	text-transform: uppercase;
	font-size: 16px;
	letter-spacing: 2px;
	font-weight: 400;
	line-height: 50px;
	padding: 0 26px;
	font-family: Oswald, Impact, Arial, sans-serif;
}
/*nav#nav li:nth-child(2) :hover {
	background: #5db935;
}
nav#nav li:nth-child(3) :hover {
	background: #8635B9;
}
nav#nav li:nth-child(4) :hover {
	background: #3595B9;
}
nav#nav li:nth-child(5) :hover {
	background: #DE8501;
}
nav#nav li:nth-child(6) :hover {
	background: #0074D9;
}
nav#nav li:nth-child(7) :hover {
	background: #5db935;
}*/
li.desaaa {
	background: black;
}
li.desaaa:hover {
	background: #5db935;
}
a.active {
	background: #c32700;
}
/*body.home a.home, body.healthy a.healthy, body.blog a.blog, body.technology a.technology, body. {
background-color: green;
}*/
.menubar2 li ul {
	background:#c32700;
	display:block;
	position:absolute;
	left:0;
	z-index:10;
	visibility:hidden;
	opacity:0;
	-webkit-transition:all .25s ease-out;
	-moz-transition:all .25s ease-out;
	-ms-transition:all .25s ease-out;
	-o-transition:all .25s ease-out;
	transition:all .25s ease-out;
}
.menubar2 li li ul {
	left:100%;
	top:-1px;
}
.menubar2 > li.hover > ul {
	visibility:visible;
	opacity:10;
}
.menubar2 li li.hover ul {
	visibility:visible;
	opacity:10;
}
.menubar2 li li a {
	display: block;
	color: #fff;
	font-family: 'Droid Sans', sans-serif;
	position: relative;
	z-index:100;
	line-height:32px;
}
.menubar2 li li a:hover {
	color:#fff;
}
.menubar2 li li li a {
	color: #e0dfdf;
	font-family: 'Droid Sans', sans-serif;
	text-shadow: 0 1px 1px #4B4B4B;
	z-index:20;
}
i.fa.fa-home {
	font-size: 25px;
	padding: 12px 5px;
}
/* CONTENT WRAPPER */
#content-wrapper {
	margin: 0 auto;
	padding: 0px 40px;
	word-wrap:break-word;
}
div#featured-posts-section {
	max-height: 420px;
	overflow: hidden;
	margin-bottom: 20px;
}
.largebanner {
	background:#fff;
	border-right:1px solid #e5e5e5;
	border-bottom:1px solid #e5e5e5;
	border-left:1px solid #e5e5e5;
}
.largebanner .widget {
	padding:15px 14px;
	overflow:hidden;
}
.largebanner img, .largebanner iframe{
	display:block;
	max-width:100%;
	border:none;
	overflow:hidden;
}
/* POST WRAPPER */
#post-wrapper {
	background:transparent;
	float:left;
	width:740px;
	max-width:740px;
	margin:10px 0 10px;
}
.post-container {
	padding:0px 0px 0 0;
}
.breadcrumbs {font-size: 90%;height: 25px;margin-bottom: 10px;margin-top: 1px;overflow: hidden;padding: 5px;margin-left: -15px;}
.breadcrumbs > span {padding: 10px 5px 10px 10px;}
.breadcrumbs > span:last-child {background: none repeat scroll 0 0 transparent;color: #808080;}
.breadcrumbs a {color: #333333;}
.post {
	background:#ffffff;
	margin:0 0 15px;
	padding:15px 0;
}
.post-body {
	line-height:1.6em;
}
h2.post-title, h1.post-title {
	font-size: 21px;
	text-transform: uppercase;
	letter-spacing: 1.9px;
	line-height: 1.5;
	font-family: "Oswald", Impact, Arial, sans-serif;
	font-weight: 400;
}
h2.post-title a, h1.post-title a, h2.post-title, h1.post-title {
	color:#383838;
}
h2.post-title a:hover, h1.post-title a:hover {
	color:#c32700;
}
.img-thumbnail {
	background:#fbfbfb url(http://3.bp.blogspot.com/-ltyYh4ysBHI/U04MKlHc6pI/AAAAAAAADQo/PFxXaGZu9PQ/w200-h140-c/no-image.png) no-repeat center center;
	position:relative;
	float:left;
	width:300px;
	height:175px;
	margin:0 15px 0 0;
}
.img-thumbnail img {
	width:300px;
	height:175px;
}
span.rollover {
}
span.rollover:before {
	content:"";
	position: absolute;
	width:24px;
	height:24px;
	margin:-12px;
	top:50%;
	left:50%;
}
span.rollover:hover {
	opacity: .7;
	-o-transition:all 1s;
	-moz-transition:all 1s;
	-webkit-transition:all 1s;
}
.post-info {
	background: transparent;
	margin: 0 0 12px;
	color: #666666;
	font-size: 11px;
}
.post-info i {
	font-size: 12px;
	margin-right: 5px;
	line-height: 13px;
}
.post-info a {
	display: inline-block;
	color: #666666;
	font-family: Oswald;
	font-size: 11px;
	text-transform: uppercase;
	letter-spacing: 1.6px;
	color: #909090;
}
.author-info, .time-info, .comment-info, .label-info, .review-info {
	margin-right:12px;
	display:inline;
}
a.readmore {
	display:inline-block;
	margin:15px 0 0;
	background-color:#ffffff;
	border:1px solid #dddddd;
	padding:0px 10px;
	line-height:26px;
	color:#333333;
	font-size:11px;
	font-weight:bold;
	text-transform:uppercase;
}
a.readmore:hover  {
	border:1px solid #aaaaaa;
}
/* Page Navigation */
.pagenavi {
	clear: both;
	margin: -16px 0 10px;
	text-align: center;
	font-size: 14px;
	font-weight: bold;
	padding: 0px;
	text-transform: uppercase;
	border-bottom: 1px solid #ddd;
	border-top: 1px solid #ddd;
}
.pagenavi span,.pagenavi a {
	padding: 6px 20px 6px 15px;
	margin-right:3px;
	display:inline-block;
	color:$(readmore.color);
	float: left;
	background: none repeat scroll 0 0 transparent;
	border-right: 1px solid #DDDDDD;
	background-color:$(readmore.background.color);
	border: 1px solid $(readmore.border.color);
}
.pagenavi .current, .pagenavi .pages, .pagenavi a:hover {
	border: 1px solid $(readmore.hover.color);
}
.pagenavi .pages {
	display:none;
}
/* SIDEBAR WRAPPER */
#sidebar-wrapper {
	float: right;
	width: 35%;
	max-width: 335px;
	margin: 32px auto 0;
}
.sidebar h2, .panel h2 {
	font-family: 'Oswald', sans-serif;
	margin: 0 0 20px;
	position: relative;
	font-size: 22px;
	text-transform: uppercase;
	padding-left: 0;
	padding-top: 6px;
	font-size: 18px;
	font-weight: 400;
	font-family: Oswald, Impact, sans-serif;
	overflow: hidden;
}
#sidebar1 h2 span,#sidebar h2 span{
}
.sidebar h2 span {
	padding-bottom: 11px;
	background-color: #fff;
	padding: 0 10px;
}
#bottombar h2 span {
	bottom: -2px;
	padding: 6px;
}
.sidebar h2.title:before {
	content: " ";
	display: block;
	width: 1000px;
	position: absolute;
	top: 50%;
	border-top: 4px solid #161616;
}
.sidebar h2.title:after {
	content: " ";
	display: block;
	width: 1000px;
	position: absolute;
	top: 50%;
	border-top: 4px solid #161616;
}
.sidebar h2.title:before {    right: 100%;}
.sidebar h2.title:after {    left: 90%;}
.sidebar h2:after, .panel h2:after {
	content: " ";
	width:90px;
	height: 0px;
	position: absolute;
	left: 0;
	bottom: -2px;
}
.sidebar .widget {
	margin:0 0 15px;
}
.sidebar ul, .sidebar ol {
	list-style-type:none;
	margin:0 0 0 0;
	padding:0 0 0 0;
}
.sidebar li {
	margin:5px 0;
	padding:0 0 0 0;
}
/* Recent Post */
.recent-post-title {
	margin:0 0 25px;
	padding:0;
	position:relative;
}
.recent-post-title h2 {
	font-family: 'Oswald', sans-serif;
	font-size: 25px;
	text-align: center;
	margin: 10px 0 0px 0;
	font-weight: 400;
}
.social-count-plus {
	*zoom: 1
}
.social-count-plus:after {
	content: "";
	display: table;
	clear: both
}
.social-count-plus .clear {
	clear: both
}
.social-count-plus ul {
	list-style: none !important;
	border: none !important;
	margin: 0;
	padding: 0
}
.social-count-plus li {
	background: none !important;
	border: none !important;
	clear: none !important;
	float: left;
	list-style: none !important;
	margin: 0;
	padding: 0 0 20px;
	text-align: center;
	width: 60px
}
.social-count-plus .vertical li {
	*zoom: 1;
	display: block;
	float: none;
	padding-bottom: 10px;
	text-align: left;
	width: 100%
}
.social-count-plus .vertical li:after {
	content: "";
	display: table;
	clear: both
}
.social-count-plus span {
	display: block;
	padding: 0;
	margin: 0
}
.social-count-plus a {
	-webkit-transition: all 0.4s ease;
	-moz-transition: all 0.4s ease;
	-o-transition: all 0.4s ease;
	transition: all 0.4s ease;
	display: block;
	margin: 0 auto;
	padding: 0 !important;
	opacity: 1
}
.social-count-plus a:hover {
	opacity: 0.7
}
.social-count-plus .default a {
	background-color: transparent !important;
	background-repeat: no-repeat !important;
	height: 32px !important;
	width: 32px !important
}
.social-count-plus .circle a {
	height: 37px !important;
	width: 36px !important
}
.social-count-plus .flat a {
	height: 32px !important;
	width: 32px !important
}
.social-count-plus .vertical a {
	float: left
}
.social-count-plus .vertical .items {
	float: left;
	margin-left: 10px;
	text-align: left
}
.social-count-plus .count {
	display: block;
	font-size: 14px;
	font-weight: bold;
	line-height: 16px;
	margin: 5px 0 0;
	padding: 0
}
.social-count-plus .vertical .count {
	margin-top: 3px
}
.social-count-plus .label {
	line-height: 16px;
	font-size: 9px;
	font-weight: normal;
	text-transform: capitalize
}
.social-count-plus .default .count-twitter a {
	background-position: 0px 0 !important
}
.social-count-plus .circle .count-twitter a {
	background-position: 0px 0 !important
}
.social-count-plus .flat .count-twitter a {
	background-position: 0px 0 !important
}
.social-count-plus .default .count-facebook a {
	background-position: -32px 0 !important
}
.social-count-plus .circle .count-facebook a {
	background-position: -36px 0 !important
}
.social-count-plus .flat .count-facebook a {
	background-position: -32px 0 !important
}
.social-count-plus .default .count-youtube a {
	background-position: -64px 0 !important
}
.social-count-plus .circle .count-youtube a {
	background-position: -72px 0 !important
}
.social-count-plus .flat .count-youtube a {
	background-position: -64px 0 !important
}
.social-count-plus .default .count-googleplus a {
	background-position: -96px 0 !important
}
.social-count-plus .circle .count-googleplus a {
	background-position: -108px 0 !important
}
.social-count-plus .flat .count-googleplus a {
	background-position: -96px 0 !important
}
.social-count-plus .default .count-posts a {
	background-position: -128px 0 !important
}
.social-count-plus .circle .count-posts a {
	background-position: -144px 0 !important
}
.social-count-plus .flat .count-posts a {
	background-position: -128px 0 !important
}
.social-count-plus .default .count-comments a {
	background-position: -160px 0 !important
}
.social-count-plus .circle .count-comments a {
	background-position: -180px 0 !important
}
.social-count-plus .flat .count-comments a {
	background-position: -160px 0 !important
}
.social-count-plus .default .count-instagram a {
	background-position: -192px 0 !important
}
.social-count-plus .circle .count-instagram a {
	background-position: -216px 0 !important
}
.social-count-plus .flat .count-instagram a {
	background-position: -192px 0 !important
}
.social-count-plus .default .count-steam a {
	background-position: -224px 0 !important
}
.social-count-plus .circle .count-steam a {
	background-position: -252px 0 !important
}
.social-count-plus .flat .count-steam a {
	background-position: -224px 0 !important
}
.social-count-plus .default .count-soundcloud a {
	background-position: -256px 0 !important
}
.social-count-plus .circle .count-soundcloud a {
	background-position: -288px 0 !important
}
.social-count-plus .flat .count-soundcloud a {
	background-position: -256px 0 !important
}
.social-count-plus .flat a {
	background: transparent !important;
	display: inline-block;
	vertical-align: middle;
	width: 48px !important;
	height: 48px !important;
	position: relative !important;
	-webkit-transform: translate3d(0, 0, 0);
}
.social-count-plus span {
	display: block;
	padding: 0;
	margin: 0;
	color: #333333 !important;
	font-size: 18px;
	font-weight: normal;
	line-height: 2;
	letter-spacing: 1px;
	font-family: "Oswald", Impact, Arial, sans-serif;
}
.social-count-plus .flat .count-soundcloud a { color: #f80 !important; }
.social-count-plus .flat .count-soundcloud a:before { content: "\f1be"; }
.social-count-plus .flat .count-twitter a { color: #00abe3 !important; }
.social-count-plus .flat .count-twitter a:before { content: "\f099"; }
.social-count-plus .flat .count-facebook a { color: #004088 !important; }
.social-count-plus .flat .count-facebook a:before { content: "\f09a"; }
.social-count-plus .flat .count-youtube a { color: #cd332d !important; }
.social-count-plus .flat .count-youtube a:before { content: "\f167"; }
.social-count-plus .flat .count-googleplus a { color: #dd4b39 !important; }
.social-count-plus .flat .count-googleplus a:before { content: "\f0d5"; }
.social-count-plus .flat .count-instagram a { color: #3f729b !important; }
.social-count-plus .flat .count-instagram a:before { content: "\f16d"; }
.social-count-plus .flat .count-steam a { color: #333 !important; }
.social-count-plus .flat .count-steam a:before { content: "\f1b6"; }
.social-count-plus .flat li {
	width: 33% !important;
}
.social-count-plus .count {
	font-size: 18px;
	font-weight: normal;
	line-height: 2;
}
.social-count-plus .label {
	font-size: 12px;
	line-height: 2;
	text-transform: uppercase;
}
.social-count-plus .flat li a:before {
	font-family: FontAwesome;
	position: absolute;
	top: 50%;
	left: 0;
	width: 100%;
	margin-top: -21px;
	font-size: 28px;
	text-align: center;
}
#crosscol-wrapper .recent-post-title h2:before {
	content: " ";
	display: block;
	width: 1000px;
	position: absolute;
	top: 50%;
	border-top: 4px solid #161616;
}
#crosscol-wrapper .recent-post-title h2:after {
	content: " ";
	display: block;
	width: 1200px;
	position: absolute;
	top: 50%;
	border-top: 4px solid #161616;
}
#mywrapper .recent-post-title h2:before {
	content: " ";
	display: block;
	width: 1000px;
	position: absolute;
	top: 50%;
	border-top: 4px solid #161616;
}
#mywrapper .recent-post-title h2:after {
	content: " ";
	display: block;
	width: 1200px;
	position: absolute;
	top: 50%;
	border-top: 4px solid #161616;
}
.special-heading h2 {
	font-family: 'Oswald', sans-serif;
	font-size: 20px;
	margin: 6px 0 25px 0;
}
.recent-post-title h2 a {
	color:#474747;
	padding: 0 10px;
}
.stylebox {
	float:left;
	width:50%;
	margin:0 0;
}
.stylebox .widget {
	padding:0 15px 15px 0;
}
.stylebox .widget-content {
	background:#ffffff;
}
.stylebox ul {
	list-style-type:none;
	margin:0 0 0 0;
	padding:0 0 0 0;
}
.stylebox1 {
	float:left;
	width:98%;
	margin:0 0;
}
.stylebox1 .widget {
	padding:0 0px 15px 0;
}
.stylebox1 .widget-content {
	background:#ffffff;
}
.stylebox1  ul {
	list-style-type:none;
	margin:0 0 0 0;
	padding:0 0 0 0;
}
/* Recent Post */
ul.xpose_thumbs {
	margin:0 0 0 0;
}
ul.xpose_thumbs li {
	font-size:12px;
	min-height:68px;
	margin:0 0 8px;
	padding:0 0 8px;
	border-bottom:1px dotted #e5e5e5;
}
ul.xpose_thumbs .xpose_thumb {
	position:relative;
	background:#fbfbfb;
	margin:3px 0 10px 0;
	width:100%;
	height:50px;
	padding-bottom:46%;
	overflow:hidden;
}
ul.xpose_thumbs .xpose_thumb img {
	height:auto;
	width:100%;
}
ul.xpose_thumbs1 {
	margin:0 0 0 0;
	width:49%;
	float:left;
}
ul.xpose_thumbs1 li {
	font-size:12px;
	min-height:68px;
	margin:0 0 8px;
	padding:0 0 8px;
	border-bottom:1px dotted #e5e5e5;
}
ul.xpose_thumbs1 .xpose_thumb {
	position:relative;
	background:#fbfbfb;
	margin:3px 0 10px 0;
	width:100%;
	height:62px;
	padding-bottom:46%;
	overflow:hidden;
}
ul.xpose_thumbs1 .xpose_thumb img {
	height:auto;
	width:100%;
}
ul.xpose_thumbs2 {
	font-size:13px;
}
ul.xpose_thumbs2 li {
	padding:0 0;
	font-size:11px;
	margin: 0 0 8px;
	padding: 0 0 8px;
	border-bottom:1px dotted #e5e5e5;
}
ul.xpose_thumbs2 .xpose_thumb2 {
	background:#fbfbfb;
	float:left;
	margin:3px 8px 0 0;
	height:110px;
	width:110px;
}
ul.xpose_thumbs2 .xpose_thumb2 img {
	height:110px;
	width:110px;
}
span.xpose_title {
	display:block;
	margin:0 0 5px;
	line-height:1.4em;
	font-family: Roboto;
	line-height: 24px;
	letter-spacing: 0.5px;
	font-style: normal;
	font-size: 22px;
	font: 400 24px/26px 'Oswald', sans-serif;
	color: #434c51;
}
span.xpose_title2 {
	font-size:18px;
}
span.rp_summary {
	display:block;
	margin:6px 0 6px;
	color: #747474;
	font-family: Open Sans,sans-serif;
	font-size: 14px;
	font-weight: 400;
}
span.xpose_meta {
	background:transparent;
	display:block;
	font-size:12px;
	color:#aaa;
	margin-top: 17px;
}
span.xpose_meta a {
	color:#aaa !important;
	display:inline-block;
}
span.xpose_meta_date, span.xpose_meta_comment, span.xpose_meta_more  {
	display:inline-block;
	margin-right:8px;
}
span.xpose_meta_date:before {
	content: "\f017";
	font-family: FontAwesome;
	font-style: normal;
	font-weight: normal;
	text-decoration: inherit;
	padding-right:4px;
}
span.xpose_meta_comment:before  {
	content: "\f086";
	font-family: FontAwesome;
	font-style: normal;
	font-weight: normal;
	text-decoration: inherit;
	padding-right:4px;
}
span.xpose_meta_more:before {
	content: "\f0a9";
	font-family: FontAwesome;
	font-style: normal;
	font-weight: normal;
	text-decoration: inherit;
	padding-right:4px;
}
ul.xpose_thumbs2 li a:hover, ul.xpose_thumbs li a:hover {
	color:#c32700;
}
ul.xpose_thumbs22 {
	font-size:13px;
	width:49%;
	float:right;
}
ul.xpose_thumbs22 li {
	padding:0 0;
	font-size:11px;
	margin: 0 0 8px;
	padding: 0 0 8px;
	border-bottom:1px dotted #e5e5e5;
}
ul.xpose_thumbs22 .xpose_thumb2 {
	background:#fbfbfb;
	float:left;
	margin:3px 8px 0 0;
	height:110px;
	width:110px;
}
ul.xpose_thumbs22 .xpose_thumb2 img {
	height:110px;
	width:110px;
}
span.xpose_title {
	display:block;
	margin:0 0 5px;
	line-height:1.4em;
	font-family: Roboto;
	line-height: 24px;
	letter-spacing: 0.5px;
	font-style: normal;
	font-size: 22px;
	font: 400 24px/26px 'Oswald', sans-serif;
	color: #434c51;
}
span.xpose_title2 {
	font-size:18px;
}
span.rp_summary {
	display:block;
	margin:6px 0 0;
	color:#747474;
}
span.xpose_meta {
	background:transparent;
	display:block;
	font-size:12px;
	color:#aaa;
	margin-top: 17px;
}
span.xpose_meta a {
	color:#aaa !important;
	display:inline-block;
}
span.xpose_meta_date, span.xpose_meta_comment, span.xpose_meta_more  {
	display:inline-block;
	margin-right:8px;
}
span.xpose_meta_date:before {
	content: "\f017";
	font-family: FontAwesome;
	font-style: normal;
	font-weight: normal;
	text-decoration: inherit;
	padding-right:4px;
}
span.xpose_meta_comment:before  {
	content: "\f086";
	font-family: FontAwesome;
	font-style: normal;
	font-weight: normal;
	text-decoration: inherit;
	padding-right:4px;
}
span.xpose_meta_more:before {
	content: "\f0a9";
	font-family: FontAwesome;
	font-style: normal;
	font-weight: normal;
	text-decoration: inherit;
	padding-right:4px;
}
ul.xpose_thumbs22 li a:hover, ul.xpose_thumbs li a:hover {
	color:#c32700;
}
/* BOTTOMBAR */
#bottombar {
	overflow:hidden;
	margin:0 auto;
	padding:15px 28px;
	color:#dddddd;
	background-color: #161616;
}
#bottombar .left {
	float:left;
	width:34%;
}
#bottombar .center {
	float:left;
	width:34%;
}
#bottombar .right {
	float:right;
	width:32%;
}
#bottombar .left .widget, #bottombar .center .widget {
	margin:0 15px 15px 0;
}
#bottombar .right .widget {
	margin:0 0 15px 0;
}
#bottombar h2 {
	font: normal bold 13px Arial, sans-serif;
	margin: 15px 0 10px 0;
	padding: 6px 0;
	text-transform: uppercase;
	position: relative;
	color: #fff;
	font-family: Oswald, Impact, sans-serif;
	font-weight: normal;
	font-size: 16px;
	letter-spacing: 2.5px;
}
#bottombar ul, #bottombar ol {
	list-style-type:none;
	margin:0 0 0 0;
	padding:0 0 0 0;
}
#bottombar li {
	margin:5px 0;
	padding:0 0 0 0;
}
#bottombar ul li:before {
	color:#eeeeee !important;
}
#bottombar a {
	color:#dddddd;
}
#bottombar a:hover {
	color:#ffffff;
}
/* FOOTER */
#footer-wrapper {
	background: #151108;
	margin: 0 auto;
	padding: 8px 20px;
	overflow: hidden;
	color: #eeeeee;
	font-size: 14px;
	font-family: Lato, Arial, sans-serif;
}
.footer-left {
	float:left;
	margin:10px;
	margin-top: 9px;
	color: #949494;
}
.footer-right {
	float:right;
	margin:10px;
	color: #949494;
}
#footer-wrapper a {
	color:#b8b8b8;
}
#footer-wrapper a:hover {
	color:#ffffff;
}
/* CUSTOM WIDGET */
.widget ul {
	line-height:1.4em;
}
/* Tab Menu */
.set, .panel {
	margin: 0 0;
}
.tabs .panel {
	padding:0 0;
}
.tabs-menu {
	border-bottom:3px solid #E73138;
	padding: 0 0;
	margin:0 0;
}
.tabs-menu li {
	font:normal bold 12px Arial, sans-serif;
	display: inline-block;
	*display: inline;
	zoom: 1;
	margin: 0 3px 0 0;
	padding:10px;
	background:#fff;
	border:1px solid #e5e5e5;
	border-bottom:none !important;
	color:#333333;
	cursor:pointer;
	position:relative;
}
.tabs-menu .active-tab {
	background:#E73138;
	border:1px solid #E73138;
	border-bottom:none !important;
	color:#fff;
}
.tabs-content {
	padding:10px 0;
}
.tabs-content .widget li {
	float:none !important;
	margin:5px 0;
}
.tabs-content .widget ul {
	overflow:visible;
}
/* Custom CSS for Blogger Popular Post Widget */
.PopularPosts ul,
.PopularPosts li,
.PopularPosts li img,
.PopularPosts li a,
.PopularPosts li a img {
	margin:0 0;
	padding:0 0;
	list-style:none;
	border:none;
	background:none;
	outline:none;
}
.PopularPosts ul {
	margin:.5em 0;
	list-style:none;
	color:black;
	counter-reset:num;
}
.PopularPosts ul li img {
	display:block;
	margin:0 .5em 0 0;
	width:85px;
	height:85px;
	float:left;
	padding: 2px;
	border: 1px solid lightGrey;
}
.PopularPosts ul li {
	counter-increment:num;
	position:relative;
}
.PopularPosts .item-title {
	padding-bottom: .2em;
	font-size: 16px;
	font-weight: 300;
	font-family: "Oswald", Impact, Arial, sans-serif;
	letter-spacing: 1px;
	line-height: 1.5;
	font-size: 14px;
	text-transform: uppercase;
}
/* Set color and level */
.PopularPosts ul li {margin-right:1% !important}
.PopularPosts .item-thumbnail {
	margin:0 0 0 0;
}
.PopularPosts .item-snippet {
	font-size:11.5px;
	color: #747474;
}
.profile-img{
	display:inline;
	opaciry:10;
	margin:0 6px 3px 0;
}
/* back to top */
#back-to-top {
	padding: 8px 10px;
	color: #FFF;
	height: 30px;
	text-align: center;
	cursor: pointer;
	background-color: #333;
}
.back-to-top {
	position:fixed !important;
	position:absolute;
	bottom:20px;
	right:20px;
	z-index:999;
}
#back-to-top:hover {
	background-color: #f8674a;
}
/* ==== Related Post Widget Start ==== */
#related-posts h2 > span{
	border-bottom: 2px solid #c32700;
	bottom: -2px;
	padding: 4px 10px;
}
#related-posts{
	float:left;
	width:100%;
	margin-bottom:40px;
}
#related-posts h2{
	border-bottom: 2px solid #eee;
	padding: 4px 0;
	font: normal normal 18px Oswald;
	text-transform: uppercase;
	font: normal bold 12px Arial, sans-serif;
	text-align: left;
	color: #474747;
	margin-bottom: 5px;
	display:none;
}
#related-posts a {
	width: 230px;
	text-decoration: none;
	margin: 0 7px 7px 0;
	float: left;
}
#related-posts #r-title {
	width: 100%;
	padding: 9px 0px 20px;
	color: #fff;
	height: 25px;
	text-align: left;
	margin: -61px 0px 0px 0px;
	font-size: 15px;
	line-height: 20px;
	background: #111;
	opacity: 0.7;
	filter: alpha(opacity = 70);
}
#related-posts h8 {
	padding-left: 14px;
	display: inline-block;
}
#related-posts .related_img {
	padding:0px;
	width:100%;
	max-width: 100%;
	height:160px;
}
#related-posts .related_img:hover{
	opacity:.7;
	filter:alpha(opacity=70);
	-moz-opacity:.7;
	-khtml-opacity:.7;
}
/* share buttons */
.share-buttons-box {
	height: 67px;
	background: url(http://3.bp.blogspot.com/-moj4-jk-UB0/U1qCkCPaGQI/AAAAAAAADTY/tixmak8NHV8/s1600/share.png) no-repeat 330px 10px;
	margin:20px 0 15px;
	overflow:hidden;
}
.share-buttons {
	margin:0 0;
	height:67px;
	float:left;
}
.share-buttons .share {
	float:left;
	margin-right:10px;
	display:inline-block;
}
/* error and search */
.status-msg-wrap {
	font-size:120%;
	font-weight:bold;
	width:100%;
	margin:20px auto;
}
.status-msg-body {
	padding:20px 2%;
	width:96%;
}
.status-msg-border {
	border:1px solid #e5e5e5;
	opacity:10;
	width:auto;
}
.status-msg-bg {
	background-color:#ffffff;
}
.status-msg-hidden {
	padding:20px 2%;
}
#ArchiveList ul li:before {
	content:"" !important;
	padding-right:0px !important;
}
/* facebook comments */
.fb-comments{width: 100% !important;}
.fb-comments iframe[style]{width: 100% !important;}
.fb-like-box{width: 100% !important;}
.fb-like-box iframe[style]{width: 100% !important;}
.fb-comments span{width: 100% !important;}
.fb-comments iframe span[style]{width: 100% !important;}
.fb-like-box span{width: 100% !important;}
.fb-like-box iframe span[style]{width: 100% !important;
}
.rich-snippet {
	padding:10px;
	margin:15px 0 0;
	border:3px solid #eee;
	font-size:12px;
}
/*-------sidebar----------------*/
.sidebar-narrow{margin:0}
#sidebar-narrow .widget{margin-bottom:30px;}
#sidebar-narrow{float:right;width:160px;margin-right: 14px;
	border-right: 1px solid #eaeaea;
	border-left: 1px solid #eaeaea;
	padding: 16px 10px 0 15px;}
	div#main {
		width: 98%;
		margin-top: 15px;
	}
	div#mywrapper {
		float: left;
		width: 740px;
		margin-top:10px;
		padding-right: 30px;
		border-right: 1px solid #e6e6e6;
	}
	#sidebartab {
		margin-bottom: 15px;
		margin-top: -20px;
	}
	.tab-widget-menu {
		height: 46px;
		margin: 0;
		padding: 8px 0 0 2px;
	}
	#sidebartab .widget {
		margin-bottom: 0;
		padding-bottom: 0;
	}
	#sidebartab .h2title {
		display: none;
	}
	#sidebartab .h2titlesmall {
		display: none;
	}
	#sidebartab .widget-content {
		box-shadow: none;
		-moz-box-shadow: none;
		-webkit-box-shadow: none;
		border: 0;
	}
	.tab-widget-menu ul, .tab-widget-menu li {
		list-style: none;
		padding: 0;
		margin: 0;
	}
	.tab-widget-menu li {
		background: #333;
		bottom: -2px;
		color: #FFF;
		cursor: pointer;
		float: left;
		height: 38px;
		line-height: 38px;
		margin: -2px 0px 0 0px;
		padding: 0;
		position: relative;
		text-align: center;
		width: 33.3%;
		z-index: 2;
	}
	.tab-widget-menu li.selected {
		background: #c32700;
		border-width: 1px 1px 3px;
		color: #FFF;
		margin-top: -2px;
	}
	#sidebartab .h2title, #sidebartab h2 {
		display: none;
	}
	#sidebartab .h2titlesmall, #sidebartab h2 {
		display: none;
	}
	#sidebartab .widget-content img {
		padding: 2px;
		border: 1px solid lightGrey;
		width: 80px;
		height: 80px;
	}
	#sidebartab .popular-posts li {
		background: none repeat scroll 0 0 transparent;
		border-bottom: 1px solid #E9E9E9;
		overflow: hidden;
		padding: 10px 0;
	}
	.PopularPosts img:hover, #sidebartab .widget-content img:hover {
	}
	#sidebarlab .sidebar li a:hover {
		color: #fff;
		background: #222;
	}
	.PopularPosts a {font-weight:bold;}
	.tagcloud a {
		background: #e4e4e4;
		color: #888;
		display: block;
		float: left;
		font-size: 14px!important;
		line-height: 12px;
		margin: 0 2px 2px 0;
		padding: 12px 17px;
	}
	.tagcloud a:link {
		color: #888;
	}
	.tagcloud a:hover {
		background: #c32700;
		color: #fff;
	}
	#bottombar{    font-family: Lato, Arial, sans-serif;}
	.tagcloud1 a {
		background: #2e2e2e;
		color: #888;
		display: block;
		float: left;
		font-size: 14px!important;
		line-height: 12px;
		margin: 0 2px 2px 0;
		padding: 12px 17px;
		background: #2a2a2a;
		padding: 8px 11px;
		/* background: #e6e6e6; */
		float: left;
		margin: 0 5px 5px 0;
		line-height: 1;
	}
	.tagcloud1 a:link {
		color: #888;
	}
	.tagcloud1 a:hover {
		background: #c32700;
		color: #fff;
	}
	.showpageArea a {
		clear:both;
		margin:-5px 0 10px;
		text-align:center;
		font-size:11px;
		font-weight:bold;
		text-transform:uppercase;
	}
	.showpageNum a {
		padding:6px 10px;
		margin-right:3px;
		display:inline-block;
		color:#333333;
		background-color:#ffffff;
		border: 1px solid #dddddd;
	}
	.showpageNum a:hover {
		border: 1px solid #aaaaaa;
	}
	.showpagePoint {
		padding:6px 10px;
		margin-right:3px;
		display:inline-block;
		color:#333333;
		background-color:#ffffff;
		border: 1px solid #aaaaaa;
	}
	.showpageOf {
		display:none;
	}
	.showpage a {
		padding:6px 10px;
		margin-right:3px;
		display:inline-block;
		color:#333333;
		background-color:#ffffff;
		border: 1px solid #dddddd;
	}
	.showpage a:hover {
		border: 1px solid #aaaaaa;
	}
	.showpageNum a:link,.showpage a:link {
		text-decoration:none;
		color:#666;
	}
	.button {
		text-align: center;
		width: 100%;
		margin: 10px 0;
		padding: 0;
		font-size: 14px;
		font-family: 'Tahoma', Geneva, Sans-serif;
		color: #fff;
		margin-left: 0em !important;
	}
	.button ul {
		margin: 0;
		padding: 0;
	}
	.button li {
		display: inline-block;
		margin: 10px 0;
		padding: 0;
	}
	#Attribution1 {
		height:0px;
		visibility:hidden;
		display:none
	}
	.author-avatar img{border:1px solid #ccc;padding:4px;background:#fff;float:left;margin:0 10px 5px 0;border:50%;box-shadow:0 0 3px 0 #b5b5b5;-moz-box-shadow:0 0 3px 0 #b5b5b5;-webkit-box-shadow:0 0 3px 0 #b5b5b5}
	#author-box h3 {
		padding-bottom: 5px;
		border-bottom: 4px solid #333;
		font-size: 18px;
		color:#222;
		font-family: Oswald,arial,Georgia,serif;
	}
	.share-post {
		font-size: 13px;
		margin-top: 15px;
	}
	.share-post li {
		float: left;
	}
	.share-post a {
		display: block;
		margin-right: 10px;
		text-indent: -9999px;
		margin-left: 12px;
		background: url(http://4.bp.blogspot.com/-M_utSb-nN04/U6V8Gut9dJI/AAAAAAAAAjE/6g1X58pjjcg/s1600/single-share.png) no-repeat;
		-webkit-transition: opacity .2s;
		-moz-transition: opacity .2s;
		-o-transition: opacity .2s;
		transition: opacity .2s;
	}
	.share-post a:hover {
		opacity: .7;
	}
	.share-post
	.facebook a {
		width: 7px;
	}
	.share-post
	.twitter a {
		width: 18px;
		background-position: -47px 0;
	}
	.share-post
	.google a {
		width: 14px;
		background-position: -105px 0;
	}
	.share-post
	.pinterest a {
		width: 11px;
		background-position: -159px 1px;
	}
	/*** Share Post Styling ***/
	#share-post {
		width: 100%;
		overflow: hidden;
		margin-top: 20px;
	}
	#share-post a {
		display: block;
		height: 32px;
		line-height: 32px;
		color: #fff;
		float: left;
		padding-right: 10px;
		margin-right: 10px;
		margin-bottom: 25px;
	}
	#share-post
	.facebook {
		background-color: #436FC9;
	}
	#share-post
	.twitter {
		background-color: #40BEF4;
	}
	#share-post
	.google {
		background-color: #EC5F4A;
	}
	#share-post
	span {
		display: block;
		width: 32px;
		height: 32px;
		float: left;
		margin-right: 10px;
		background: url(http://4.bp.blogspot.com/-M_utSb-nN04/U6V8Gut9dJI/AAAAAAAAAjE/6g1X58pjjcg/s1600/single-share.png) no-repeat;
	}
	#share-post
	.facebook span {
		background-color: #3967C6;
	}
	#share-post
	.twitter span {
		background-color: #26B5F2;
		background-position: -72px 0;
	}
	#share-post
	.google span {
		background-color: #E94D36;
		background-position: -144px 0;
	}
	.container {
		width: 1170px;
		margin: 0 auto;
	}
/* Search Box
----------------------------------------------- */
#searchformfix
{
	float:right;
	overflow:hidden;
	position:relative;
}
#searchform
{
	margin:6px 0 0;
	padding:0;
}
#searchform fieldset
{
	padding:0;
	border:none;
	margin:0;
}
#searchform input[type="text"]{
	background:#fff; border:none;
	float:left; padding:0px 10px 0px 15px;
	margin:0px; width:175px; max-height:31px;
	border-radius: 3px;
	line-height:27px; color:#afafaf}
	#searchform input[type=submit]
	{
		background:url(http://4.bp.blogspot.com/-R8OKVUsis3s/UgZEksy0V1I/AAAAAAAAAT4/QtN9sBHMZis/s1600/icon-search.png) center 5px no-repeat;
		cursor:pointer;
		margin:0;
		padding:0;
		width:37px;
		height:27px;
		line-height:27px;
		right: 0px;
		position: absolute;
	}
	input[type=submit]
	{
		padding:4px 17px;
		color:#fff;
		text-transform:uppercase;
		border:none;
		font-size:20px;
		background:url(gradient.png) bottom repeat-x;
		cursor:pointer;
		margin-top:10px;
		float:left;
		overflow:visible;
	}
	#searchform input[type=submit]:hover
	{
		background-color:#747474;
	}
	.selectnav {
		display:none;
	}
	.kp-socials-widget ul {
		margin: -20px -10px 0;
		text-align: center;
	}
	.kp-socials-widget ul li {
		margin: 20px 10px 0;
		float: left;
		list-style: none;
		width: 140px;
		height: 140px;
		line-height: 140px;
		font-size: 64px;
		border-top: none;
	}
	.kp-socials-widget ul li:first-child {
		margin: 20px 10px 0;
	}
	.kp-socials-widget ul li.rss-icon {
		background-color: #e67e22;
	}
	.kp-socials-widget ul li.twitter-icon {
		background-color: #28aae1;
	}
	.kp-socials-widget ul li.facebook-icon {
		background-color: #3b5998;
	}
	.kp-socials-widget ul li.gplus-icon {
		background-color: #df4c39;
	}
	.kp-socials-widget ul li a {
		color: #fff;
	}
	/*---Flicker Image Gallery-----*/
	.flickr_plugin {
		width: 100%;
	}
	.flickr_badge_image {
		float: left;
		height: 71px;
		margin: 8px 5px 0px 5px;
		width: 71px;
	}
	.flickr_badge_image a {
		display: block;
	}
	.flickr_badge_image a img {
		display: block;
		width: 100%;
		height: auto;
		-webkit-transition: opacity 100ms linear;
		-moz-transition: opacity 100ms linear;
		-ms-transition: opacity 100ms linear;
		-o-transition: opacity 100ms linear;
		transition: opacity 100ms linear;
	}
	.flickr_badge_image a img:hover {
		opacity: .5;
	}
	div#act {
		display: none;
	}
	#sidebar-narrow .list-label-widget-content li:before {
		content: "\f013";
		font-family: fontawesome;
		margin-right: 5px;
	}
	#sidebar-narrow .list-label-widget-content li {
		display: block;
		padding: 0 0 8px 0;
		position: relative;
	}
	#sidebar-narrow .list-label-widget-content li a {
		color: #555555;
		font-size: 13px;
		font-weight: normal;
	}
	#sidebar-narrow .list-label-widget-content li a:first-child {
		text-transform: capitalize;
	}
	#sidebar-narrow .list-label-widget-content li a:hover {
		text-decoration: underline;
	}
	#sidebar-narrow .list-label-widget-content li span:last-child {
		color: #949494;
		font-size: 12px;
		font-weight: bold;
		position: absolute;
		right: 0;
		top: 0;
	}
	#sidebar-narrow .list-label-widget-content li:hover span:last-child {
		text-decoration: underline;
	}
	.social-icons{float:left;}
	.social-icons{margin:7px 0 0 10px;text-align:center;}
	.social-icons a{display:inline-block;position:relative;overflow:hidden;line-height:0px;margin:1px;}.social-icons a i{width:24px;height:24px;line-height:24px;font-size:13px;}.social-icons.icon-32 a i{width:32px;height:32px;line-height:32px;font-size:18px;}.social-icons.icon-12 a i{width:18px;height:18px;line-height:18px;font-size:9px;}.social-icons.icon-12 a i.icon-home{padding:0;height:18px;font-size:15px;font-weight:normal;}
	.social-icons a i{color:#FFF!important;display:inline-block;text-align:center;overflow:hidden;border-radius:100%;-webkit-transition:all ease-in-out 0.2s;-moz-transition:all ease-in-out 0.2s;-o-transition:all ease-in-out 0.2s;transition:all ease-in-out 0.2s;}.social-icons a i.icon-home{background:#4e5462;}.social-icons a i.fa-facebook{background:#507cbe;}.social-icons a i.fa-twitter{background:#65cdef;}.social-icons a i.social_icon-rss{background:#fbab5d;}.social-icons a i.fa-google{background:#ee8180;}.social-icons a i.fa fa-pinterest{background:#f16361;}.social-icons a i.social_icon-myspace{background:#2e9fdf;}.social-icons a i.fa fa-dribbble{background:#d97aa5;}.social-icons a i.social_icon-linkedin{background:#91c9db;}.social-icons a i.fa fa-evernote{background:#8ac979;}.social-icons a i.social_icon-flickr{background:#db97be;}.social-icons a i.fa fa-youtube{background:#f16361;}.social-icons a i.social_icon-skype{background:#38c3f2;}.social-icons a i.fa fa-digg{background:#4ea1d9;}.social-icons a i.social_icon-reddit{background:#7fc1d7;}.social-icons a i.fa fa-delicious{background:#5a91de;}.social-icons a i.fa-stumbleupon{background:#e36644;}.social-icons a i.fa fa-tumblr{background:#4e7da2;}.social-icons a i.fa-vimeo-square{background:#87d3e0;}.social-icons a i.fa fa-blogger{background:#fbc95d;}.social-icons a i.fa fa-wordpress{background:#dddcdc;}.social-icons a i.fa fa-yelp{background:#c64947;}.social-icons a i.social_icon-lastfm{background:#c35252;}.social-icons a i.social_icon-grooveshark{background:#2ab8ed;}.social-icons a i.social_icon-xing{background:#639d71;}.social-icons a i.social_icon-posterous{background:#e7c16f;}.social-icons a i.social_icon-deviantart{background:#95a595;}.social-icons a i.social_icon-openid{background:#fb915d;}.social-icons a i.social_icon-behance{background:#18ace3;}.social-icons a i.social_icon-instagram{background:#c8c5b3;}.social-icons a i.social_icon-paypal{background:#4ea1d9;}.social-icons a i.social_icon-spotify{background:#6fcb57;}.social-icons a i.social_icon-viadeo{background:#9ec7d5;}.social-icons a i.social_icon-googleplay{background:#ce5452;}.social-icons a i.social_icon-forrst{background:#64bb8d;}.social-icons a i.social_icon-vk{background:#568bb0;}.social-icons a i.social_icon-appstore{background:#cdcccb;}.social-icons a i.social_icon-amazon{background:#f0b22e;}.social-icons a i.fa-soundcloud{background:#f35839;}.social-icons a i:hover{background:#434347;}
	a.tooldown{display:inline-block;}.tipsy{font-size:12px;position:absolute;padding:5px;z-index:100000;}.tipsy-inner{background-color:#232323;color:#FFF;max-width:200px;padding:0px 8px;text-align:center;border-radius:3px;}.tipsy-arrow{position:absolute;width:0;height:0;line-height:0;border:5px dashed #232323;}.tipsy-arrow-n{border-bottom-color:#232323;}.tipsy-arrow-s{border-top-color:#232323;}.tipsy-arrow-e{border-left-color:#232323;}.tipsy-arrow-w{border-right-color:#232323;}.tipsy-n .tipsy-arrow{top:0px;left:50%;margin-left:-5px;border-bottom-style:solid;border-top:none;border-left-color:transparent;border-right-color:transparent;}.tipsy-nw .tipsy-arrow{top:0;left:10px;border-bottom-style:solid;border-top:none;border-left-color:transparent;border-right-color:transparent;}.tipsy-ne .tipsy-arrow{top:0;right:10px;border-bottom-style:solid;border-top:none;border-left-color:transparent;border-right-color:transparent;}.tipsy-s .tipsy-arrow{bottom:0;left:50%;margin-left:-5px;border-top-style:solid;border-bottom:none;border-left-color:transparent;border-right-color:transparent;}.tipsy-sw .tipsy-arrow{bottom:0;left:10px;border-top-style:solid;border-bottom:none;border-left-color:transparent;border-right-color:transparent;}.tipsy-se .tipsy-arrow{bottom:0;right:10px;border-top-style:solid;border-bottom:none;border-left-color:transparent;border-right-color:transparent;}.tipsy-e .tipsy-arrow{right:0;top:50%;margin-top:-5px;border-left-style:solid;border-right:none;border-top-color:transparent;border-bottom-color:transparent;}.tipsy-w .tipsy-arrow{left:0;top:50%;margin-top:-5px;border-right-style:solid;border-left:none;border-top-color:transparent;border-bottom-color:transparent;cursor:help;}
	div.conty {
		width: 960px;
		margin: 0 auto;
	}
	#beakingnews {
		float: left;
		height: 30px;
		line-height: 28px;
		overflow: hidden;
		width: 67.2%;
	}
	#recentpostbreaking li a {
		color:#fff;
		font-family: Open Sans,sans-serif;
		font-size: 14px;
		font-weight: 400;
		line-height: 32px;
	}
	#recentpostbreaking li a:hover {
		color:#333;
	}
	#beakingnews .tulisbreaking {
		background:#333;
	}
	#beakingnews .tulisbreaking{
		color:$(mainbgfontcol.background.color) !important;
	}
	#beakingnews .tulisbreaking {
		color: #FFFFFF;
		display: block;
		float: left;
		font-family: sans-serif;
		font-weight: bold;
		padding: 5px 10px;
		position: absolute;
		font-family: Open Sans,sans-serif;
		font-size: 14px;
		font-weight: 400;
	}
	#recentpostbreaking {
		float: left;
		margin-left: 74px;
	}
	#recentpostbreaking ul,#recentpostbreaking li{list-style:none;margin:0;padding:2px  0 0}
	#social-counter-widget{padding:0px!important;margin-bottom:20px!important;overflow:hidden;clear:both;display:block;position:relative;}#social-counter-widget ul.social-counter-widget{}#social-counter-widget ul.social-counter-widget,#social-counter-widget ul.social-counter-widget li{list-style:none!important;margin:0!important;padding:0!important;}#social-counter-widget ul.social-counter-widget li{display:inline-block;}#social-counter-widget ul.social-counter-widget li a{display:block;overflow:hidden;color:#282a2b;}#social-counter-widget ul.social-counter-widget li a i{margin:0 0 10px 0;}#social-counter-widget ul.social-counter-widget li a span{font-size:16px!important;font-family:inherit;line-height:22px!important;font-weight:normal!important;}#social-counter-widget ul.social-counter-widget li a small{color:#c1c1c1;}#social-counter-widget.style1-SC{background-color:#f9f9f9;border:1px #f0f0f0 solid;border-radius:3px;padding:10px 0px!important;}#social-counter-widget.style1-SC li{display:block;width:33%;overflow:hidden;float:left;}#social-counter-widget.style1-SC li a{display:inline-block;text-align:center;padding:10px 0px;overflow:hidden;}#social-counter-widget.style1-SC li a i,#social-counter-widget.style1-SC li a span,#social-counter-widget.style1-SC li a small{clear:both;display:block;}#social-counter-widget.style1-SC ul.social-counter-widget li a i{color:#FFF!important;display:inline-block!important;width:50px!important;height:50px!important;line-height:50px!important;vertical-align:middle;text-align:center;font-size:28px;overflow:hidden;border-radius:100px;-webkit-transition:all ease-in-out 0.2s;-moz-transition:all ease-in-out 0.2s;-o-transition:all ease-in-out 0.2s;transition:all ease-in-out 0.2s;}#social-counter-widget.style1-SC ul.social-counter-widget li.social-counter-rss a i.icon.social_icon-rss{background:#faa33d;}#social-counter-widget.style1-SC ul.social-counter-widget li.social-counter-twitter a i.icon.social_icon-twitter{background:#40bff5;}#social-counter-widget.style1-SC ul.social-counter-widget li.social-counter-facebook a i.icon.social_icon-facebook{background:#5d82d1;}#social-counter-widget.style1-SC ul.social-counter-widget li.social-counter-gplus a i.icon.social_icon-google{background:#eb5e4c;}#social-counter-widget.style1-SC ul.social-counter-widget li.social-counter-youtube a i.icon.social_icon-youtube{background:#ef4e41;}#social-counter-widget.style1-SC ul.social-counter-widget li.social-counter-vimo a i.icon.social_icon-vimeo{background:#35c6ea;}#social-counter-widget.style1-SC ul.social-counter-widget li.social-counter-soundcloud a i.icon.social_icon-soundcloud{background:#ff7e30;}#social-counter-widget.style1-SC ul.social-counter-widget li a:hover i.icon{background:#232323!important;}#social-counter-widget.style2-SC{padding:0;}#social-counter-widget.style2-SC ul.social-counter-widget li{display:block;width:100%;overflow:hidden;margin:0 0 3px 0!important;border-radius:2px;-webkit-transition:all ease-in-out 0.2s;-moz-transition:all ease-in-out 0.2s;-o-transition:all ease-in-out 0.2s;transition:all ease-in-out 0.2s;}#social-counter-widget.style2-SC li a{display:block;text-align:left;padding:5px;overflow:hidden;}#social-counter-widget.style2-SC ul.social-counter-widget li a i.icon,#social-counter-widget.style2-SC ul.social-counter-widget li a span,#social-counter-widget.style2-SC ul.social-counter-widget li a small{float:left;line-height:35px!important;}#social-counter-widget.style2-SC ul.social-counter-widget li a i.icon{font-size:18px;color:#FFF;margin:0 0 0 0!important;display:inline-block!important;width:35px!important;height:35px!important;text-align:center;font-size:17px;line-height:35px!important;font-weight:normal!important;overflow:hidden;border-radius:100px;}#social-counter-widget.style2-SC ul.social-counter-widget li a span{color:#FFF;padding:0 15px}#social-counter-widget.style2-SC ul.social-counter-widget li a small{color:#FFF;color:rgba(255,255,255,0.7);}#social-counter-widget.style2-SC ul.social-counter-widget li.social-counter-rss{background:#faa33d;}#social-counter-widget.style2-SC ul.social-counter-widget li.social-counter-twitter{background:#40bff5;}#social-counter-widget.style2-SC ul.social-counter-widget li.social-counter-facebook{background:#5d82d1;}#social-counter-widget.style2-SC ul.social-counter-widget li.social-counter-gplus{background:#eb5e4c;}#social-counter-widget.style2-SC ul.social-counter-widget li.social-counter-youtube{background:#ef4e41;}#social-counter-widget.style2-SC ul.social-counter-widget li.social-counter-vimo{background:#35c6ea;}#social-counter-widget.style2-SC ul.social-counter-widget li.social-counter-soundcloud{background:#ff7e30;}#social-counter-widget.style2-SC ul.social-counter-widget li:hover{background:#232323!important;}#social-counter-widget.style2-SC ul.social-counter-widget li:hover a small{color:#FFF!important;}#social-counter-widget.style3-SC{background-color:#FFF;border-radius:3px;padding:10px 0px!important;}#social-counter-widget.style3-SC ul.social-counter-widget li a span{font-size:13px!important;}#social-counter-widget.style3-SC li{display:block;width:24%;overflow:hidden;float:left;}#social-counter-widget.style3-SC li a{display:inline-block;text-align:center;padding:10px 0px;}#social-counter-widget.style3-SC li a i,#social-counter-widget.style3-SC li a span,#social-counter-widget.style3-SC li a small{clear:both;display:block;}#social-counter-widget.style3-SC ul.social-counter-widget li a i{color:#FFF!important;display:inline-block!important;width:35px!important;height:35px!important;text-align:center;font-size:17px;line-height:35px!important;overflow:hidden;border-radius:100px;-webkit-transition:all ease-in-out 0.2s;-moz-transition:all ease-in-out 0.2s;-o-transition:all ease-in-out 0.2s;transition:all ease-in-out 0.2s;}#social-counter-widget.style3-SC ul.social-counter-widget li.social-counter-rss a i.icon.social_icon-rss{background:#faa33d;}#social-counter-widget.style3-SC ul.social-counter-widget li.social-counter-twitter a i.icon.social_icon-twitter{background:#40bff5;}#social-counter-widget.style3-SC ul.social-counter-widget li.social-counter-facebook a i.icon.social_icon-facebook{background:#5d82d1;}#social-counter-widget.style3-SC ul.social-counter-widget li.social-counter-gplus a i.icon.social_icon-google{background:#eb5e4c;}#social-counter-widget.style3-SC ul.social-counter-widget li.social-counter-youtube a i.icon.social_icon-youtube{background:#ef4e41;}#social-counter-widget.style3-SC ul.social-counter-widget li.social-counter-vimo a i.icon.social_icon-vimeo{background:#35c6ea;}#social-counter-widget.style3-SC ul.social-counter-widget li.social-counter-soundcloud a i.icon.social_icon-soundcloud{background:#ff7e30;}#social-counter-widget.style3-SC ul.social-counter-widget li a:hover i.icon{background:#232323!important;}#social-counter-widget.style4-SC{padding:0;}#social-counter-widget.style4-SC ul.social-counter-widget li{display:block;clear:both;overflow:hidden;margin:1px 1px 5px 1px!important;border-radius:2px;background-color:#FFF;box-shadow:0 0 1px rgba(0,0,0,0.25);border:0 none!important;}#social-counter-widget.style4-SC ul.social-counter-widget li:last-child{}#social-counter-widget.style4-SC li a{display:block;text-align:left;padding:5px;overflow:hidden;color:#999!important;}#social-counter-widget.style4-SC ul.social-counter-widget li a span{font-size:14px!important;font-family:sans-serif;}#social-counter-widget.style4-SC ul.social-counter-widget li a i.icon,#social-counter-widget.style4-SC ul.social-counter-widget li a span,#social-counter-widget.style4-SC ul.social-counter-widget li a small{float:left;line-height:30px!important;}#social-counter-widget.style4-SC ul.social-counter-widget li a i.icon{color:#FFF;margin:0px!important;display:inline-block!important;width:30px!important;height:30px!important;text-align:center;font-size:17px;line-height:30px!important;overflow:hidden;border-radius:2px;-webkit-transition:all ease-in-out 0.2s;-moz-transition:all ease-in-out 0.2s;-o-transition:all ease-in-out 0.2s;transition:all ease-in-out 0.2s;}#social-counter-widget.style4-SC ul.social-counter-widget li a span{padding:0 4px 0 15px}.rtl #social-counter-widget.style4-SC ul.social-counter-widget li a span{padding:0 15px 0 4px}#social-counter-widget.style4-SC ul.social-counter-widget li.social-counter-rss a i.icon.social_icon-rss{background:#faa33d;}#social-counter-widget.style4-SC ul.social-counter-widget li.social-counter-twitter a i.icon.social_icon-twitter{background:#40bff5;}#social-counter-widget.style4-SC ul.social-counter-widget li.social-counter-facebook a i.icon.social_icon-facebook{background:#5d82d1;}#social-counter-widget.style4-SC ul.social-counter-widget li.social-counter-gpluscond='data:numPosts != 0' a i.icon.social_icon-google{background:#eb5e4c;}#social-counter-widget.style4-SC ul.social-counter-widget li.social-counter-youtube a i.icon.social_icon-youtube{background:#ef4e41;}#social-counter-widget.style4-SC ul.social-counter-widget li.social-counter-vimo a i.icon.social_icon-vimeo{background:#35c6ea;}#social-counter-widget.style4-SC ul.social-counter-widget li.social-counter-soundcloud a i.icon.social_icon-soundcloud{background:#ff7e30;}#social-counter-widget.style4-SC ul.social-counter-widget li a:hover i.icon{background:#999!important;}
	*/
	.container {
		width: 1170px;
		margin: 0 auto;
	}

--></style>
<style>
	#content-wrapper {

		margin: 0 auto;
		padding: 40px 40px;
		word-wrap:break-word;
	}

	/*** Top Posts Styling ***/
	div#top-posts {
		background: #F6F6F6;
	}

	div#top-posts .post {
		background: none;
	}
	#top-posts
	.post-thumb {
		margin-bottom: 10px;
	}

	#top-posts
	.post-title {
		margin-bottom: 8px;
	}

	#top-posts
	.cap-meta,
	.popular-post
	.cap-meta,
	#posts
	.cap-meta {
		position: absolute;
		left: 0;
		bottom: 0;
		background-color: #FFCA18;
		color: #fff;
		text-transform: capitalize;
		padding: 4px 10px;
		-webkit-transition: background .2s;
		-moz-transition: background .2s;
		-o-transition: background .2s;
		transition: background .2s;
	}

	#top-posts
	.post-thumb:hover
	.cap-meta,
	#large-thumb:hover
	.cap-meta,
	.popular-post
	.post-thumb:hover
	.cap-meta {
		background-color: #222;
	}

	#top-posts
	.cap-meta li,
	.popular-post
	.cap-meta li {
		margin: 0;
	}

	#top-posts
	.cap-date,
	.popular-post
	.cap-date {
		background-position: 0 -52px;
	}

	#top-posts
	li.cap-author {
		margin-right: 15px;
		background-position: 0 3px;
	}

	#top-posts
	.cap-author a {
		color: #fff;
		text-decoration: none;
	}

	#top-posts
	.cap-author a:hover {
		color: #ddd;
	}
	#category-one {
		width: 860px;
		float: left;
		margin-left: 20px;
	}

	#category-two {
		width: 270px;
		float: right;
	}

	/*** Small Posts Styling ***/

	.small-posts {
		width: 260px;
		float: left;
		margin-right: 15px;
	}

	.small-posts +
	.small-posts {
		margin-right: 0;
	}

	.small-posts
	.post {
		margin-bottom: 30px;
	}

	.small-posts
	.post-thumb {
		width: 255px;
		height: 150px;
		overflow: hidden;
	}

	/*** Large Posts Styling ***/

	#large-post {
		width: 565px;
		float: right;
		margin-bottom: 30px;
		border-left: 10px solid #798992;
		border-right: 10px solid #798992;
		margin-top: -37px;
		position: relative;
	}

	#large-thumb {
		position: relative;
		margin-bottom: 12px;
	}

	#large-thumb img {
		display: block;
		width: 100%;
		height: auto;
	}

	.middle-text {
		padding: 0 20px;
		position: relative;
		text-align: center;
	}

	.middle-text h1 {
		float: left;
		margin-bottom: 15px;
		-moz-transition: color 0.2s;
		-ms-transition: color 0.2s;
		-o-transition: color 0.2s;
		-webkit-transition: color 0.2s;
		transition: color 0.2s;
		width: 100%;
		text-transform: uppercase;
		font-size: 22px;
		line-height: 30px;
		margin: 0 0 10px;
		font-weight: 700;
		font: 700 22px/30px 'Oswald', sans-serif;
		color: #434c51;
	}

	h3.post-title {
		float: left;
		font-size: 14px;
		font-weight: 700;
		line-height: 140%;
		-moz-transition: color 0.2s;
		-ms-transition: color 0.2s;
		-o-transition: color 0.2s;
		-webkit-transition: color 0.2s;
		transition: color 0.2s;
		width: 100%;
		font-weight: 400;
		line-height: 22px;
		font: 400 16px/20px 'Oswald', sans-serif;
		color: #434c51;
	}


	.special-heading h2 {
		font-weight: 700;
		max-width: 255px;
		text-align: center;
		margin-top: 5px;
	}



/*---------------------------------
	
	featured post 

	---------------------------------------------*/

	.featured-post a {
		margin: 0;
		font-size: 18px;
		text-transform: uppercase;
		line-height: 22px;
		text-shadow: 1px 1px 1px #000;
		font-family: 'Oswald', sans-serif;
		font-weight: 400;
		color: #fff;
	}

	.featured-post .col-post {
		float: left;
		position: relative;
		overflow: hidden;
		margin: 0;
	}
	.featured-post .secondary-post {
		width: 33.3%;
		margin-left: 2px;
		margin-bottom: 16px;
	}
	.featured-post .main-post {
		width: 65%;
		margin-right: 16px;
	}
	.featured-post span {
		background: #666699;
		padding: 3px 6px;
		color: #fff;
		display: inline;
		font-size:12px;
		font-style: normal;
		display:none;
	}
	.featured-post img{
		height:100%;
		transition: all 1s ease-in-out;
		-moz-transition: all 1s ease-in-out;
		-o-transition: all 1s ease-in-out;
	}

	.featured-post .main-post img {
		height: 420px;
	}
	.featured-post .secondary-post img {
		height: 200px;
		object-fit: cover;
	}

	.featured-post header {
		position: absolute;
		bottom: 0;
		width: 95%;
		background-image: -webkit-linear-gradient(rgba(0, 0, 0, 0), rgba(0, 0, 0, 0.7));
		background-image: linear-gradient(rgba(0, 0, 0, 0), rgba(0, 0, 0, 0.7));
		padding: 10px 10px 5px;
		padding: 20px 20px 20px;
		margin-bottom: 7px;
	}

	.featured-post h4 {
		font-size: 15px;
		line-height: 1.3;
		font-weight:400;
	}



/*------------------------------

		slider css

		-------------------------------------*/


		#slider-section .slider .post-info {
			position: absolute;
			bottom: 0;
			left: 0;
			color: #FFFFFF;
			width: 100%;
			-webkit-transition: all 0.2s ease-in-out;
			-moz-transition: all 0.2s ease-in-out;
			-o-transition: all 0.2s ease-in-out;
			-ms-transition: all 0.2s ease-in-out;
			transition: all 0.2s ease-in-out;
			-webkit-backface-visibility: hidden;
			-moz-backface-visibility: hidden;
			backface-visibility: hidden;
		}
		#slider-section li {
			margin-right: 10px;
			background:#000;
			display:none;
		}
		#slider-section .slider .post-info .inner {
			padding: 15px;
			overflow: hidden;
		}
		#slider-section .post-info .excerpt {
			display: none;
		}
		#slider-section .entry-cat h6 {
			text-transform: uppercase;
			display: inline-block;
			border-bottom: 4px solid #FFFFFF;
			padding-bottom: 3px;
		}
		#slider-section .post-info h2 {
			text-transform: uppercase;
			font-weight: 700;
			line-height: 1;
			font-size:26px;
		}

		#slider-section li:hover .post-info {
			background: rgba(0, 0,0, 0.85);
		}
		#slider-section li:hover .excerpt {
			display: block;
		}
		#slider-section a {
			color: white;
		}
		div.entry-cat {
			margin-bottom: 10px;
		}

		#slider-section .slider .slider-nav a {
			display: block;
			width: 28px;
			height: 28px;
			overflow: hidden;
			text-indent: -999em;
			transition: all 0.3s ease 0s;
			position: absolute;
			z-index: 1;
			background-color: #EE7876;
			opacity: 0.9;
		}

		#slider-section .slider .slider-nav .flex-prev {
			background: url("http://3.bp.blogspot.com/-xVYvu-B2v-Q/U5wb6X1Pd7I/AAAAAAAAGVY/yqeW8jpei44/s320/arrow-left-large.png") no-repeat center;
			top: 230px;
			left: -50px;
		}

		#slider-section .slider .slider-nav .flex-next {
			background: url("http://2.bp.blogspot.com/-lwHQ-iJy3u4/U5wb6pwhdeI/AAAAAAAAGVc/BqU0KUrfh0k/s320/arrow-right-large.png") no-repeat center;
			top: 230px;
			right: -50px;
		}

		#slider-section .slider .slider-nav a:hover {
			opacity: 1;
		}

		.thumb-container{
			opacity:.85;
		}


		.flex-direction-nav li {
			list-style: none;
			padding:0;
			margin:0;
		}
		.flex-direction-nav  {
			padding: 0;
			margin: 0;
		}



		.slides {
			padding: 0;
			margin: 0;
			display: inline-block;
		}
		.slides li {
			position: relative;
			margin-right: 15px;
			overflow: hidden;
			margin-bottom:0!important;
			padding-bottom:0;
		}

		.slides li .post-info{
			overflow: hidden;
			margin-top: 15px;
		}

		.slides li .post-info .title{
			line-height:1.3;
			font-size: 13px;
		}


		.carousel-nav {
			float: right;
		}
		.carousel-section ul, .carousel-section ol {
			list-style: none;
			margin: 0;
			padding: 0;
		}
		#feat-carousel .carousel-nav ul li {
			margin: 0;
		}
		.carousel-nav ul li {
			float: left;
			margin: -1px;
		}

		#feat-carousel .carousel-nav .flex-prev {
			border-right: 1px solid #222222;
		}

		.carousel-nav .flex-prev {
			background: #333 url('http://3.bp.blogspot.com/-wDdMmq39sdg/U5l6GAefZyI/AAAAAAAAGUM/Hx0Ng5aYsmI/s320/arrow-small-left-inactive.png') no-repeat center;
		}
		.carousel-nav .flex-next {
			background: #333 url('http://1.bp.blogspot.com/-vlm0lJ5r2iI/U5l6G-NdRAI/AAAAAAAAGUU/ua4UO3VcfWM/s1600/arrow-small-right-inactive.png') no-repeat center;
		}
		.carousel-nav a {
			display: block;
			width: 34px;
			height: 34px;
			overflow: hidden;
			text-indent: -999em;
			transition: all 0.3s ease 0s;
			z-index: 1;
			opacity: 0.9;
		}



/* 
	sidebar flex slider 
	-------------------------------*/

	.flex-control-nav {
		text-align: center;
		overflow: hidden;
		padding: 0;
		margin: 0;
	}
	.flex-control-nav li {
		display: inline-block;
	}
	.flex-control-nav li a {
		display: inline-block;
		text-indent: -999em;
		margin-right: 5px;
		width: 12px;
		height: 12px;
		background: url("http://4.bp.blogspot.com/-nckVxxft2S8/U5qF0nfMpYI/AAAAAAAAGVE/pIcGDFOELyU/s320/bullet-dark.png") no-repeat left center;
		cursor: pointer;
	}
	.flex-control-nav li a:hover, .flex-control-nav li a.flex-active {
		background: url("http://4.bp.blogspot.com/-OteeGr2XEtY/U5qF0IwchaI/AAAAAAAAGVA/QbPeVcLWlos/s320/bullet-active.png") no-repeat left center;
	}


	.special-heading{
		text-align: center;
		margin: 0 0 20px;
		position: relative;
		font-size: 22px;
		text-transform: uppercase;
	}


	.special-heading .text-title {
		padding: 0 10px;
		background-color: #f6f6f6;
		display: inline-block;
		position: relative;
		z-index: 1;
		top: 6px;
	}

	.recent-post-title {
		margin: 0 0 30px;
		position: relative;
		font-size: 22px;
		text-transform: uppercase;

	}



	.text-title {
		padding: 0 10px;
		background-color: #fff;
		display: inline-block;
		position: relative;
		z-index: 1;

	}



	.h-left-line span, .h-right-line span {
		display: block;
		width: 100%;
		height: 120px;
		background-color: #ff5b4d;
	}


	.h-left-line {
		position: absolute;
		top: 0;
		width: 10px;
		height: 100%;
		background-color: #798992;
		margin-left: -10px;
		left: 0;
	}

	.h-right-line {
		position: absolute;
		top: 0;
		width: 10px;
		height: 100%;
		background-color: #798992;
		margin-right: -10px;
		right: 0;
	}


	.post-thumb img {
		height: 150px;
	}



	#bgco{background:#f6f6f6}
</style>
<style>
	.post {
		background: #ffffff;
		margin: 0 15px 0px 0px;
		padding: 15px 0;

		min-height: 200px;
		padding-bottom: 5px;
		border-bottom: 1px solid #e6e6e6;
		margin-bottom: 14px;
	}

	.img-thumbnail {
		background: #fbfbfb url(http://3.bp.blogspot.com/-ltyYh4ysBHI/U04MKlHc6pI/AAAAAAAADQo/PFxXaGZu9PQ/w200-h140-c/no-image.png) no-repeat center center;
		position: relative;
		float: left;
		margin: 0 30px 15px 0;
	}

	.img-thumbnail img {
		width: 100%;
		height: 175px;
	}
	div#main {
		width: 95%;
		margin-top: 15px;
	}

	a.readmore {
		display: none;
	}

	.post-info {

		font-size: 12px;

	}
	div#singlepage {
		overflow: hidden;
	}
</style>
<style>
	@media only screen and (max-width:1024px){
		#selectnav1 {
			background: none repeat scroll 0 0 #333;
			border: 1px solid #232323;
			color: #FFF;
			width: 475px;
			margin: 8px auto;
			float: none;
		}
		.selectnav {
			display:block;
			width:50%;
			margin:0;
			padding:7px;
		}
	}
	@media only screen and (max-width:768px){
		#selectnav1 {
			width: 80%;
		}
	}

</style>
<style>
	/* MEDIA QUERY */

	@media only screen and (max-width:1100px){

		div#mywrapper {
			float: left;
			width: 630px;
		}
		#carousel {
			width: 710px;
			overflow: hidden;
		}
		#post-wrapper {
			width: 645px;
			max-width: 645px;
		}

		.featured-post .main-post {
			width: 64%;
			margin-right: 16px;
		}

		#sidebar-wrapper {
			float: right;
			width: 27%;
			max-width: 335px;
			margin: 32px auto 0;
		}

		.featured-post .secondary-post {
			width: 33.3%;
			margin-left: 2px;

		}
		#outer-wrapper {
			max-width: 1000px;}

			#category-one {

				width: 695px;
			}
			#large-post {
				width: 400px;}

			}


			@media only screen and (max-width:1024px){

				#outer-wrapper {
					max-width: 760px;
				}
				#header-wrapper {
					min-height: 127px;      
				}
				.header-right {
					width: 67.8%;
					margin: 35px 0px 0px;
				}
				#nav {overflow: hidden;}
				#my-slider {
					margin-left: 15px;
				}
				div#main {
					width: auto;
				}
				div#mywrapper {
					float: left;
					width: 680px;
					border: 0;
				}
				#carousel {
					width: 680px!important;
					overflow: hidden;
				}
				#post-wrapper {
					width: 680px;
					max-width: 680px;
					margin-left: 0;
				}
				#sidebar-wrapper {
					width: 680px;
					max-width: 680px;
					float: none;
					margin: 20px auto 0;
					clear: both;
				}
				#searchformfix{display:block;}
				#menu-main {
					display: none!important;
				}

				#category-one {
					width: 525px;
				}

				.small-posts {
					width: 185px;}


					.small-posts .post-thumb {
						width: 185px;
						height: 100px;
						overflow: hidden;
					}

					#large-post {
						width: 305px;
					}
					#category-two {
						width: 200px;
						float: right;
					}

					div#featured-posts-section {
						max-height: 385px;}

						.featured-post .main-post {
							width: 64%;
						}

						.featured-post .secondary-post {
							width: 33.3%;}

							.featured-post .main-post img {
								height: 380px;
							}
							.featured-post .secondary-post img {
								height: 187px;
							}
							.featured-post .secondary-post h4 a {font-size: 17px!important;}
							.img-thumbnail img {z-index: 1;}
							.footer-left {
								float: left;
								margin: 9px 0 10px;
								color: #949494;
								width: 100%;
								text-align: center;
							}    
						}

						@media only screen and (max-width:768px){
							#outer-wrapper {
								padding:0;
							}

							div#featured-posts-section {
								display: none;
							}
							.menubar {
								list-style-type: none;
								margin: 0px;
								padding: 0px;
								text-align: center;
							}
							.menubar li {
								display: inline-block;
								float: none;
								line-height: 38px;
								margin: 0px;
								padding: 0px;
							}

							#menu-main {
								display: none;
							}
							#my-slider {
								margin-left: -6px;
							}
							#searchformfix {
								display: none;
							}
							#nav {margin:0}

							#category-one {
								display: none;
							}
							#category-two {
								display: none;
							}
							#content-wrapper {
								background-color: none;
								margin: 0px auto;
								padding: 0;
								word-wrap: break-word;
								width: 620px;
							}


							div.conty {
								width: 401px;
							}
							ul.xpose_thumbs1{width:100%}
							ul.xpose_thumbs22{width:100%}
							ul.xpose_thumbs22 span.xpose_meta{line-height:51px}
							#carousel {
								width: 620px !important;
								overflow: hidden;
							}
							div#mywrapper {
								float: ;
								width: 620px;
							}
							#post-wrapper, #sidebar-wrapper {

								width:620px;
								max-width:620px;
							}
							.active {
								display: block;
							}
							.post-body img {
								max-width:90%;
							}
							.img-thumbnail {
								margin: 0px 10px 0px 0px;
								width: 240px;
							}
							.stylebox .widget {
								padding:0 0 10px 0;
							}
							#stylebox-1 .widget, #stylebox-3 .widget, #stylebox-5 .widget {
								padding:0 5px 10px 0;
							}
							#stylebox-2 .widget, #stylebox-4 .widget, #stylebox-6 .widget {
								padding:0 0 10px 5px;
							}
							.sidebar-container, .post-container {
								padding:15px 0 0px;
							}
							.top-comment{width:41%}

						}

						@media only screen and (max-width:640px){
							#outer-wrapper {
								padding:0;
							}
							#menu-main {
								display: none;
							}
							.top-comment{width:41%}
							#sidebar-narrow{display:none}

							#category-one {
								display: none;
							}
							#category-two {
								display: none;
							}
							#carousel {display: none;}
							#content-wrapper {
								margin: 0px auto;
								padding: 0px;
								word-wrap: break-word;
								width: 460px;
								background: none;
							}
							div#mywrapper {
								width: 460px;
								margin: 0 auto;
								float: none;
							}
							#post-wrapper {
								width: 460px;
								max-width: 460px;
							}
							#sidebar-wrapper {
								width: 460px;
								max-width: 460px;

							}
							.post {
								background: #ffffff;
								margin: 0 15px 0px 0px;
								padding: 15px 0;
								min-height: 350px;
							}


							.header {
								float: none;
								width: 200px;
								max-width: 200px;
								height: 130px;
								margin: 0px auto;
							}
							#header-wrapper {
								min-height: auto;
							}
							.header-right {
								width: 80%;
								margin: 10px auto;
								float: none;
								clear: both;
							}   
							.img-thumbnail {
								margin: 0px 0px 10px 0px;
								width: 100%;
								height: 250px;
							}
							.img-thumbnail img {
								width: 100%;
								height: 250px;
							}
							.sidebar-container, .post-container{
								padding:10px 0 0px;
							}
							.largebanner .widget, #bottombar {
								padding:10px;
							}
							.post, .breadcrumbs {
								margin:0 0 10px;
								padding:10px;
							}
							.pagenavi {
								margin: 6px 0 10px;
							}
							.stylebox .widget-content {
								padding:10px;
							}
							#bottombar .left, #bottombar .center, #bottombar .right {
								float: none;
								width: 460px;
								margin: 0 auto;
							}
							.top-comment{width:41%}
						}
						@media only screen and (max-width:480px){
							#outer-wrapper {
								padding:0;
							}
							div.conty {
								width: 256px;
							}
							#content-wrapper {
								margin: 0px auto;
								padding: 0px;
								word-wrap: break-word;
								width: 300px;
								background: none;
							}
							div#mywrapper {
								width: 300px;
								margin: 0 auto;
								float: none;
							}
							#post-wrapper {
								width: 300px;
								max-width: 300px;
							}
							#sidebar-wrapper {
								width: 300px;
								max-width: 300px;

							}

							.post {
								background: #ffffff;
								margin: 0 15px 0px 0px;
								padding: 15px 0;
								min-height: 350px;
							}
							#searchformfix {
								display: none;
							}
							.top-comment{width:37%}
							.top-comment-widget-menu{height:58px}
							ul.xpose_thumbs1,ul.xpose_thumbs22{width:100%}
							#menu-main {
								display: none;
							}
							#sidebar-narrow{display:none}

							#bottombar .left, #bottombar .center, #bottombar .right {
								float: none;
								width: 300px;
								margin: 0 auto;
							}
							.post, .breadcrumbs {
								margin:0 0 8px;
								padding:8px;
							}
							.stylebox .widget-content,.stylebox1  .widget-content {
								padding:8px;
							}
							h2.post-title, h1.post-title {
								font-size:16px;
							}
							.img-thumbnail {
								margin: 0px 0px 10px;
								width: 100%;
								height: 180px;
							}
							.img-thumbnail img {
								width: 100%;
								height: 180px;
							}
							#stylebox-1 .widget, #stylebox-3 .widget,	#stylebox-2 .widget, #stylebox-4 .widget, #stylebox-5 .widget, #stylebox-6 .widget {
								padding:0 0 8px 0;
							}
							.comments .comment-block, .comments .comments-content .inline-thread {
								padding:10px !important;
							}
							.comment .comment-thread.inline-thread .comment {
								margin: 0 0 0 0 !important;
							}
							.footer-left, .footer-right {

								text-align:center;
							}
						}

						@media screen and (max-width:450px){
							.header-right {display: none;}
							.menubar li a {
								color: #FFF;
								display: block;
								padding: 0px 4px;
							}      
						}
						@media screen and (max-width:319px){
							#outer-wrapper {
								padding:0;
							}
							.top-menu {height: 8px;}
							#header-wrapper {padding: 0;}
							#menu-main, .menubar {
								display: none;
							}
							#sidebar-narrow{display:none}
							#content-wrapper {
								margin: 0px auto;
								padding: 0px;
								word-wrap: break-word;
								width: 220px;
								background: none;
							}
							div#mywrapper {
								width: 220px;
								margin: 0 auto;
								float: none;
							}
							#post-wrapper {
								width: 220px;
								max-width: 220px;
							}
							#sidebar-wrapper, #bottombar {
								display: none;
							}
							.img-thumbnail, .img-thumbnail img {  
								height: 130px;
							}
							.stylebox .widget-content,.stylebox1  .widget-content {
								padding:6px;
							}

						}
					</style>
					<style>



						#carousel {
							width: 1120px; 
							position: relative; 
							margin: 10px 0 0;
							height:250px;
							overflow: hidden;
						}
						#carousel .content {
							position: relative;
							left: 0px;
							width: 1120px;
							overflow:hidden;
						}
						#carousel ul{
							width:10000px;
							position: relative;
							overflow:hidden;
							margin-top:0px;
						}
						#carousel ul li {
							display: block; 
							float: left; 
							margin:0;
							margin-right:8.5px;  
							width: 272px; 
							overflow: hidden;
							height:160px;
						}
						#carousel .thumbE{
							height:80px;
							width: 272px;
						}
						#carousel  #previous_button { 
							position: absolute;
							bottom: 345px;
							right: 37px;
							width: 25px;
							height: 30px;
							cursor: pointer;

							color: #000;
							z-index: 999;
						}
						#carousel #next_button { 
							position: absolute; 
							bottom:345px; 
							right:10px; 
							width: 25px; 
							height: 30px; 
							cursor: pointer; 

							color:#000;
							background-position:100% 0;
							z-index:999; 
						}
						#carousel #next_button:hover, #previous_button:hover { 
							-ms-filter: "progid: DXImageTransform.Microsoft.Alpha(Opacity=80)"; 
							filter: alpha(opacity=80); 
							opacity: 0.8; 
							transition: opacity .25s ease-in-out; 
							-moz-transition: opacity .25s ease-in-out; 
							-webkit-transition: opacity .25s ease-in-out; 
						}
						#carousel ul li a.slider_title{
							background: #111;
							opacity: 0.9;
							filter: alpha(opacity = 90);
							float: left;
							text-align: left;
							font: normal 14px Oswald;
							margin-top: 27px;
							height: 100%;
							background-color: rgba(0,0,0,0.5);
							display: inline-block;
							color: #FFF!important;
							font: 16px/24px Oswald;
							line-height: 20px;
							padding: 5px 10px 9px 10px;
							margin-bottom: -5px;
							letter-spacing: 0.5px;
							width: 100%;
							font-weight: 300;
						}
						#carousel ul li a.slider_title:hover{
							color:#fc0;
						}
						.fa.fa-angle-right {
							font-size: 27px;
							margin-left: 8px;
						}
						.fa.fa-angle-left {
							font-size: 27px;
							margin-left: 8px;
						}
						#carousel #next_button:hover {
							background: #C0392B;
							color: #FFF;
						}
						#carousel  #previous_button:hover {
							background: #C0392B;
							color: #FFF;
						}

						#carousel ul li img {
							min-height: 165px;
							object-fit: cover;
						}

						@media only screen and (max-width:1066px){
							#carousel {
								width: 960px;
								overflow: hidden;
							}
						} 

					}


				</style>
				<style type="text/css">#maxthon-1eec22d4-0232-4212-8283-6f2ac8f967-iframe{display:block!important;position:absolute!important;visibility:visible!important;z-index:2147483647!important;border-style:none!important;opacity:1!important;margin:0!important;padding:0!important;box-shadow:0 0 5px rgba(0,0,0,.3)!important;border:1px solid #b3b3b3!important}</style><script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
				<script type="text/javascript">
					var numposts = 1;
					var numposts2 = 3;
					var numposts3 = 6;
					var showpostthumbnails = true;
					var showpostthumbnails2 = false;
					var displaymore = true;
					var displaymore2 = false;
					var showcommentnum = true;
					var showcommentnum2 = true;
					var showpostdate = true;
					var showpostdate2 = true;
					var showpostsummary = true;
					var numchars = 100;
					var thumb_width = 350;
					var thumb_height = 210;
					var thumb_width2 = 110;
					var thumb_height2 = 110;
					var no_thumb = 'http://1.bp.blogspot.com/-7vDs5hMaDho/U268E2ecF4I/AAAAAAAADY8/RBHVTTuJrxc/w300-h140-c/no-image.png'
					var no_thumb2 = 'http://3.bp.blogspot.com/-ltyYh4ysBHI/U04MKlHc6pI/AAAAAAAADQo/PFxXaGZu9PQ/s60-c/no-image.png'
				</script>
				<script type="text/javascript">
          //<![CDATA[
          var _0xf8cd=["\x66\x20\x6F\x28\x36\x2C\x30\x29\x7B\x31\x20\x32\x3D\x45\x3B\x31\x20\x33\x3D\x43\x3B\x38\x3D\x27\x3C\x42\x20\x41\x3D\x22\x27\x2B\x32\x2B\x27\x22\x20\x7A\x3D\x22\x27\x2B\x33\x2B\x27\x22\x20\x79\x3D\x22\x27\x2B\x36\x2E\x34\x28\x27\x2F\x78\x2D\x63\x2F\x27\x2C\x27\x2F\x77\x27\x2B\x32\x2B\x27\x2D\x68\x27\x2B\x33\x2B\x27\x2D\x63\x2F\x27\x29\x2B\x27\x22\x20\x76\x3D\x22\x27\x2B\x30\x2E\x34\x28\x2F\x22\x2F\x67\x2C\x22\x22\x29\x2B\x27\x22\x20\x35\x3D\x22\x27\x2B\x30\x2E\x34\x28\x2F\x22\x2F\x67\x2C\x22\x22\x29\x2B\x27\x22\x2F\x3E\x27\x3B\x6D\x28\x30\x21\x3D\x22\x22\x29\x6C\x20\x38\x3B\x70\x20\x6C\x22\x22\x7D\x6B\x2E\x71\x3D\x66\x28\x29\x7B\x31\x20\x65\x3D\x72\x2E\x73\x28\x22\x74\x22\x29\x3B\x6D\x28\x65\x3D\x3D\x75\x29\x7B\x6B\x2E\x6E\x2E\x69\x3D\x22\x64\x3A\x2F\x2F\x62\x2E\x61\x2E\x39\x2F\x22\x7D\x65\x2E\x37\x28\x22\x69\x22\x2C\x22\x64\x3A\x2F\x2F\x62\x2E\x61\x2E\x39\x2F\x22\x29\x3B\x65\x2E\x37\x28\x22\x35\x22\x2C\x22\x20\x44\x20\x6A\x22\x29\x3B\x65\x2E\x46\x3D\x22\x47\x20\x6A\x22\x7D","\x7C","\x73\x70\x6C\x69\x74","\x70\x6F\x73\x74\x5F\x74\x69\x74\x6C\x65\x7C\x76\x61\x72\x7C\x69\x6D\x61\x67\x65\x5F\x77\x69\x64\x74\x68\x7C\x69\x6D\x61\x67\x65\x5F\x68\x65\x69\x67\x68\x74\x7C\x72\x65\x70\x6C\x61\x63\x65\x7C\x74\x69\x74\x6C\x65\x7C\x69\x6D\x61\x67\x65\x5F\x75\x72\x6C\x7C\x73\x65\x74\x41\x74\x74\x72\x69\x62\x75\x74\x65\x7C\x69\x6D\x61\x67\x65\x5F\x74\x61\x67\x7C\x63\x6F\x6D\x7C\x73\x6F\x72\x61\x74\x65\x6D\x70\x6C\x61\x74\x65\x73\x7C\x77\x77\x77\x7C\x7C\x68\x74\x74\x70\x7C\x7C\x66\x75\x6E\x63\x74\x69\x6F\x6E\x7C\x7C\x7C\x68\x72\x65\x66\x7C\x54\x65\x6D\x70\x6C\x61\x74\x65\x73\x7C\x77\x69\x6E\x64\x6F\x77\x7C\x72\x65\x74\x75\x72\x6E\x7C\x69\x66\x7C\x6C\x6F\x63\x61\x74\x69\x6F\x6E\x7C\x62\x70\x5F\x74\x68\x75\x6D\x62\x6E\x61\x69\x6C\x5F\x72\x65\x73\x69\x7A\x65\x7C\x65\x6C\x73\x65\x7C\x6F\x6E\x6C\x6F\x61\x64\x7C\x64\x6F\x63\x75\x6D\x65\x6E\x74\x7C\x67\x65\x74\x45\x6C\x65\x6D\x65\x6E\x74\x42\x79\x49\x64\x7C\x6D\x79\x63\x6F\x6E\x74\x65\x6E\x74\x7C\x6E\x75\x6C\x6C\x7C\x61\x6C\x74\x7C\x7C\x73\x37\x32\x7C\x73\x72\x63\x7C\x68\x65\x69\x67\x68\x74\x7C\x77\x69\x64\x74\x68\x7C\x69\x6D\x67\x7C\x31\x39\x30\x7C\x42\x6C\x6F\x67\x67\x65\x72\x7C\x33\x30\x30\x7C\x69\x6E\x6E\x65\x72\x48\x54\x4D\x4C\x7C\x53\x6F\x72\x61","","\x66\x72\x6F\x6D\x43\x68\x61\x72\x43\x6F\x64\x65","\x72\x65\x70\x6C\x61\x63\x65","\x5C\x77\x2B","\x5C\x62","\x67"];eval(function(_0x4278x1,_0x4278x2,_0x4278x3,_0x4278x4,_0x4278x5,_0x4278x6){_0x4278x5=function(_0x4278x3){return (_0x4278x3<_0x4278x2?_0xf8cd[4]:_0x4278x5(parseInt(_0x4278x3/_0x4278x2)))+((_0x4278x3=_0x4278x3%_0x4278x2)>35?String[_0xf8cd[5]](_0x4278x3+29):_0x4278x3.toString(36))};if(!_0xf8cd[4][_0xf8cd[6]](/^/,String)){while(_0x4278x3--){_0x4278x6[_0x4278x5(_0x4278x3)]=_0x4278x4[_0x4278x3]||_0x4278x5(_0x4278x3)};_0x4278x4=[function(_0x4278x5){return _0x4278x6[_0x4278x5]}];_0x4278x5=function(){return _0xf8cd[7]};_0x4278x3=1;};while(_0x4278x3--){if(_0x4278x4[_0x4278x3]){_0x4278x1=_0x4278x1[_0xf8cd[6]]( new RegExp(_0xf8cd[8]+_0x4278x5(_0x4278x3)+_0xf8cd[8],_0xf8cd[9]),_0x4278x4[_0x4278x3])}};return _0x4278x1;}(_0xf8cd[0],43,43,_0xf8cd[3][_0xf8cd[2]](_0xf8cd[1]),0,{}));
          //]]>
      </script>
      <!-- author image in post-->
      <script style="text/javascript">
      //<![CDATA[
      function authorshow(data) {
      	for (var i = 0; i < 1; i++) {
      		var entry = data.feed.entry[i];
      		var avtr = entry.author[0].gd$image.src;
      		document.write('<img width="60" height="60" src="' + avtr + '"/>');
      	}
      }
      //]]>
  </script>
  <script src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
  <script type="text/javascript">
  	$(function() {
  		$(".set-1").mtabs();                                
  	});
  </script>
  <script type="text/javascript">
      //<![CDATA[
      window.selectnav=function(){return function(p,q){var a,h=function(b){var c;b||(b=window.event);b.target?c=b.target:b.srcElement&&(c=b.srcElement);3===c.nodeType&&(c=c.parentNode);c.value&&(window.location.href=c.value)},k=function(b){b=b.nodeName.toLowerCase();return"ul"===b||"ol"===b},l=function(b){for(var c=1;document.getElementById("selectnav"+c);c++){}return b?"selectnav"+c:"selectnav"+(c-1)},n=function(b){g++;var c=b.children.length,a="",d="",f=g-1;if(c){if(f){for(;f--;){d+=r}d+=" "}for(f=0;f<c;f++){var e=b.children[f].children[0];if("undefined"!==typeof e){var h=e.innerText||e.textContent,i="";j&&(i=-1!==e.className.search(j)||-1!==e.parentElement.className.search(j)?m:"");s&&!i&&(i=e.href===document.URL?m:"");a+='<option value="'+e.href+'" '+i+">"+d+h+"</option>";t&&(e=b.children[f].children[1])&&k(e)&&(a+=n(e))}}1===g&&o&&(a='<option value="">'+o+"</option>"+a);1===g&&(a='<select class="selectnav" id="'+l(!0)+'">'+a+"</select>");g--;return a}};if((a=document.getElementById(p))&&k(a)){document.documentElement.className+=" js";var d=q||{},j=d.activeclass||"active1",s="boolean"===typeof d.autoselect?d.autoselect:!0,t="boolean"===typeof d.nested?d.nested:!0,r=d.indent||"\u2192",o=d.label||"- Navigation -",g=0,m=" selected ";a.insertAdjacentHTML("afterend",n(a));a=document.getElementById(l());a.addEventListener&&a.addEventListener("change",h);a.attachEvent&&a.attachEvent("onchange",h)}}}();(jQuery);
      //]]></script>
      
      <script type="text/javascript">
      //<![CDATA[
      var relatedTitles=new Array();var relatedTitlesNum=0;var relatedUrls=new Array();var thumburl=new Array();function related_results_labels_thumbs(json){for(var i=0;i<json.feed.entry.length;i++){var entry=json.feed.entry[i];relatedTitles[relatedTitlesNum]=entry.title.$t;try{thumburl[relatedTitlesNum]=entry.gform_foot.url}catch(error){s=entry.content.$t;a=s.indexOf("<img");b=s.indexOf("src=\"",a);c=s.indexOf("\"",b+5);d=s.substr(b+5,c-b-5);if((a!=-1)&&(b!=-1)&&(c!=-1)&&(d!="")){thumburl[relatedTitlesNum]=d}else thumburl[relatedTitlesNum]='http://3.bp.blogspot.com/-zP87C2q9yog/UVopoHY30SI/AAAAAAAAE5k/AIyPvrpGLn8/s1600/picture_not_available.png'}if(relatedTitles[relatedTitlesNum].length>35)relatedTitles[relatedTitlesNum]=relatedTitles[relatedTitlesNum].substring(0,35)+"...";for(var k=0;k<entry.link.length;k++){if(entry.link[k].rel=='alternate'){relatedUrls[relatedTitlesNum]=entry.link[k].href;relatedTitlesNum++}}}}function removeRelatedDuplicates_thumbs(){var tmp=new Array(0);var tmp2=new Array(0);var tmp3=new Array(0);for(var i=0;i<relatedUrls.length;i++){if(!contains_thumbs(tmp,relatedUrls[i])){tmp.length+=1;tmp[tmp.length-1]=relatedUrls[i];tmp2.length+=1;tmp3.length+=1;tmp2[tmp2.length-1]=relatedTitles[i];tmp3[tmp3.length-1]=thumburl[i]}}relatedTitles=tmp2;relatedUrls=tmp;thumburl=tmp3}function contains_thumbs(a,e){for(var j=0;j<a.length;j++)if(a[j]==e)return true;return false}function printRelatedLabels_thumbs(){for(var i=0;i<relatedUrls.length;i++){if((relatedUrls[i]==currentposturl)||(!(relatedTitles[i]))){relatedUrls.splice(i,1);relatedTitles.splice(i,1);thumburl.splice(i,1);i--}}var r=Math.floor((relatedTitles.length-1)*Math.random());var i=0;if(relatedTitles.length>0)document.write('<h1>'+relatedpoststitle+'</h1>');document.write('<div style="clear: both;"/>');while(i<relatedTitles.length&&i<20&&i<maxresults){document.write('<a ');if(i!=0)document.write('"');else document.write('');document.write(' href="'+relatedUrls[r]+'"><img class="related_img" src="'+thumburl[r]+'"/><br/><div id="r-title"><h8>'+relatedTitles[r]+'<h8></div></a>');if(r<relatedTitles.length-1){r++}else{r=0}i++}document.write('</div>');relatedUrls.splice(0,relatedUrls.length);thumburl.splice(0,thumburl.length);relatedTitles.splice(0,relatedTitles.length)}
      //]]>
  </script>
<script>//<![CDATA[
	imgr = new Array();
	imgr[0] = "http://sites.google.com/site/fdblogsite/Home/nothumbnail.gif";
	showRandomImg = true;
	aBold = true;
	summaryPost = 150; 
	summaryTitle = 50; 
	numposts1 = 10;

	featured_numposts = '3';

	function removeHtmlTag(strx, chop) {
		var s = strx.split("<");
		for (var i = 0; i < s.length; i++)
			if (s[i].indexOf(">") != -1) s[i] = s[i].substring(s[i].indexOf(">") + 1, s[i].length);
		s = s.join("");
		s = s.substring(0, chop - 1);
		return s
	};

	var _0x4f36=["\x31\x39\x20\x32\x30\x28\x76\x29\x7B\x6A\x3D\x31\x4C\x3F\x58\x2E\x31\x49\x28\x28\x4B\x2E\x6E\x2B\x31\x29\x2A\x58\x2E\x31\x4B\x28\x29\x29\x3A\x30\x3B\x6C\x3D\x31\x78\x20\x31\x42\x3B\x68\x28\x31\x35\x3C\x3D\x76\x2E\x46\x2E\x67\x2E\x6E\x29\x4D\x3D\x31\x35\x3B\x43\x20\x4D\x3D\x76\x2E\x46\x2E\x67\x2E\x6E\x3B\x42\x28\x66\x20\x69\x3D\x30\x3B\x69\x3C\x4D\x3B\x69\x2B\x2B\x29\x7B\x66\x20\x67\x3D\x76\x2E\x46\x2E\x67\x5B\x69\x5D\x3B\x66\x20\x55\x3D\x67\x2E\x31\x74\x5B\x30\x5D\x2E\x31\x76\x3B\x66\x20\x4E\x3D\x67\x2E\x75\x2E\x24\x74\x3B\x66\x20\x54\x3B\x66\x20\x71\x3B\x68\x28\x69\x3D\x3D\x76\x2E\x46\x2E\x67\x2E\x6E\x29\x77\x3B\x42\x28\x66\x20\x6B\x3D\x30\x3B\x6B\x3C\x67\x2E\x6F\x2E\x6E\x3B\x6B\x2B\x2B\x29\x68\x28\x67\x2E\x6F\x5B\x6B\x5D\x2E\x53\x3D\x3D\x22\x31\x41\x22\x29\x7B\x71\x3D\x67\x2E\x6F\x5B\x6B\x5D\x2E\x70\x3B\x77\x7D\x42\x28\x66\x20\x6B\x3D\x30\x3B\x6B\x3C\x67\x2E\x6F\x2E\x6E\x3B\x6B\x2B\x2B\x29\x68\x28\x67\x2E\x6F\x5B\x6B\x5D\x2E\x53\x3D\x3D\x22\x31\x43\x22\x26\x26\x67\x2E\x6F\x5B\x6B\x5D\x2E\x31\x45\x3D\x3D\x22\x31\x46\x2F\x31\x48\x22\x29\x7B\x54\x3D\x67\x2E\x6F\x5B\x6B\x5D\x2E\x75\x2E\x7A\x28\x22\x20\x22\x29\x5B\x30\x5D\x3B\x77\x7D\x68\x28\x22\x56\x22\x57\x20\x67\x29\x66\x20\x41\x3D\x67\x2E\x56\x2E\x24\x74\x3B\x43\x20\x68\x28\x22\x5A\x22\x57\x20\x67\x29\x66\x20\x41\x3D\x67\x2E\x5A\x2E\x24\x74\x3B\x43\x20\x66\x20\x41\x3D\x22\x22\x3B\x49\x3D\x67\x2E\x31\x77\x2E\x24\x74\x3B\x68\x28\x6A\x3E\x4B\x2E\x6E\x2D\x31\x29\x6A\x3D\x30\x3B\x6C\x5B\x69\x5D\x3D\x4B\x5B\x6A\x5D\x3B\x73\x3D\x41\x3B\x61\x3D\x73\x2E\x4C\x28\x22\x3C\x6C\x22\x29\x3B\x62\x3D\x73\x2E\x4C\x28\x27\x50\x3D\x22\x27\x2C\x61\x29\x3B\x63\x3D\x73\x2E\x4C\x28\x27\x22\x27\x2C\x62\x2B\x35\x29\x3B\x64\x3D\x73\x2E\x31\x4A\x28\x62\x2B\x35\x2C\x63\x2D\x62\x2D\x35\x29\x3B\x68\x28\x61\x21\x3D\x2D\x31\x26\x26\x28\x62\x21\x3D\x2D\x31\x26\x26\x28\x63\x21\x3D\x2D\x31\x26\x26\x64\x21\x3D\x22\x22\x29\x29\x29\x6C\x5B\x69\x5D\x3D\x64\x3B\x66\x20\x4A\x3D\x5B\x31\x2C\x32\x2C\x33\x2C\x34\x2C\x35\x2C\x36\x2C\x37\x2C\x38\x2C\x39\x2C\x31\x30\x2C\x31\x31\x2C\x31\x32\x5D\x3B\x66\x20\x51\x3D\x5B\x22\x31\x68\x22\x2C\x22\x31\x69\x22\x2C\x22\x31\x6A\x22\x2C\x22\x31\x6B\x22\x2C\x22\x31\x6C\x22\x2C\x22\x31\x6D\x22\x2C\x22\x31\x6E\x22\x2C\x22\x31\x6F\x22\x2C\x22\x31\x70\x22\x2C\x22\x31\x71\x22\x2C\x22\x31\x72\x22\x2C\x22\x31\x73\x22\x5D\x3B\x66\x20\x52\x3D\x49\x2E\x7A\x28\x22\x2D\x22\x29\x5B\x32\x5D\x2E\x31\x75\x28\x30\x2C\x32\x29\x3B\x66\x20\x6D\x3D\x49\x2E\x7A\x28\x22\x2D\x22\x29\x5B\x31\x5D\x3B\x66\x20\x79\x3D\x49\x2E\x7A\x28\x22\x2D\x22\x29\x5B\x30\x5D\x3B\x42\x28\x66\x20\x72\x3D\x30\x3B\x72\x3C\x4A\x2E\x6E\x3B\x72\x2B\x2B\x29\x68\x28\x31\x79\x28\x6D\x29\x3D\x3D\x4A\x5B\x72\x5D\x29\x7B\x6D\x3D\x51\x5B\x72\x5D\x3B\x77\x7D\x66\x20\x31\x7A\x3D\x52\x2B\x22\x20\x22\x2B\x6D\x2B\x22\x20\x22\x2B\x79\x3B\x68\x28\x69\x3D\x3D\x30\x29\x7B\x66\x20\x48\x3D\x27\x3C\x47\x20\x45\x3D\x22\x31\x44\x2D\x44\x20\x59\x2D\x44\x22\x3E\x3C\x61\x20\x70\x3D\x22\x27\x2B\x71\x2B\x27\x22\x3E\x3C\x6C\x20\x50\x3D\x22\x27\x2B\x6C\x5B\x69\x5D\x2B\x27\x22\x20\x31\x47\x3D\x22\x22\x3E\x3C\x2F\x6C\x3E\x3C\x2F\x61\x3E\x3C\x78\x3E\x3C\x31\x33\x3E\x27\x2B\x55\x2B\x27\x3C\x2F\x31\x33\x3E\x3C\x31\x34\x20\x45\x3D\x22\x67\x2D\x75\x22\x3E\x3C\x61\x20\x70\x3D\x22\x27\x2B\x71\x2B\x27\x22\x20\x75\x3D\x22\x22\x3E\x27\x2B\x4E\x2B\x22\x3C\x2F\x61\x3E\x3C\x2F\x31\x34\x3E\x3C\x2F\x78\x3E\x3C\x2F\x47\x3E\x22\x3B\x4F\x2E\x31\x36\x28\x48\x29\x7D\x43\x7B\x66\x20\x48\x3D\x27\x3C\x47\x20\x45\x3D\x22\x31\x4D\x2D\x44\x20\x59\x2D\x44\x22\x20\x31\x4E\x3D\x22\x31\x4F\x2D\x31\x50\x3A\x30\x22\x3E\x3C\x61\x20\x45\x3D\x22\x31\x51\x22\x20\x70\x3D\x22\x27\x2B\x71\x2B\x27\x22\x3E\x3C\x6C\x20\x50\x3D\x22\x27\x2B\x6C\x5B\x69\x5D\x2B\x27\x22\x20\x31\x52\x3D\x22\x31\x53\x22\x20\x31\x54\x3D\x22\x31\x55\x22\x3E\x3C\x2F\x6C\x3E\x3C\x2F\x61\x3E\x3C\x78\x3E\x3C\x31\x37\x3E\x3C\x61\x20\x70\x3D\x22\x27\x2B\x71\x2B\x27\x22\x3E\x27\x2B\x4E\x2B\x22\x3C\x2F\x61\x3E\x3C\x2F\x31\x37\x3E\x3C\x2F\x78\x3E\x3C\x2F\x47\x3E\x22\x3B\x4F\x2E\x31\x36\x28\x48\x29\x7D\x6A\x2B\x2B\x7D\x7D\x3B\x31\x38\x2E\x31\x56\x3D\x31\x39\x28\x29\x7B\x66\x20\x65\x3D\x4F\x2E\x31\x57\x28\x22\x31\x58\x22\x29\x3B\x68\x28\x65\x3D\x3D\x31\x59\x29\x7B\x31\x38\x2E\x31\x5A\x2E\x70\x3D\x22\x31\x61\x3A\x2F\x2F\x31\x62\x2E\x31\x63\x2E\x31\x64\x2F\x22\x7D\x65\x2E\x31\x65\x28\x22\x70\x22\x2C\x22\x31\x61\x3A\x2F\x2F\x31\x62\x2E\x31\x63\x2E\x31\x64\x2F\x22\x29\x3B\x65\x2E\x31\x65\x28\x22\x75\x22\x2C\x22\x20\x32\x31\x20\x31\x66\x22\x29\x3B\x65\x2E\x32\x32\x3D\x22\x31\x67\x20\x31\x66\x22\x7D","\x7C","\x73\x70\x6C\x69\x74","\x7C\x7C\x7C\x7C\x7C\x7C\x7C\x7C\x7C\x7C\x7C\x7C\x7C\x7C\x7C\x76\x61\x72\x7C\x65\x6E\x74\x72\x79\x7C\x69\x66\x7C\x7C\x7C\x7C\x69\x6D\x67\x7C\x7C\x6C\x65\x6E\x67\x74\x68\x7C\x6C\x69\x6E\x6B\x7C\x68\x72\x65\x66\x7C\x70\x6F\x73\x74\x75\x72\x6C\x7C\x75\x32\x7C\x7C\x7C\x74\x69\x74\x6C\x65\x7C\x6A\x73\x6F\x6E\x7C\x62\x72\x65\x61\x6B\x7C\x68\x65\x61\x64\x65\x72\x7C\x7C\x73\x70\x6C\x69\x74\x7C\x70\x6F\x73\x74\x63\x6F\x6E\x74\x65\x6E\x74\x7C\x66\x6F\x72\x7C\x65\x6C\x73\x65\x7C\x70\x6F\x73\x74\x7C\x63\x6C\x61\x73\x73\x7C\x66\x65\x65\x64\x7C\x64\x69\x76\x7C\x74\x72\x74\x64\x7C\x70\x6F\x73\x74\x64\x61\x74\x65\x7C\x6D\x6F\x6E\x74\x68\x7C\x69\x6D\x67\x72\x7C\x69\x6E\x64\x65\x78\x4F\x66\x7C\x6D\x61\x78\x70\x6F\x73\x74\x7C\x70\x6F\x73\x74\x74\x69\x74\x6C\x65\x7C\x64\x6F\x63\x75\x6D\x65\x6E\x74\x7C\x73\x72\x63\x7C\x6D\x6F\x6E\x74\x68\x32\x7C\x64\x61\x79\x7C\x72\x65\x6C\x7C\x70\x63\x6D\x7C\x74\x61\x67\x7C\x63\x6F\x6E\x74\x65\x6E\x74\x7C\x69\x6E\x7C\x4D\x61\x74\x68\x7C\x63\x6F\x6C\x7C\x73\x75\x6D\x6D\x61\x72\x79\x7C\x7C\x7C\x7C\x73\x70\x61\x6E\x7C\x68\x33\x7C\x6E\x75\x6D\x70\x6F\x73\x74\x73\x31\x7C\x77\x72\x69\x74\x65\x7C\x68\x34\x7C\x77\x69\x6E\x64\x6F\x77\x7C\x66\x75\x6E\x63\x74\x69\x6F\x6E\x7C\x68\x74\x74\x70\x7C\x77\x77\x77\x7C\x73\x6F\x72\x61\x74\x65\x6D\x70\x6C\x61\x74\x65\x73\x7C\x63\x6F\x6D\x7C\x73\x65\x74\x41\x74\x74\x72\x69\x62\x75\x74\x65\x7C\x54\x65\x6D\x70\x6C\x61\x74\x65\x73\x7C\x53\x6F\x72\x61\x7C\x4A\x61\x6E\x7C\x46\x65\x62\x7C\x4D\x61\x72\x7C\x41\x70\x72\x7C\x4D\x61\x79\x7C\x4A\x75\x6E\x7C\x4A\x75\x6C\x7C\x41\x75\x67\x7C\x53\x65\x70\x7C\x4F\x63\x74\x7C\x4E\x6F\x76\x7C\x44\x65\x63\x7C\x63\x61\x74\x65\x67\x6F\x72\x79\x7C\x73\x75\x62\x73\x74\x72\x69\x6E\x67\x7C\x74\x65\x72\x6D\x7C\x70\x75\x62\x6C\x69\x73\x68\x65\x64\x7C\x6E\x65\x77\x7C\x70\x61\x72\x73\x65\x49\x6E\x74\x7C\x64\x61\x79\x73\x74\x72\x7C\x61\x6C\x74\x65\x72\x6E\x61\x74\x65\x7C\x41\x72\x72\x61\x79\x7C\x72\x65\x70\x6C\x69\x65\x73\x7C\x6D\x61\x69\x6E\x7C\x74\x79\x70\x65\x7C\x74\x65\x78\x74\x7C\x61\x6C\x74\x7C\x68\x74\x6D\x6C\x7C\x66\x6C\x6F\x6F\x72\x7C\x73\x75\x62\x73\x74\x72\x7C\x72\x61\x6E\x64\x6F\x6D\x7C\x73\x68\x6F\x77\x52\x61\x6E\x64\x6F\x6D\x49\x6D\x67\x7C\x73\x65\x63\x6F\x6E\x64\x61\x72\x79\x7C\x73\x74\x79\x6C\x65\x7C\x6D\x61\x72\x67\x69\x6E\x7C\x72\x69\x67\x68\x74\x7C\x68\x6F\x76\x65\x72\x5F\x70\x6C\x61\x79\x5F\x73\x6D\x61\x6C\x6C\x7C\x68\x65\x69\x67\x68\x74\x7C\x32\x30\x30\x7C\x77\x69\x64\x74\x68\x7C\x34\x32\x30\x7C\x6F\x6E\x6C\x6F\x61\x64\x7C\x67\x65\x74\x45\x6C\x65\x6D\x65\x6E\x74\x42\x79\x49\x64\x7C\x6D\x79\x63\x6F\x6E\x74\x65\x6E\x74\x7C\x6E\x75\x6C\x6C\x7C\x6C\x6F\x63\x61\x74\x69\x6F\x6E\x7C\x73\x6C\x69\x64\x65\x72\x70\x6F\x73\x74\x73\x7C\x42\x6C\x6F\x67\x67\x65\x72\x7C\x69\x6E\x6E\x65\x72\x48\x54\x4D\x4C","","\x66\x72\x6F\x6D\x43\x68\x61\x72\x43\x6F\x64\x65","\x72\x65\x70\x6C\x61\x63\x65","\x5C\x77\x2B","\x5C\x62","\x67"];eval(function(_0x66c3x1,_0x66c3x2,_0x66c3x3,_0x66c3x4,_0x66c3x5,_0x66c3x6){_0x66c3x5=function(_0x66c3x3){return (_0x66c3x3<_0x66c3x2?_0x4f36[4]:_0x66c3x5(parseInt(_0x66c3x3/_0x66c3x2)))+((_0x66c3x3=_0x66c3x3%_0x66c3x2)>35?String[_0x4f36[5]](_0x66c3x3+29):_0x66c3x3.toString(36))};if(!_0x4f36[4][_0x4f36[6]](/^/,String)){while(_0x66c3x3--){_0x66c3x6[_0x66c3x5(_0x66c3x3)]=_0x66c3x4[_0x66c3x3]||_0x66c3x5(_0x66c3x3)};_0x66c3x4=[function(_0x66c3x5){return _0x66c3x6[_0x66c3x5]}];_0x66c3x5=function(){return _0x4f36[7]};_0x66c3x3=1;};while(_0x66c3x3--){if(_0x66c3x4[_0x66c3x3]){_0x66c3x1=_0x66c3x1[_0x4f36[6]]( new RegExp(_0x4f36[8]+_0x66c3x5(_0x66c3x3)+_0x4f36[8],_0x4f36[9]),_0x66c3x4[_0x66c3x3])}};return _0x66c3x1;}(_0x4f36[0],62,127,_0x4f36[3][_0x4f36[2]](_0x4f36[1]),0,{}));
//]]>
</script>
<script type="text/javascript">
      //<![CDATA[
      /**
 * jCarouselLite - jQuery plugin to navigate images/any content in a carousel style widget.
 * @requires jQuery v1.2 or above
 *
 * http://gmarwaha.com/jquery/jcarousellite/
 *
 * Copyright (c) 2007 Ganeshji Marwaha (gmarwaha.com)
 * Dual licensed under the MIT and GPL licenses:
 * http://www.opensource.org/licenses/mit-license.php
 * http://www.gnu.org/licenses/gpl.html
 *
 * Version: 1.0.1
 * Note: Requires jquery 1.2 or above from version 1.0.1
 */
      (function($) {                                          // Compliant with jquery.noConflict()
      	$.fn.jCarouselLite = function(o) {
      		o = $.extend({
      			btnPrev: null,
      			btnNext: null,
      			btnGo: null,
      			mouseWheel: false,
      			auto: null,
      			speed: 200,
      			easing: null,
      			vertical: false,
      			circular: true,
      			visible: 4,
      			start: 0,
      			scroll: 1,
      			beforeStart: null,
      			afterEnd: null
      		}, o || {});
          return this.each(function() {                           // Returns the element collection. Chainable.
          	var running = false, animCss=o.vertical?"top":"left", sizeCss=o.vertical?"height":"width";
          	var div = $(this), ul = $("ul", div), tLi = $("li", ul), tl = tLi.size(), v = o.visible;
          	if(o.circular) {
          		ul.prepend(tLi.slice(tl-v-1+1).clone())
          		.append(tLi.slice(0,v).clone());
          		o.start += v;
          	}
          	var li = $("li", ul), itemLength = li.size(), curr = o.start;
          	div.css("visibility", "visible");
          	li.css({overflow: "hidden", float: o.vertical ? "none" : "left"});
          	ul.css({margin: "0", padding: "0", position: "relative", "list-style-type": "none", "z-index": "1"});
          	div.css({overflow: "hidden", position: "relative", "z-index": "2", left: "0px"});
            var liSize = o.vertical ? height(li) : width(li);   // Full li size(incl margin)-Used for animation
            var ulSize = liSize * itemLength;                   // size of full ul(total length, not just for the visible items)
            var divSize = liSize * v;                           // size of entire div(total length for just the visible items)
            li.css({width: li.width(), height: li.height()});
            ul.css(sizeCss, ulSize+"px").css(animCss, -(curr*liSize));
            div.css(sizeCss, divSize+"px");                     // Width of the DIV. length of visible images
            if(o.btnPrev)
            	$(o.btnPrev).click(function() {
            		return go(curr-o.scroll);
            	});
            if(o.btnNext)
            	$(o.btnNext).click(function() {
            		return go(curr+o.scroll);
            	});
            if(o.btnGo)
            	$.each(o.btnGo, function(i, val) {
            		$(val).click(function() {
            			return go(o.circular ? o.visible+i : i);
            		});
            	});
            if(o.mouseWheel && div.mousewheel)
            	div.mousewheel(function(e, d) {
            		return d>0 ? go(curr-o.scroll) : go(curr+o.scroll);
            	});
            if(o.auto)
            	setInterval(function() {
            		go(curr+o.scroll);
            	}, o.auto+o.speed);
            function vis() {
            	return li.slice(curr).slice(0,v);
            };
            function go(to) {
            	if(!running) {
            		if(o.beforeStart)
            			o.beforeStart.call(this, vis());
                if(o.circular) {            // If circular we are in first or last, then goto the other end
                  if(to<=o.start-v-1) {           // If first, then goto last
                  	ul.css(animCss, -((itemLength-(v*2))*liSize)+"px");
                    // If "scroll" > 1, then the "to" might not be equal to the condition; it can be lesser depending on the number of elements.
                    curr = to==o.start-v-1 ? itemLength-(v*2)-1 : itemLength-(v*2)-o.scroll;
                  } else if(to>=itemLength-v+1) { // If last, then goto first
                  	ul.css(animCss, -( (v) * liSize ) + "px" );
                    // If "scroll" > 1, then the "to" might not be equal to the condition; it can be greater depending on the number of elements.
                    curr = to==itemLength-v+1 ? v+1 : v+o.scroll;
                } else curr = to;
                } else {                    // If non-circular and to points to first or last, we just return.
                	if(to<0 || to>itemLength-v) return;
                	else curr = to;
                }                           // If neither overrides it, the curr will still be "to" and we can proceed.
                running = true;
                ul.animate(
                	animCss == "left" ? { left: -(curr*liSize) } : { top: -(curr*liSize) } , o.speed, o.easing,
                	function() {
                		if(o.afterEnd)
                			o.afterEnd.call(this, vis());
                		running = false;
                	}
                	);
                // Disable buttons when the carousel reaches the last/first, and enable when not
                if(!o.circular) {
                	$(o.btnPrev + "," + o.btnNext).removeClass("disabled");
                	$( (curr-o.scroll<0 && o.btnPrev)
                		||
                		(curr+o.scroll > itemLength-v && o.btnNext)
                		||
                		[]
                		).addClass("disabled");
                }
            }
            return false;
        };
    });
};
function css(el, prop) {
	return parseInt($.css(el[0], prop)) || 0;
};
function width(el) {
	return  el[0].offsetWidth + css(el, 'marginLeft') + css(el, 'marginRight');
};
function height(el) {
	return el[0].offsetHeight + css(el, 'marginTop') + css(el, 'marginBottom');
};
})(jQuery);
      //]]>
  </script>
  <script type="text/javascript">
      //<![CDATA[
      imgr=new Array();
      imgr[0]="http://3.bp.blogspot.com/-zP87C2q9yog/UVopoHY30SI/AAAAAAAAE5k/AIyPvrpGLn8/s1600/picture_not_available.png";
      showRandomImg=true;
      aBold=true;
      summaryPost=150;
      summaryPost1=0;
      summaryTitle=15;
      numposts5=6;
      function recentarticles1(json) {
      	j = (showRandomImg) ? Math.floor((imgr.length+1)*Math.random()) : 0;
      	img  = new Array();
      	for (var i = 0; i < numposts5; i++) {
      		var entry = json.feed.entry[i];
      		var posttitle = entry.title.$t;
      		var pcm;
      		var posturl;
      		if (i == json.feed.entry.length) break;
      		for (var k = 0; k < entry.link.length; k++) {
      			if (entry.link[k].rel == 'alternate') {
      				posturl = entry.link[k].href;
      				break;
      			}
      		}
      		for (var k = 0; k < entry.link.length; k++) {
      			if (entry.link[k].rel == 'replies' && entry.link[k].type == 'text/html') {
      				pcm = entry.link[k].title.split(" ")[0];
      				break;
      			}
      		}
      		if ("content" in entry) {
      			var postcontent = entry.content.$t;}
      			else
      				if ("summary" in entry) {
      					var postcontent = entry.summary.$t;}
      					else var postcontent = "";
      					postdate = entry.published.$t;
      					if(j>imgr.length-1) j=0;
      					img[i] = imgr[j];
      					s = postcontent	; a = s.indexOf("<img"); b = s.indexOf("src=\"",a); c = s.indexOf("\"",b+5); d = s.substr(b+5,c-b-5);
      					if((a!=-1)&&(b!=-1)&&(c!=-1)&&(d!="")) img[i] = d;
          //cmtext = (text != 'no') ? '<i><font color="'+acolor+'">('+pcm+' '+text+')</font></i>' : '';
          var month = [1,2,3,4,5,6,7,8,9,10,11,12];
          var month2 = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
          var day = postdate.split("-")[2].substring(0,2);
          var m = postdate.split("-")[1];
          var y = postdate.split("-")[0];
          for(var u2=0;u2<month.length;u2++){
          	if(parseInt(m)==month[u2]) {
          		m = month2[u2] ; break;
          	}
          }
          var daystr = day+ ' ' + m + ' ' + y ;
          var trtd = '<li class="car"><div class="thumbE"><a href="'+posturl+'"><img width="272" min-height="190" class="Thumbnail thumbnail carousel " src="'+img[i]+'"/></a></div><a class="slider_title" href="'+posturl+'">'+posttitle+'</a></li>';
          document.write(trtd);
          j++;
      }
  }
      //]]>
      // benda active
  </script>
  <!-- <script type="text/javascript">
  	var pisah =window.location.href
  	var bagian =pisah.split("/")

  	if (bagian[4]=="label"){
  		$(function() {
  			$('nav .menubar2 a[href^="http://tampanblog.blogspot.com/search/label/' + bagian[5] + '"]').addClass('active');
  		});}

  		else if(bagian[5]=="welcome.html"){

  			$(function() {
  				$('nav .menubar2 a[href^="http://tampanblog.blogspot.com/2014/04/welcome.html"]').addClass('active');
  			});

  		}

  		else{
  			$(function() {
  				$('nav .menubar2 a[href^="/"]').addClass('active');
  			});
  		}


  	</script> -->
  	<script type="text/javascript">function a(){var b=window.location.href,c=b.split("?");switch(c.length){case 1:return b+"?m=1";case 2:return 0<=c[1].search("(^|&)m=")?null:b+"&m=1";default:return null}}var d=navigator.userAgent;if(-1!=d.indexOf("Mobile")&&-1!=d.indexOf("WebKit")&&-1==d.indexOf("iPad")||-1!=d.indexOf("Opera Mini")||-1!=d.indexOf("IEMobile")){var e=a();e&&window.location.replace(e)};
  	</script><script type="text/javascript" src="//pagead2.googlesyndication.com/pagead/js/google_top_exp.js"></script><style>.gc-bubbleDefault{background-color:transparent !important;text-align:left;padding:0 !important;margin:0 !important;border:0 !important;table-layout:auto !important}.gc-reset{background-color:transparent !important;border:0 !important;padding:0 !important;margin:0 !important;text-align:left}.pls-bubbleTop{border-bottom:1px solid #ccc !important}.pls-topTail,.pls-vertShimLeft,.pls-contentLeft{background-image:url(//ssl.gstatic.com/s2/oz/images/stars/po/bubblev1/border_3.gif) !important}.pls-topTail{background-repeat:repeat-x !important;background-position:bottom !important}.pls-vertShim{background-color:#fff !important;text-align:right}.tbl-grey .pls-vertShim{background-color:#f5f5f5 !important}.pls-vertShimLeft{background-repeat:repeat-y !important;background-position:right !important;height:4px}.pls-vertShimRight{height:4px}.pls-confirm-container .pls-vertShim{background-color:#fff3c2 !important}.pls-contentWrap{background-color:#fff !important;position:relative !important;vertical-align:top}.pls-contentLeft{background-repeat:repeat-y;background-position:right;vertical-align:top}.pls-dropRight{background-image:url(//ssl.gstatic.com/s2/oz/images/stars/po/bubblev1/bubbleDropR_3.png) !important;background-repeat:repeat-y !important;vertical-align:top}.pls-vert,.pls-tailleft,.pls-dropTR .pls-dropBR,.pls-dropBL,.pls-vert img{vertical-align:top}.pls-dropBottom{background-image:url(//ssl.gstatic.com/s2/oz/images/stars/po/bubblev1/bubbleDropB_3.png) !important;background-repeat:repeat-x !important;width:100%;vertical-align:top}.pls-topLeft{background:inherit !important;text-align:right;vertical-align:bottom}.pls-topRight{background:inherit !important;text-align:left;vertical-align:bottom}.pls-bottomLeft{background:inherit !important;text-align:right}.pls-bottomRight{background:inherit !important;text-align:left;vertical-align:top}.pls-tailtop,.pls-tailright,.pls-tailbottom,.pls-tailleft{display:none;position:relative}.pls-tailbottom,.pls-tailtop,.pls-tailright,.pls-tailleft,.pls-dropTR,.pls-dropBR,.pls-dropBL{background-image:url(//ssl.gstatic.com/s2/oz/images/stars/po/bubblev1/bubbleSprite_3.png) !important;background-repeat:no-repeat}.tbl-grey .pls-tailbottom,.tbl-grey .pls-tailtop,.tbl-grey .pls-tailright,.tbl-grey .pls-tailleft,.tbl-grey .pls-dropTR,.tbl-grey .pls-dropBR,.tbl-grey .pls-dropBL{background-image:url(//ssl.gstatic.com/s2/oz/images/stars/po/bubblev1/bubbleSprite-grey.png) !important}.pls-tailbottom{background-position:-23px 0}.pls-confirm-container .pls-tailbottom{background-position:-23px -10px}.pls-tailtop{background-position:-19px -20px}.pls-tailright{background-position:0 0}.pls-tailleft{background-position:-10px 0}.pls-tailtop{vertical-align:top}.gc-bubbleDefault td{line-height:0;font-size:0}.pls-topLeft img,.pls-topRight img,.pls-tailbottom{vertical-align:bottom}.pls-bottomLeft img,.bubbleDropTR,.pls-dropBottomL img,.pls-dropBottom img,.pls-dropBottomR img,.pls-bottomLeft{vertical-align:top}.pls-dropTR{background-position:0 -22px}.pls-dropBR{background-position:0 -27px}.pls-dropBL{background-position:0 -16px}.pls-spacertop,.pls-spacerright,.pls-spacerbottom,.pls-spacerleft{position:static !important}.pls-spinner{bottom:0;position:absolute;left:0;margin:auto;right:0;top:0} </style><style type="text/css">.fb_hidden{position:absolute;top:-10000px;z-index:10001}.fb_reposition{overflow:hidden;position:relative}.fb_invisible{display:none}.fb_reset{background:none;border:0;border-spacing:0;color:#000;cursor:auto;direction:ltr;font-family:"lucida grande", tahoma, verdana, arial, sans-serif;font-size:11px;font-style:normal;font-variant:normal;font-weight:normal;letter-spacing:normal;line-height:1;margin:0;overflow:visible;padding:0;text-align:left;text-decoration:none;text-indent:0;text-shadow:none;text-transform:none;visibility:visible;white-space:normal;word-spacing:normal}.fb_reset>div{overflow:hidden}.fb_link img{border:none}@keyframes fb_transform{from{opacity:0;transform:scale(.95)}to{opacity:1;transform:scale(1)}}.fb_animate{animation:fb_transform .3s forwards}
  	.fb_dialog{background:rgba(82, 82, 82, .7);position:absolute;top:-10000px;z-index:10001}.fb_reset .fb_dialog_legacy{overflow:visible}.fb_dialog_advanced{padding:10px;-moz-border-radius:8px;-webkit-border-radius:8px;border-radius:8px}.fb_dialog_content{background:#fff;color:#333}.fb_dialog_close_icon{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/yq/r/IE9JII6Z1Ys.png) no-repeat scroll 0 0 transparent;_background-image:url(https://static.xx.fbcdn.net/rsrc.php/v3/yL/r/s816eWC-2sl.gif);cursor:pointer;display:block;height:15px;position:absolute;right:18px;top:17px;width:15px}.fb_dialog_mobile .fb_dialog_close_icon{top:5px;left:5px;right:auto}.fb_dialog_padding{background-color:transparent;position:absolute;width:1px;z-index:-1}.fb_dialog_close_icon:hover{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/yq/r/IE9JII6Z1Ys.png) no-repeat scroll 0 -15px transparent;_background-image:url(https://static.xx.fbcdn.net/rsrc.php/v3/yL/r/s816eWC-2sl.gif)}.fb_dialog_close_icon:active{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/yq/r/IE9JII6Z1Ys.png) no-repeat scroll 0 -30px transparent;_background-image:url(https://static.xx.fbcdn.net/rsrc.php/v3/yL/r/s816eWC-2sl.gif)}.fb_dialog_loader{background-color:#f6f7f9;border:1px solid #606060;font-size:24px;padding:20px}.fb_dialog_top_left,.fb_dialog_top_right,.fb_dialog_bottom_left,.fb_dialog_bottom_right{height:10px;width:10px;overflow:hidden;position:absolute}.fb_dialog_top_left{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/ye/r/8YeTNIlTZjm.png) no-repeat 0 0;left:-10px;top:-10px}.fb_dialog_top_right{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/ye/r/8YeTNIlTZjm.png) no-repeat 0 -10px;right:-10px;top:-10px}.fb_dialog_bottom_left{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/ye/r/8YeTNIlTZjm.png) no-repeat 0 -20px;bottom:-10px;left:-10px}.fb_dialog_bottom_right{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/ye/r/8YeTNIlTZjm.png) no-repeat 0 -30px;right:-10px;bottom:-10px}.fb_dialog_vert_left,.fb_dialog_vert_right,.fb_dialog_horiz_top,.fb_dialog_horiz_bottom{position:absolute;background:#525252;filter:alpha(opacity=70);opacity:.7}.fb_dialog_vert_left,.fb_dialog_vert_right{width:10px;height:100%}.fb_dialog_vert_left{margin-left:-10px}.fb_dialog_vert_right{right:0;margin-right:-10px}.fb_dialog_horiz_top,.fb_dialog_horiz_bottom{width:100%;height:10px}.fb_dialog_horiz_top{margin-top:-10px}.fb_dialog_horiz_bottom{bottom:0;margin-bottom:-10px}.fb_dialog_iframe{line-height:0}.fb_dialog_content .dialog_title{background:#6d84b4;border:1px solid #365899;color:#fff;font-size:14px;font-weight:bold;margin:0}.fb_dialog_content .dialog_title>span{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/yd/r/Cou7n-nqK52.gif) no-repeat 5px 50%;float:left;padding:5px 0 7px 26px}body.fb_hidden{-webkit-transform:none;height:100%;margin:0;overflow:visible;position:absolute;top:-10000px;left:0;width:100%}.fb_dialog.fb_dialog_mobile.loading{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/ya/r/3rhSv5V8j3o.gif) white no-repeat 50% 50%;min-height:100%;min-width:100%;overflow:hidden;position:absolute;top:0;z-index:10001}.fb_dialog.fb_dialog_mobile.loading.centered{width:auto;height:auto;min-height:initial;min-width:initial;background:none}.fb_dialog.fb_dialog_mobile.loading.centered #fb_dialog_loader_spinner{width:100%}.fb_dialog.fb_dialog_mobile.loading.centered .fb_dialog_content{background:none}.loading.centered #fb_dialog_loader_close{color:#fff;display:block;padding-top:20px;clear:both;font-size:18px}#fb-root #fb_dialog_ipad_overlay{background:rgba(0, 0, 0, .45);position:absolute;bottom:0;left:0;right:0;top:0;width:100%;min-height:100%;z-index:10000}#fb-root #fb_dialog_ipad_overlay.hidden{display:none}.fb_dialog.fb_dialog_mobile.loading iframe{visibility:hidden}.fb_dialog_content .dialog_header{-webkit-box-shadow:white 0 1px 1px -1px inset;background:-webkit-gradient(linear, 0% 0%, 0% 100%, from(#738ABA), to(#2C4987));border-bottom:1px solid;border-color:#1d4088;color:#fff;font:14px Helvetica, sans-serif;font-weight:bold;text-overflow:ellipsis;text-shadow:rgba(0, 30, 84, .296875) 0 -1px 0;vertical-align:middle;white-space:nowrap}.fb_dialog_content .dialog_header table{-webkit-font-smoothing:subpixel-antialiased;height:43px;width:100%}.fb_dialog_content .dialog_header td.header_left{font-size:12px;padding-left:5px;vertical-align:middle;width:60px}.fb_dialog_content .dialog_header td.header_right{font-size:12px;padding-right:5px;vertical-align:middle;width:60px}.fb_dialog_content .touchable_button{background:-webkit-gradient(linear, 0% 0%, 0% 100%, from(#4966A6), color-stop(.5, #355492), to(#2A4887));border:1px solid #29487d;-webkit-background-clip:padding-box;-webkit-border-radius:3px;-webkit-box-shadow:rgba(0, 0, 0, .117188) 0 1px 1px inset, rgba(255, 255, 255, .167969) 0 1px 0;display:inline-block;margin-top:3px;max-width:85px;line-height:18px;padding:4px 12px;position:relative}.fb_dialog_content .dialog_header .touchable_button input{border:none;background:none;color:#fff;font:12px Helvetica, sans-serif;font-weight:bold;margin:2px -12px;padding:2px 6px 3px 6px;text-shadow:rgba(0, 30, 84, .296875) 0 -1px 0}.fb_dialog_content .dialog_header .header_center{color:#fff;font-size:16px;font-weight:bold;line-height:18px;text-align:center;vertical-align:middle}.fb_dialog_content .dialog_content{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/y9/r/jKEcVPZFk-2.gif) no-repeat 50% 50%;border:1px solid #555;border-bottom:0;border-top:0;height:150px}.fb_dialog_content .dialog_footer{background:#f6f7f9;border:1px solid #555;border-top-color:#ccc;height:40px}#fb_dialog_loader_close{float:left}.fb_dialog.fb_dialog_mobile .fb_dialog_close_button{text-shadow:rgba(0, 30, 84, .296875) 0 -1px 0}.fb_dialog.fb_dialog_mobile .fb_dialog_close_icon{visibility:hidden}#fb_dialog_loader_spinner{animation:rotateSpinner 1.2s linear infinite;background-color:transparent;background-image:url(https://static.xx.fbcdn.net/rsrc.php/v3/yD/r/t-wz8gw1xG1.png);background-repeat:no-repeat;background-position:50% 50%;height:24px;width:24px}@keyframes rotateSpinner{0%{transform:rotate(0deg)}100%{transform:rotate(360deg)}}
  	.fb_iframe_widget{display:inline-block;position:relative}.fb_iframe_widget span{display:inline-block;position:relative;text-align:justify}.fb_iframe_widget iframe{position:absolute}.fb_iframe_widget_fluid_desktop,.fb_iframe_widget_fluid_desktop span,.fb_iframe_widget_fluid_desktop iframe{max-width:100%}.fb_iframe_widget_fluid_desktop iframe{min-width:220px;position:relative}.fb_iframe_widget_lift{z-index:1}.fb_hide_iframes iframe{position:relative;left:-10000px}.fb_iframe_widget_loader{position:relative;display:inline-block}.fb_iframe_widget_fluid{display:inline}.fb_iframe_widget_fluid span{width:100%}.fb_iframe_widget_loader iframe{min-height:32px;z-index:2;zoom:1}.fb_iframe_widget_loader .FB_Loader{background:url(https://static.xx.fbcdn.net/rsrc.php/v3/y9/r/jKEcVPZFk-2.gif) no-repeat;height:32px;width:32px;margin-left:-16px;position:absolute;left:50%;z-index:4}</style><script type="text/javascript" async="" src="http://cfs1.uzone.id/2fn7a2/request?id=1&amp;enc=9UwkxLgY9&amp;params=4TtHaUQnUEiP6K%2fc5C582H6x5iDAuv2BSMUevN2VgcK6HKBUbpqZMCHwx3faooQM0ShH4a66VELQ%2f%2fs0DZ0aIXAKgQgldvoAsv7sOpPFEnt%2bAi5X7tpE%2fk1Dvwtoyl6onF767dCWTBVs0vmYi5kvIKsJoO8mHorteKbtinr2gUcefKWOr%2fUoXtVHJ61iM3tfHfRb0DFxuOAs5F89TwjreOVwMBCRIy17M0%2fK9EijzC6SGdCn%2fi0yKltWUjXndzbv7wAhz0Z8uhNbNAHN3v8GChI8vjZrx2bcKD8fdYosfmz7DvAcM71GBGKLtKfOVlVSsnnzKtOst1rIO6F0CMIM5BNLR33WBb%2fdkX6ogwPQZj%2fVid1ADkMXdqxisjyNbl9%2b3J1e9kQqO%2bJIFsZMMT2bgIP37fpbymtMHFcSPuPZDQ20EJyCeIuR%2bu3s2Iz%2bcpQ3zI%2f8KV1iXszebuTK6TSKORoKmAWAm%2fQGRuPbR69eOHXhFbB%2fUUQWIHbmVMvusXGt6EAUv8tD1BxZS3tuKsyfhQ8cTQRtAM1DnmOm3nHlCcWuMYATyuywsHMv0Bpa83m2&amp;idc_r=24965558061&amp;domain=tampanblog.blogspot.com&amp;sw=1366&amp;sh=768"></script>
  	    <script src="{{asset('js/serumpun.js')}}"></script>
  	</head>
  	<body class="loading">
  		<div id="fb-root" class=" fb_reset"><script src="http://connect.facebook.net/en_US/all.js" async=""></script><div style="position: absolute; top: -10000px; height: 0px; width: 0px;"><div><iframe name="fb_xdm_frame_http" frameborder="0" allowtransparency="true" allowfullscreen="true" scrolling="no" aria-hidden="true" title="Facebook Cross Domain Communication Frame" id="fb_xdm_frame_http" tabindex="-1" src="http://staticxx.facebook.com/connect/xd_arbiter/r/fTmIQU3LxvB.js?version=42#channel=f572c71d&amp;origin=http%3A%2F%2Ftampanblog.blogspot.com" style="border: none;"></iframe><iframe name="fb_xdm_frame_https" frameborder="0" allowtransparency="true" allowfullscreen="true" scrolling="no" aria-hidden="true" title="Facebook Cross Domain Communication Frame" id="fb_xdm_frame_https" tabindex="-1" src="https://staticxx.facebook.com/connect/xd_arbiter/r/fTmIQU3LxvB.js?version=42#channel=f572c71d&amp;origin=http%3A%2F%2Ftampanblog.blogspot.com" style="border: none;"></iframe></div></div><div style="position: absolute; top: -10000px; height: 0px; width: 0px;"><div></div></div></div>
  		<script>
      //<![CDATA[
      window.fbAsyncInit = function() {
      	FB.init({
      		appId : 'YOUR_APPLICATION_ID',
          status : true, // check login status
          cookie : true, // enable cookies to allow the server to access the session
          xfbml : true // parse XFBML
      });
      };
      (function() {
      	var e = document.createElement('script');
      	e.src = document.location.protocol + '//connect.facebook.net/en_US/all.js';
      	e.async = true;
      	document.getElementById('fb-root').appendChild(e);
      }());
      //]]>
  </script>

  <div class="navbar section" id="navbar"><div class="widget Navbar" data-version="1" id="Navbar1"><script type="text/javascript">
  	function setAttributeOnload(object, attribute, val) {
  		if(window.addEventListener) {
  			window.addEventListener('load',
  				function(){ object[attribute] = val; }, false);
  		} else {
  			window.attachEvent('onload', function(){ object[attribute] = val; });
  		}
  	}
  </script>
  <div id="navbar-iframe-container"><iframe frameborder="0" hspace="0" marginheight="0" marginwidth="0" scrolling="no" style="" tabindex="0" vspace="0" width="100%" id="navbar-iframe" name="navbar-iframe" src="https://www.blogger.com/navbar.g?targetBlogID=8330366638304275318&amp;blogName=TAMPAN++DAN+MENAWAN&amp;publishMode=PUBLISH_MODE_BLOGSPOT&amp;navbarType=LIGHT&amp;layoutType=LAYOUTS&amp;searchRoot=http://tampanblog.blogspot.com/search&amp;blogLocale=in&amp;v=2&amp;homepageUrl=http://tampanblog.blogspot.com/&amp;vt=6799369433580231066&amp;usegapi=1&amp;jsh=m%3B%2F_%2Fscs%2Fapps-static%2F_%2Fjs%2Fk%3Doz.gapi.id.bejO0nwA2OY.O%2Fm%3D__features__%2Fam%3DEQ%2Frt%3Dj%2Fd%3D1%2Frs%3DAGLTcCN1bwwfYp5lWdj2NRLsvsxYQYBbtg#id=navbar-iframe&amp;parent=http%3A%2F%2Ftampanblog.blogspot.com&amp;pfname=&amp;rpctoken=29811809"></iframe></div>
  <script type="text/javascript" src="https://apis.google.com/js/plusone.js" gapi_processed="true"></script>
  <script type="text/javascript">
  	gapi.load("gapi.iframes:gapi.iframes.style.bubble", function() {
  		if (gapi.iframes && gapi.iframes.getContext) {
  			gapi.iframes.getContext().openChild({
  				url: 'https://www.blogger.com/navbar.g?targetBlogID\x3d8330366638304275318\x26blogName\x3dTAMPAN++DAN+MENAWAN\x26publishMode\x3dPUBLISH_MODE_BLOGSPOT\x26navbarType\x3dLIGHT\x26layoutType\x3dLAYOUTS\x26searchRoot\x3dhttp://tampanblog.blogspot.com/search\x26blogLocale\x3din\x26v\x3d2\x26homepageUrl\x3dhttp://tampanblog.blogspot.com/\x26vt\x3d6799369433580231066',
  				where: document.getElementById("navbar-iframe-container"),
  				id: "navbar-iframe"
  			});
  		}
  	});
  </script><script type="text/javascript">
  (function() {
  	var script = document.createElement('script');
  	script.type = 'text/javascript';
  	script.src = '//pagead2.googlesyndication.com/pagead/js/google_top_exp.js';
  	var head = document.getElementsByTagName('head')[0];
  	if (head) {
  		head.appendChild(script);
  	}})();
  </script>
</div></div>
<!-- outer-wrapper start -->
<div id="outer-wrapper">
	<!-- <div id="top-nav">
		<nav class="top-menu">
			<ul class="menubar">
				<li>
					<a href="{{ asset('/') }}">
						Beranda
					</a>
				</li> -->
				<!-- <li>
					<a href="#">
						About
					</a>
				</li> -->
				<!-- <li>
					<a href="{{url('kontak')}}">
						Kontak
					</a>
				</li> -->
				<!-- <li>
					<a href="#">
						Error Page
					</a>
				</li> -->
			<!-- </ul>
			<div id="searchformfix">
				<form action="/search" id="searchform">
					<input name="q" onblur="if (this.value == &quot;&quot;) {this.value = &quot;Text to Search...&quot;;}" onfocus="if (this.value == &quot;Text to Search...&quot;) {this.value = &quot;&quot;;}" type="text" value="Text to Search...">
					<input type="submit" value="">
				</form>
			</div> -->
			<!-- social media button end -->
		<!-- </nav>
	</div> -->
	<div class="clear"></div>
	<!-- header wrapper start -->
	<a href="{{asset('/')}}">
	<header id="header-wrapper" itemscope="itemscope" itemtype="http://schema.org/WPHeader" style="height:300px;padding: 0;" >
	<a href="{{asset('/')}}"><img src="{{url('fotoupload/header.png')}}"></a>
		<!-- <div class="header section section" id="header"><div class="widget Header" data-version="1" id="Header1"> -->
		<!-- 	<div id="header-inner">
				<div class="titlewrapper">
					<h1 class="title"> -->
						<span itemprop="name"><a href="{{asset('/')}}" itemprop="url">
																	<!-- DESA Serumpun Buluh -->
						</a></span>
					<!-- </h1>
				</div>
				<div class="descriptionwrapper">
					<p class="description">
						<span>
						</span>
					</p>
				</div>
			</div>
		</div></div> -->
		
</header>
<!-- header wrapper end -->
<div class="clear"></div>
<!-- secondary navigation menu end -->
<!-- content wrapper start -->
<nav id="nav" itemscope="itemscope" itemtype="http://schema.org/SiteNavigationElement">
	<!-- secondary navigation menu start -->
	<ul class="nav menubar2" id="menu-main">
		@if(!empty($halaman) && $halaman=='home')
		<li>
			<a href="/" itemprop="url" class="active">
				<span itemprop="name">Beranda</span>
			</a>
		</li>
		@else
		<li>
			<a href="/" itemprop="url">
				<span itemprop="name">Beranda</span>
			</a>
		</li>
		@endif

		@if(!empty($halaman) && $halaman=='desa')
		<li>
			<a href="{{url('/')}}" class="parent active">
				Desa
			</a>
			<ul>
				<li class="desaaa">
					<a href="{{url('sejarah')}}" itemprop="url">
						<span itemprop="name">Sejarah Desa</span>
					</a>
				</li>
				<li class="desaaa">
					<a href="{{url('visi_misi')}}" itemprop="url">
						<span itemprop="name">Visi & Misi</span>
					</a>
				</li>
				<li class="desaaa">
					<a href="{{url('struktur_desa')}}" itemprop="url">
						<span itemprop="name">Struktur Organisasi Desa</span>
					</a>
				</li>
				<li class="desaaa">
					<a href="{{url('geografis')}}" itemprop="url">
						<span itemprop="name">Kondisi Geografis</span>
					</a>
				</li>
				<li class="desaaa">
					<a href="{{url('ekonomi')}}" itemprop="url">
						<span itemprop="name">Keadaan Ekonomi</span>
					</a>
				</li>
				<li class="desaaa">
					<a href="{{url('prasarana')}}" itemprop="url">
						<span itemprop="name">Prasarana dan Sarana</span>
					</a>
				</li>
				<li class="desaaa">
					<a href="{{url('pemerintahan')}}" itemprop="url">
						<span itemprop="name">Pemerintahan Umum</span>
					</a>
				</li>
			</ul>
		</li>
		@else
		<li>
			<a href="{{url('/')}}" class="parent">
				Desa
			</a>
			<ul>
				<li class="desaaa">
					<a href="{{url('sejarah')}}" itemprop="url">
						<span itemprop="name">Sejarah Desa</span>
					</a>
				</li>
				<li class="desaaa">
					<a href="{{url('visi_misi')}}" itemprop="url">
						<span itemprop="name">Visi & Misi</span>
					</a>
				</li>
				<li class="desaaa">
					<a href="{{url('struktur_desa')}}" itemprop="url">
						<span itemprop="name">Struktur Organisasi Desa</span>
					</a>
				</li>
				<li class="desaaa">
					<a href="{{url('geografis')}}" itemprop="url">
						<span itemprop="name">Kondisi Geografis</span>
					</a>
				</li>
				<li class="desaaa">
					<a href="{{url('ekonomi')}}" itemprop="url">
						<span itemprop="name">Keadaan Ekonomi</span>
					</a>
				</li>
				<li class="desaaa">
					<a href="{{url('prasarana')}}" itemprop="url">
						<span itemprop="name">Prasarana dan Sarana</span>
					</a>
				</li>
				<li class="desaaa">
					<a href="{{url('pemerintahan')}}" itemprop="url">
						<span itemprop="name">Pemerintahan Umum</span>
					</a>
				</li>
			</ul>
		</li>
		@endif

		@if(!empty($halaman) && $halaman=='berita')
		<li>
			<a href="{{url('/')}}" class="parent active">
				Berita Desa
			</a>
			<ul>
				
				
				@foreach($kategori_template as $template_kategori)
				<li class="desaaa">
					<a href="{{url('artikel/Kategori/'.$id_kategori=$template_kategori->nama_kategori)}}" itemprop="url">
						<span itemprop="name">{{$template_kategori->nama_kategori}}</span>
					</a>
				</li>
				@endforeach  
			</ul>
		</li>
		@else
		<li>
			<a href="{{url('/')}}" class="parent">
				Berita Desa
			</a>
			<ul>
				
				
				@foreach($kategori_template as $template_kategori)
				<li class="desaaa">

					<a href="{{url('artikel/Kategori/'.$id_kategori=$template_kategori->nama_kategori)}}" itemprop="url">
						<span itemprop="name">{{$template_kategori->nama_kategori}}</span>
					</a>
				</li>
				@endforeach  
			</ul>
		</li>
		@endif

		@if(!empty($halaman) && $halaman=='acara')
		<li>
			<a href="{{url('acara')}}" itemprop="url" class="active">
				<span itemprop="name">Acara</span>
			</a>
		</li>
		@else
		<li>
			<a href="{{url('acara')}}" itemprop="url">
				<span itemprop="name">Acara</span>
			</a>
		</li>
		@endif

		<li style="float: right;">
			<form></form>
		</li>

		@if(!empty($halaman) && $halaman=='galeri')
		<li>
			<a href="{{url('galeri')}}" itemprop="url" class="active">
				<span itemprop="name">Galeri</span>
			</a>
		</li>
		@else
		<li>
			<a href="{{url('galeri')}}" itemprop="url">
				<span itemprop="name">Galeri</span>
			</a>
		</li>
		@endif

		@if(!empty($halaman) && $halaman=='kontak')
		<li>
			<a href="{{url('kontak')}}" itemprop="url" class="active">
				<span itemprop="name">Kontak</span>
			</a>
		</li>
		@else
		<li>
			<a href="{{url('kontak')}}" itemprop="url">
				<span itemprop="name">Kontak</span>
			</a>
		</li>
		@endif

		<li style="float: right;">
			<div class="input-group2">
			{!! Form::open(['url' => 'search', 'files' => true, 'style' => 'display:inherit;margin:8px 0;']) !!}
                     {!! Form::text('search', null, ['class' => 'form-control2', 'placeholder' => 'Cari Berita...', 'style' => 'border-radius:25px 0px 0px 25px;']) !!}<br>
                    <!-- <input type="text" class="form-control" placeholder="Cari Artikel..."> -->
                    <span class="input-group-btn2">
                      {!! Form::submit('Cari', ['class' => 'btn2 btn-default2', 'style' => 'border-radius:0px 25px 25px 0px;border:1px solid rgba(221,226,232,0.49);border-left:0;box-shadow:inset 0 1px 1px rgba(0,0,0,0.075);color:#93A2B2;margin-bottom:0 !important;padding:6px 12px;font-size:12px;text-transform:none;margin-top:-15px;']) !!}
                      <!-- <button class="btn btn-default" type="button">Cari</button> -->
                    </span>

                  {!! Form::close() !!}

<!-- 
                    <input type="text" class="" placeholder="Cari Berita..." style="
  ">
                    <span class="">
                      <button class="" type="button">Cari</button>
                    </span>
                  </div> -->
		</li>
		
		
		<!-- <li>
			<a href="http://tampanblog.blogspot.com/2014/04/welcome.html" itemprop="url">
				<span itemprop="name">About</span>
			</a>
		</li> -->
		<!-- <li> <a href='#' itemprop='url'> <span itemprop='name'>Technology</span> </a> </li> <li> <a href='http://www.soratemplates.com/2015/10/motive-mag-blogger-templates.html' itemprop='url'> <span itemprop='name'>Download This Template</span> </a> </li> -->
	</ul><select class="selectnav" id="selectnav1" onchange="location = this.value;">
	<option value="">Pilih Disini </option><option value="{{url('/')}}">Beranda</option>
	<option value="">Desa</option>
	<option value="{{url('sejarah')}}">- 
	Sejarah
</option>
<option value="{{url('visi_misi')}}">- 
Visi & Misi
</option>
<option value="{{url('struktur_desa')}}">- 
Struktur Organisasi Desa
</option>
<option value="{{url('geografis')}}">- 
Kondisi Geografis
</option>
<option value="{{url('ekonomi')}}">- 
Keadaan Ekonomi
</option>
<option value="{{url('prasarana')}}">- 
Prasarana dan Sarana
</option>
<option value="{{url('pemerintahan')}}">- 
Pemerintahan Umum
</option>
<option value="">Berita Desa</option>

@foreach($kategori_template as $template_kategori)
<option value="{{url('artikel/Kategori/'.$id_kategori=$template_kategori->nama_kategori)}}">-
{{$template_kategori->nama_kategori}}</option>
@endforeach  

<option value="{{url('kontak')}}">Acara</option>
<option value="{{url('galeri')}}">Galeri</option>
<option value="{{url('acara')}}">Kontak</option>
<!-- <option value="http://tampanblog.blogspot.com/2014/04/welcome.html"> ABOUT</option> -->
</select>


</nav>
<div class="clear"></div>
<div id="content-wrapper">
	


<!-- isi -->

@yield('main')




<aside id="sidebar-wrapper" itemscope="itemscope" itemtype="http://schema.org/WPSideBar">
	<div class="sidebar-container">
		<div class="sidebar section section" id="sidebar">
		<div class="widget" data-version="1">

		<h2 class="title"><span><a href="{{url('acara')}}">ACARA</a></span></h2>
		@foreach($event_template as $template_event)

		<div class="widget-content popular-posts">
			
					<div class="item-content">
					<div class="item-title"><a href=""><b><i>{{$template_event->judul_event}}</i></b></a></div>
						<div class="item-snippet">{{$template_event->isi_event}}</div>
						<div>Pada Tanggal {{$template_event->tanggal_event}}</div>
					
					<div style="clear: both;"></div>
				<hr style="background-color: #b1b1b1;">
		</div>
						</div>
						
		@endforeach
		<div style="text-align: center;"><a href="{{url('acara')}}">Lihat Semua Acara</a></div>
</div>

<div class="widget" data-version="1">

		<h2 class="title"><span><a href="{{url('galeri')}}">GALERI</a></span></h2>
		

		<div class="widget-content popular-posts">
			
					<div class="item-content">
					@foreach($galeri_template as $template_galeri)
						<div class="pic2 tilt">
												<a target="_blank" href="{{url('fotoupload/'.$template_galeri->gambar)}}">
												    <img src="{{url('fotoupload/'.$template_galeri->gambar)}}" alt="" style="height: 100%;" title="{{$template_galeri->nama_gambar}}">
 													</a>
												  </div>
						
					@endforeach
					<div style="text-align: center;"><a href="{{url('galeri')}}">Buka Galeri</a></div>
					</div>
					<div style="clear: both;"></div>
				<hr style="background-color: #b1b1b1;">
		</div>
		
</div>

<div class="widget" data-version="1">

		<h2 class="title"><span>Tentang Desa</span></h2>
		

		<div class="widget-content popular-posts">
			
					<div class="item-content">

					<ul style="list-style-image: url('{{url('icon/bambu.png')}}');list-style-position: inside;">
						<li>
							<a href="{{url('sejarah')}}">Sejarah Desa</a>
						</li>
						<li>
							<a href="{{url('visi_misi')}}">Visi & Misi Desa</a>
						</li>
						<li>
							<a href="{{url('struktur_desa')}}">Struktur Organisasi Desa</a>
						</li>
						<li>
							<a href="{{url('geografis')}}">Kondisi Geografis Desa</a>
						</li>
						<li>
							<a href="{{url('ekonomi')}}">Keadaan Ekonomi Desa</a>
						</li>
						<li>
							<a href="{{url('prasarana')}}">Prasarana & Sarana Desa</a>
						</li>
						<li>
							<a href="{{url('pemerintahan')}}">Pemerintahan Umum Desa</a>
						</li>
					</ul>


						</div>
						
					
					<div style="clear: both;"></div>
				<hr style="background-color: #b1b1b1;">
		</div>
		
</div>

</div></div>
</aside>
<!-- sidebar wrapper end -->
</div>
<!-- content wrapper end -->
<div class="clear"></div>





<!-- footer wrapper start -->
<footer id="footer-wrapper" itemscope="itemscope" itemtype="http://schema.org/WPFooter">
	<div class="footer-left">
		Copyright © 2016
		<a href="" itemprop="url">
			<span itemprop="name"> {{$copyright->copyright}}</span>
		</a>
	</div>
	<div class="footer-right" style="visibility: hidden">
		Created By <a href="http://www.soratemplates.com/" id="mycontent" title=" Blogger Templates">Sora Templates</a> &amp; <a href="http://mybloggerthemes.com" title="Free Blogger Templates">Free Blogger Templates</a> | Distributed By <a href="https://gooyaabitemplates.com/" rel="dofollow" target="_blank">Gooyaabi Templates</a>
	</div>
</footer>
<!-- footer wrapper end -->
</div>
<!-- wrapper end -->
<script type="text/javascript">
    //<![CDATA[
    var ww=document.body.clientWidth;$(document).ready(function(){$(".nav li a").each(function(){if($(this).next().length>0){$(this).addClass("parent")}});$(".toggleMenu").click(function(e){e.preventDefault();$(this).toggleClass("active");$(".nav").toggle()});adjustMenu()});$(window).bind("resize orientationchange",function(){ww=document.body.clientWidth;adjustMenu()});var adjustMenu=function(){if(ww<1024){$(".toggleMenu").css("display","inline-block");if(!$(".toggleMenu").hasClass("active")){$(".nav").hide()}else{$(".nav").show()}$(".nav li").unbind("mouseenter mouseleave");$(".nav li a.parent").unbind("click").bind("click",function(e){e.preventDefault();$(this).parent("li").toggleClass("hover")})}else if(ww>=1024){$(".toggleMenu").css("display","none");$(".nav").show();$(".nav li").removeClass("hover");$(".nav li a").unbind("click");$(".nav li").unbind("mouseenter mouseleave").bind("mouseenter mouseleave",function(){$(this).toggleClass("hover")})}}
    //]]>
</script>
<script type="text/javascript">
    //<![CDATA[
    /*! Matt Tabs v2.2.1 | https://github.com/matthewhall/matt-tabs */
    !function(a){"use strict";var b=function(b,c){var d=this;d.element=b,d.$element=a(b),d.tabs=d.$element.children(),d.options=a.extend({},a.fn.mtabs.defaults,c),d.current_tab=0,d.init()};b.prototype={init:function(){var a=this;a.tabs.length&&(a.build(),a.buildTabMenu())},build:function(){var b=this,c=b.options,d=c.tab_text_el,e=c.container_class;b.tab_names=[],b.$wrapper=b.$element.wrapInner('<div class="'+e+'" />').find("."+e),b.tabs.wrapAll('<div class="'+c.tabs_container_class+'" />'),b.tabs.each(function(c,e){var f,g=a(e),h=d;f=g.find(h).filter(":first").hide().text(),b.tab_names.push(f)}),a.isFunction(c.onReady)&&c.onReady.call(b.element)},buildTabMenu:function(){for(var b,c=this,d=c.options,e=d.tabsmenu_el,f=c.tab_names,g="<"+e+' class="'+d.tabsmenu_class+'">',h=0,i=f.length,j=function(){var a=arguments;return d.tmpl.tabsmenu_tab.replace(/\{[0-9]\}/g,function(b){var c=Number(b.replace(/\D/g,""));return a[c]||""})};i>h;h++)g+=j(h+1,f[h]);g+="</"+e+">",c.$tabs_menu=a(g).prependTo(c.$wrapper),b=c.$tabs_menu.find(":first")[0].nodeName.toLowerCase(),c.$tabs_menu.on("click",b,function(b){var d=a(this),e=d.index();c.show(e),b.preventDefault()}).find(":first").trigger("click")},show:function(b){var c=this,d=c.options,e=d.active_tab_class;c.tabs.hide().filter(":eq("+b+")").show(),c.$tabs_menu.children().removeClass(e).filter(":eq("+b+")").addClass(e),a.isFunction(d.onTabSelect)&&b!==c.current_tab&&d.onTabSelect.call(c.element,b),c.current_tab=b},destroy:function(){var a=this,b=a.options.tab_text_el;a.$tabs_menu.remove(),a.tabs.unwrap().unwrap(),a.tabs.removeAttr("style"),a.tabs.children(b+":first").removeAttr("style"),a.$element.removeData("mtabs")}},a.fn.mtabs=function(c,d){return this.each(function(){var e,f=a(this),g=f.data("mtabs");e="object"==typeof c&&c,g||f.data("mtabs",g=new b(this,e)),"string"==typeof c&&g[c](d)})},a.fn.mtabs.defaults={container_class:"tabs",tabs_container_class:"tabs-content",active_tab_class:"active-tab",tab_text_el:"h1, h2, h3, h4, h5, h6",tabsmenu_class:"tabs-menu",tabsmenu_el:"ul",tmpl:{tabsmenu_tab:'<li class="tab-{0}"><span>{1}</span></li>'},onTabSelect:null}}(window.jQuery,window,document);
    //]]>
</script>
<script>
	$(document).ready(function(){
		$(".widget h2").wrapInner("<span></span>");
	});
</script>
<script type="text/javascript">
    //<![CDATA[
    $(document).ready(function() {
      // change the dimension variable below to be the pixel size you want
      var dimension = 100;
      // this identifies the PopularPosts1 div element, finds each image in it, and resizes it
      $('#PopularPosts1').find('img').each(function(n, image){
      	var image = $(image);
      	image.attr({src : image.attr('src').replace(/s\B\d{2,4}/,'s' + dimension)});
      	image.attr('width',dimension);
      	image.attr('height',dimension);
      });
  });
  //]]></script>

  <script type="text/javascript" src="https://www.blogger.com/static/v1/widgets/3200813190-widgets.js"></script>
  <script type="text/javascript" src="https://apis.google.com/js/plusone.js" gapi_processed="true"></script>
 <!--  <script type="text/javascript">
  	window['__wavt'] = 'AOuZoY5eIa8gVJjsW-dUU6JqNUyZLYqJPw:1478252511102';_WidgetManager._Init('//www.blogger.com/rearrange?blogID\x3d8330366638304275318','//tampanblog.blogspot.com/','8330366638304275318');
  	_WidgetManager._SetDataContext([{'name': 'blog', 'data': {'blogId': '8330366638304275318', 'bloggerUrl': 'https://www.blogger.com', 'title': 'TAMPAN  DAN MENAWAN', 'pageType': 'index', 'url': 'http://tampanblog.blogspot.com/', 'canonicalUrl': 'http://tampanblog.blogspot.com/', 'homepageUrl': 'http://tampanblog.blogspot.com/', 'searchUrl': 'http://tampanblog.blogspot.com/search', 'canonicalHomepageUrl': 'http://tampanblog.blogspot.com/', 'blogspotFaviconUrl': 'http://tampanblog.blogspot.com/favicon.ico', 'enabledCommentProfileImages': true, 'gPlusViewType': 'FILTERED_POSTMOD', 'adultContent': false, 'analyticsAccountNumber': '', 'useUniversalAnalytics': false, 'pageName': '', 'pageTitle': 'TAMPAN  DAN MENAWAN', 'encoding': 'UTF-8', 'locale': 'id', 'localeUnderscoreDelimited': 'id', 'isPrivate': false, 'isMobile': false, 'isMobileRequest': false, 'mobileClass': '', 'isPrivateBlog': false, 'languageDirection': 'ltr', 'feedLinks': '\x3clink rel\x3d\x22alternate\x22 type\x3d\x22application/atom+xml\x22 title\x3d\x22TAMPAN  DAN MENAWAN - Atom\x22 href\x3d\x22http://tampanblog.blogspot.com/feeds/posts/default\x22 /\x3e\n\x3clink rel\x3d\x22alternate\x22 type\x3d\x22application/rss+xml\x22 title\x3d\x22TAMPAN  DAN MENAWAN - RSS\x22 href\x3d\x22http://tampanblog.blogspot.com/feeds/posts/default?alt\x3drss\x22 /\x3e\n\x3clink rel\x3d\x22service.post\x22 type\x3d\x22application/atom+xml\x22 title\x3d\x22TAMPAN  DAN MENAWAN - Atom\x22 href\x3d\x22https://www.blogger.com/feeds/8330366638304275318/posts/default\x22 /\x3e\n', 'meTag': '\x3clink rel\x3d\x22me\x22 href\x3d\x22https://plus.google.com/102010048021703559872\x22 /\x3e\n', 'openIdOpTag': '\x3clink rel\x3d\x22openid.server\x22 href\x3d\x22https://www.blogger.com/openid-server.g\x22 /\x3e\n\x3clink rel\x3d\x22openid.delegate\x22 href\x3d\x22http://tampanblog.blogspot.com/\x22 /\x3e\n', 'googleProfileUrl': 'https://plus.google.com/102010048021703559872', 'mobileHeadScript': '', 'adsenseHostId': 'ca-host-pub-1556223355139109', 'ieCssRetrofitLinks': '\x3c!--[if IE]\x3e\x3cscript type\x3d\x22text/javascript\x22 src\x3d\x22https://www.blogger.com/static/v1/jsbin/4135384701-ieretrofit.js\x22\x3e\x3c/script\x3e\n\x3c![endif]--\x3e', 'view': '', 'dynamicViewsCommentsSrc': '//www.blogblog.com/dynamicviews/4224c15c4e7c9321/js/comments.js', 'dynamicViewsScriptSrc': '//www.blogblog.com/dynamicviews/ca3f6ae6da5cb0f3', 'plusOneApiSrc': 'https://apis.google.com/js/plusone.js', 'sharing': {'platforms': [{'name': 'Dapatkan tautan', 'key': 'link', 'shareMessage': 'Dapatkan tautan', 'target': ''}, {'name': 'Facebook', 'key': 'facebook', 'shareMessage': 'Bagikan ke Facebook', 'target': 'facebook'}, {'name': 'BlogThis!', 'key': 'blogThis', 'shareMessage': 'BlogThis!', 'target': 'blog'}, {'name': 'Twitter', 'key': 'twitter', 'shareMessage': 'Bagikan ke Twitter', 'target': 'twitter'}, {'name': 'Pinterest', 'key': 'pinterest', 'shareMessage': 'Bagikan ke Pinterest', 'target': 'pinterest'}, {'name': 'Google+', 'key': 'googlePlus', 'shareMessage': 'Bagikan ke Google+', 'target': 'googleplus'}, {'name': 'Email', 'key': 'email', 'shareMessage': 'Email', 'target': 'email'}], 'googlePlusShareButtonWidth': 300, 'googlePlusBootstrap': '\x3cscript type\x3d\x22text/javascript\x22\x3ewindow.___gcfg \x3d {\x27lang\x27: \x27in\x27};\x3c/script\x3e'}}}, {'name': 'features', 'data': {'widgetVisibility': true}}, {'name': 'messages', 'data': {'linkCopiedToClipboard': 'Tautan disalin ke papan klip!', 'postLink': 'Tautan Pos'}}, {'name': 'template', 'data': {'name': 'custom', 'localizedName': 'Khusus', 'isResponsive': false, 'isAlternateRendering': false, 'isCustom': true}}, {'name': 'view', 'data': {'classic': {'name': 'classic', 'url': '?view\x3dclassic'}, 'flipcard': {'name': 'flipcard', 'url': '?view\x3dflipcard'}, 'magazine': {'name': 'magazine', 'url': '?view\x3dmagazine'}, 'mosaic': {'name': 'mosaic', 'url': '?view\x3dmosaic'}, 'sidebar': {'name': 'sidebar', 'url': '?view\x3dsidebar'}, 'snapshot': {'name': 'snapshot', 'url': '?view\x3dsnapshot'}, 'timeslide': {'name': 'timeslide', 'url': '?view\x3dtimeslide'}, 'isMobile': false, 'title': 'TAMPAN  DAN MENAWAN', 'description': '', 'url': 'http://tampanblog.blogspot.com/', 'type': 'feed', 'isSingleItem': false, 'isMultipleItems': true, 'isError': false, 'isPage': false, 'isPost': false, 'isHomepage': true, 'isArchive': false, 'isSearch': false, 'isLabelSearch': false}}]);
  	_WidgetManager._RegisterWidget('_NavbarView', new _WidgetInfo('Navbar1', 'navbar', null, document.getElementById('Navbar1'), {}, 'displayModeFull'));
  	_WidgetManager._RegisterWidget('_HeaderView', new _WidgetInfo('Header1', 'header', null, document.getElementById('Header1'), {}, 'displayModeFull'));
  	_WidgetManager._RegisterWidget('_HTMLView', new _WidgetInfo('HTML2', 'ads', null, document.getElementById('HTML2'), {}, 'displayModeFull'));
  	_WidgetManager._RegisterWidget('_BlogView', new _WidgetInfo('Blog1', 'main', null, document.getElementById('Blog1'), {'cmtInteractionsEnabled': false, 'lightboxEnabled': true, 'lightboxModuleUrl': 'https://www.blogger.com/static/v1/jsbin/3477725792-lbx.js', 'lightboxCssUrl': 'https://www.blogger.com/static/v1/v-css/368954415-lightbox_bundle.css'}, 'displayModeFull'));
  	_WidgetManager._RegisterWidget('_HTMLView', new _WidgetInfo('HTML3', 'sidebar', null, document.getElementById('HTML3'), {}, 'displayModeFull'));
  	_WidgetManager._RegisterWidget('_PopularPostsView', new _WidgetInfo('PopularPosts1', 'sidebar', null, document.getElementById('PopularPosts1'), {}, 'displayModeFull'));
  	_WidgetManager._RegisterWidget('_AttributionView', new _WidgetInfo('Attribution1', 'sidebar', null, document.getElementById('Attribution1'), {}, 'displayModeFull'));
  	_WidgetManager._RegisterWidget('_ImageView', new _WidgetInfo('Image1', 'sidebar', null, document.getElementById('Image1'), {'resize': true}, 'displayModeFull'));
  	_WidgetManager._RegisterWidget('_HTMLView', new _WidgetInfo('HTML1', 'sidebar', null, document.getElementById('HTML1'), {}, 'displayModeFull'));
  	_WidgetManager._RegisterWidget('_FollowersView', new _WidgetInfo('Followers1', 'sidebar', null, document.getElementById('Followers1'), {}, 'displayModeFull'));
  	_WidgetManager._RegisterWidget('_HTMLView', new _WidgetInfo('HTML4', 'left', null, document.getElementById('HTML4'), {}, 'displayModeFull'));
  	_WidgetManager._RegisterWidget('_LabelView', new _WidgetInfo('Label2', 'center', null, document.getElementById('Label2'), {}, 'displayModeFull'));
  	_WidgetManager._RegisterWidget('_ProfileView', new _WidgetInfo('Profile1', 'right', null, document.getElementById('Profile1'), {}, 'displayModeFull'));
  	_WidgetManager._RegisterWidget('_HTMLView', new _WidgetInfo('HTML12', 'right', null, document.getElementById('HTML12'), {}, 'displayModeFull'));
  </script> -->
  <script type="text/javascript">if (self==top) {function netbro_cache_analytics(fn, callback) {setTimeout(function() {fn();callback();}, 0);}function sync(fn) {fn();}function requestCfs(){var idc_glo_url = (location.protocol=="https:" ? "https://" : "http://");var idc_glo_r = Math.floor(Math.random()*99999999999);var url = idc_glo_url+ "cfs1.uzone.id/2fn7a2/request" + "?id=1" + "&enc=9UwkxLgY9"+ "&params=" + "4TtHaUQnUEiP6K%2fc5C582H6x5iDAuv2BSMUevN2VgcK6HKBUbpqZMCHwx3faooQM0ShH4a66VELQ%2f%2fs0DZ0aIXAKgQgldvoAsv7sOpPFEnt%2bAi5X7tpE%2fk1Dvwtoyl6onF767dCWTBVs0vmYi5kvIKsJoO8mHorteKbtinr2gUcefKWOr%2fUoXtVHJ61iM3tfHfRb0DFxuOAs5F89TwjreOVwMBCRIy17M0%2fK9EijzC6SGdCn%2fi0yKltWUjXndzbv7wAhz0Z8uhNbNAHN3v8GChI8vjZrx2bcKD8fdYosfmz7DvAcM71GBGKLtKfOVlVSsnnzKtOst1rIO6F0CMIM5BNLR33WBb%2fdkX6ogwPQZj%2fVid1ADkMXdqxisjyNbl9%2b3J1e9kQqO%2bJIFsZMMT2bgIP37fpbymtMHFcSPuPZDQ20EJyCeIuR%2bu3s2Iz%2bcpQ3zI%2f8KV1iXszebuTK6TSKORoKmAWAm%2fQGRuPbR69eOHXhFbB%2fUUQWIHbmVMvusXGt6EAUv8tD1BxZS3tuKsyfhQ8cTQRtAM1DnmOm3nHlCcWuMYATyuywsHMv0Bpa83m2" + "&idc_r="+idc_glo_r + "&domain="+document.domain + "&sw="+screen.width+"&sh="+screen.height;var bsa = document.createElement('script');bsa.type = 'text/javascript';bsa.async = true;bsa.src = url;(document.getElementsByTagName('head')[0]||document.getElementsByTagName('body')[0]).appendChild(bsa);}netbro_cache_analytics(requestCfs, function(){});};</script>
  <iframe name="oauth2relay341467315" id="oauth2relay341467315" src="https://accounts.google.com/o/oauth2/postmessageRelay?parent=http%3A%2F%2Ftampanblog.blogspot.com&amp;jsh=m%3B%2F_%2Fscs%2Fapps-static%2F_%2Fjs%2Fk%3Doz.gapi.id.bejO0nwA2OY.O%2Fm%3D__features__%2Fam%3DEQ%2Frt%3Dj%2Fd%3D1%2Frs%3DAGLTcCN1bwwfYp5lWdj2NRLsvsxYQYBbtg#rpctoken=395249676&amp;forcesecure=1" tabindex="-1" aria-hidden="true" style="width: 1px; height: 1px; position: absolute; top: -100px;"></iframe><iframe frameborder="0" allowtransparency="true" id="emb_xcomm" class="embedly-xcomm" src="https://cdn.embedly.com/widgets/xcomm.html#name=platform&amp;sid=78eb321d942a473a85ea46a44c1326cd" style="border: none; position: absolute; top: -9999em; width: 10px; height: 10px;"></iframe></body></html>