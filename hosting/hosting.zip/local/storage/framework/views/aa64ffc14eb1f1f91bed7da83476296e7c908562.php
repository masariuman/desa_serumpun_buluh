<?php echo csrf_field(); ?>

<?php if(isset($kategori)): ?>
	<?php echo Form::hidden('id',$kategori->id); ?>

<?php endif; ?>

<!-- foto -->
<?php echo Form::label('foto', 'Foto :', ['class' => 'control-label']); ?>

<?php echo Form::file('foto'); ?>

<?php if($errors->has('foto')): ?>
  <span><i><b><font color="red"><?php echo e($errors->first('foto')); ?></font></b></i></span><br>
<?php endif; ?>
<br><br>


<!-- nama -->
<?php echo Form::label('nama', 'Nama :', ['class' => 'control-label']); ?>

<?php echo Form::text('nama', null, ['class' => 'form-control']); ?>

<?php if($errors->has('nama')): ?>
  <span><i><b><font color="red"><?php echo e($errors->first('nama')); ?></font></b></i></span><br>
<?php endif; ?>
<br>

<!-- jabatan -->
<?php echo Form::label('jabatan', 'Jabatan :', ['class' => 'control-label']); ?>

<?php echo Form::text('jabatan', null, ['class' => 'form-control']); ?>

<?php if($errors->has('jabatan')): ?>
  <span><i><b><font color="red"><?php echo e($errors->first('jabatan')); ?></font></b></i></span><br>
<?php endif; ?>
<br>

<br>
<?php echo Form::submit($submitButtonText, ['class' => 'btn btn-primary form-control']); ?>

