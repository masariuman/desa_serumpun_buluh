<?php $__env->startSection('main'); ?>
	
	<div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Category Baru</h3>
              </div>

              
            </div>
            
            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12">
                <div class="x_panel">
                  
                  <div>
                  <?php echo Form::open(['url' => 'admin/artikel/kategori']); ?>

                      <?php echo $__env->make('admin.artikel.form_category', ['submitButtonText' => 'Tambah Kategori'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                  <?php echo Form::close(); ?>

                    
                  </div>
                  
                </div>
              </div>
            </div>
          </div>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>