<?php echo csrf_field(); ?>

<?php if(isset($kategori)): ?>
	<?php echo Form::hidden('id',$kategori->id); ?>

<?php endif; ?>
<!-- judul	 -->
<?php echo Form::label('judul_artikel', 'Judul :', ['class' => 'control-label']); ?>

<?php echo Form::text('judul_artikel', null, ['class' => 'form-control']); ?>

<?php if($errors->has('judul_artikel')): ?>
  <span><i><b><font color="red"><?php echo e($errors->first('judul_artikel')); ?></font></b></i></span><br>
<?php endif; ?>
<br>
<!-- kategori -->
<?php echo Form::label('id_kategori', 'Kategori :', ['class' => 'control-label']); ?> 
<?php if(count($list_kategori)>0): ?>
	<?php echo Form::select('id_kategori', $list_kategori, null, ['class' => 'control-label', 'id' => 'id_kategori', 'placeholder' => 'Pilih Kategori']); ?>

<?php else: ?>
	<p>Kategori tidak ada. Silahkan buat kategori terlebih dahulu di menu kategori.</p>
<?php endif; ?>
<?php if($errors->has('judul_artikel')): ?>
  <span><i><b><font color="red"><?php echo e($errors->first('id_kategori')); ?></font></b></i></span><br>
<?php endif; ?>
<br>
<!-- isi -->
<?php echo Form::label('isi', 'Isi Artikel :', ['class' => 'control-label']); ?>

<?php echo Form::textarea('isi', null, ['class' => 'form-control']); ?>

<?php if($errors->has('judul_artikel')): ?>
  <span><i><b><font color="red"><?php echo e($errors->first('isi')); ?></font></b></i></span><br>
<?php endif; ?>
<br>
<!-- gambar -->
<?php echo Form::label('gambar', 'Gambar :', ['class' => 'control-label']); ?>

<?php echo Form::file('gambar'); ?>

<?php if($errors->has('judul_artikel')): ?>
  <span><i><b><font color="red"><?php echo e($errors->first('gambar')); ?></font></b></i></span><br>
<?php endif; ?>
<br>

<!-- nama gambar -->
<?php echo Form::label('nama_gambar', 'Nama Gambar :', ['class' => 'control-label']); ?>

<?php echo Form::text('nama_gambar', null, ['class' => 'form-control']); ?>

<?php if($errors->has('judul_artikel')): ?>
  <span><i><b><font color="red"><?php echo e($errors->first('nama_gambar')); ?></font></b></i></span><br>
<?php endif; ?>
<br>

<br>
<?php echo Form::submit($submitButtonText, ['class' => 'btn btn-primary form-control']); ?>



<!-- tinymce -->
<script src="<?php echo e(URL::to('js/tinymce/js/tinymce/tinymce.min.js')); ?>"></script>
<script>
  var editor_config = {
    path_absolute : "<?php echo e(URL::to('/')); ?>/",
    selector: 'textarea',
    plugins: [
      "advlist autolink lists link image charmap print preview hr anchor pagebreak table",
      "searcheplace wordcount visualblocks visualchars code fullscreen",
      "insertdatetime media nonbreaking save table contextmenu directionality",
      "emoticons template paste textcolor colorpicker textpattern"
    ],
    toolbar: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | table link image media",
    relative_urls: false,
    file_browser_callback : function(field_name, url, type, win) {
      var x = window.innerWidth || document.documentElement.clienWidth || document.getElementsByTagName('body')[0].clientWidth;
      var y = window.innerHeight|| document.documentElement.clienHeight|| document.getElementsByTagName('body')[0].clientHeight;

      var cmsURL = editor_config.path_absolute + 'laravel-filemanager?field_name=' + field_name;
      if (type == 'image') {
        cmsURL = cmsURL + "&type=Images";
      }
      else {
        cmsURL = cmsURL + "&type=files";
      }

      tinymce.activeEditor.windowManager.open({
        file : cmsURL,
        title : 'Filemanager',
        width : x * 0.8,
        height : y * 0.8,
        resizable : "yes",
        close_previous : "no"
      });
    }

  };
  tinymce.init(editor_config);
</script>