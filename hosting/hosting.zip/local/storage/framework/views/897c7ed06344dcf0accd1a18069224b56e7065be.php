<?php $__env->startSection('main'); ?>
	
	<div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Ubah Data RW</h3>
              </div>

              
            </div>
            
            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12">
                <div class="x_panel">
                  
                  <div>
                  <?php echo Form::model($kategori, ['method' => 'PATCH', 'action' => ['DesaController@update_rw', $kategori->id], 'files' => true]); ?>

                     <?php echo csrf_field(); ?>

<?php if(isset($kategori)): ?>
  <?php echo Form::hidden('id',$kategori->id); ?>

<?php endif; ?>

<?php if(count($list_rw)>0): ?>
  <?php echo Form::select('id_dusun', $list_rw, null, ['class' => 'control-label', 'id' => 'id_rw', 'placeholder' => 'Pilih Dusun']); ?>

<?php else: ?>
  <p>Dusun tidak ada. Silahkan buat Dusun terlebih dahulu.</p>
<?php endif; ?>
<?php if($errors->has('id_dusun')): ?>
  <span><i><b><font color="red"><?php echo e($errors->first('id_dusun')); ?></font></b></i></span><br>
<?php endif; ?>
<br><br>
<!-- nama -->
<?php echo Form::label('nama_rw', 'Nama RW :', ['class' => 'control-label']); ?>

<?php echo Form::text('nama_rw', null, ['class' => 'form-control']); ?>

<?php if($errors->has('nama_rw')): ?>
  <span><i><b><font color="red"><?php echo e($errors->first('nama_rw')); ?></font></b></i></span><br>
<?php endif; ?>
<br>

<!-- jabatan -->
<?php echo Form::label('nama_kepala', 'Nama Kepala RW :', ['class' => 'control-label']); ?>

<?php echo Form::text('nama_kepala', null, ['class' => 'form-control']); ?>

<?php if($errors->has('nama_kepala')): ?>
  <span><i><b><font color="red"><?php echo e($errors->first('nama_kepala')); ?></font></b></i></span><br>
<?php endif; ?>
<br>

<br>
<?php echo Form::submit('Ubah Data RW', ['class' => 'btn btn-primary form-control']); ?>

                  <?php echo Form::close(); ?>

                    
                  </div>
                  
                </div>
              </div>
            </div>
          </div>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>