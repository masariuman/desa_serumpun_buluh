<?php $__env->startSection('main'); ?>
	
	<div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Pengaturan</h3>
              </div>

              
            </div>
            
            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12">
                <div class="x_panel">
                  <div class="x_title">
                  <?php foreach($desa as $kategori): ?>
                    <a href="<?php echo e(url('admin/pengaturan/'.$kategori->id.'/edit')); ?>">
                      <button type="button" class="btn btn-primary"><i class="fa fa-pencil">  Ubah Pengaturan</i></button>
                    </a>
                  <?php endforeach; ?>
                    
                    <ul class="nav navbar-right panel_toolbox">
                      
                      <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"></a>
                        
                      </li>
                      <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"></a>
                        
                      </li>
                      <li><a class="close-link"></a>
                      </li>
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                   <?php echo $__env->make('_partial.flash_message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <!-- start project list -->
                    <table class="table table-striped projects">
                      <tbody>
                      <?php $x=1; ?>
                      <!-- tampilkan data kategori an  -->
                      <?php foreach($desa as $kategori): ?>
                        <tr>
                          <td>1.</td>
                          <td>
                            <a>Judul Web</a>
                          </td>
                          <td >
                            :
                          </td>
                          <td>
                            <?php echo e($kategori->judul_web); ?>

                          </td>
                        </tr>
                        <tr>
                          <td>2.</td>
                          <td>
                            <a>Nama Desa</a>
                          </td>
                          <td >
                            :
                          </td>
                          <td>
                            <?php echo e($kategori->nama_desa); ?>

                          </td>
                        </tr>
                        <tr>
                          <td>3.</td>
                          <td>
                            <a>Copyright</a>
                          </td>
                          <td >
                            :
                          </td>
                          <td>
                            <?php echo e($kategori->copyright); ?>

                          </td>
                        </tr>
                        

                      <?php endforeach; ?>
                        <!-- <tr>
                          <td>1.</td>
                          <td>
                            <a>Nama Desa</a>
                          </td>
                          <td >
                            :
                          </td>
                          <td>
                            Serumpun Buluh << dari DB
                          </td>
                          <td> -->
                            <!-- <a href="#" class="btn btn-primary btn-xs"><i class="fa fa-eye"></i> Lihat </a> -->
                            <!-- <a href="#" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i> Ubah </a> -->
                            <!-- <a href="#" class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i> Hapus </a> -->
                          <!-- </td>
                        </tr>
                        <tr>
                          <td>2.</td>
                          <td>
                            <a>Copyright</a>
                          </td>
                          <td >
                            :
                          </td>
                          <td>
                            Copyright &copy; 2016 Arif Setiawan.
                          </td>
                          <td> -->
                            <!-- <a href="#" class="btn btn-primary btn-xs"><i class="fa fa-eye"></i> Lihat </a> -->
                            <!-- <a href="#" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i> Ubah </a> -->
                            <!-- <a href="#" class="btn btn-danger btn-xs"><i class="fa fa-trash-o"></i> Hapus </a> -->
                          <!-- </td> -->
                        <!-- </tr> -->
                        
                      </tbody>
                    </table>
                    
                    <hr>


                    <!-- start project list -->
                    <table class="table table-striped projects">
                      <tbody>
                      <?php $x=1; ?>
                      <!-- tampilkan data kategori an  -->
                      <?php foreach($login as $kategorii): ?>
                        <tr>
                          <td>1.</td>
                          <td>
                            <a>User</a>
                          </td>
                          <td >
                            :
                          </td>
                          <td>
                            <?php echo e($kategorii->name); ?>

                          </td>
                        </tr>
                        <tr>
                          <td>2.</td>
                          <td>
                            <a>Email</a>
                          </td>
                          <td >
                            :
                          </td>
                          <td>
                            <?php echo e($kategorii->email); ?>

                          </td>
                        </tr>
                        <tr>
                          <td>3.</td>
                          <td>
                            <a>Password</a>
                          </td>
                          <td >
                            :
                          </td>
                          <td>
                            ************
                          </td>
                        </tr>


                      <?php endforeach; ?>
                       
                      </tbody>
                    </table>

                     <?php foreach($login as $kategori1): ?>
                    <a href="<?php echo e(url('admin/pengaturan_login/'.$kategori1->id.'/edit')); ?>">
                      <button type="button" class="btn btn-primary"><i class="fa fa-pencil">  Ubah Pengaturan Masuk</i></button>
                    </a>
                  <?php endforeach; ?>

                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>