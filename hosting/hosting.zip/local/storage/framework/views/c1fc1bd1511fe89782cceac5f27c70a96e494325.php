<?php $__env->startSection('main'); ?>
	
	<div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Ubah Keadaan Ekonomi Desa</h3>
              </div>

              
            </div>
            
            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12">
                <div class="x_panel">
                  
                  <div>
                  <?php echo Form::model($kategori, ['method' => 'PATCH', 'action' => ['DesaController@update_ekonomi', $kategori->id]]); ?>

                      <?php echo csrf_field(); ?>

                      <?php if(isset($kategori)): ?>
  <?php echo Form::hidden('id',$kategori->id); ?>

<?php endif; ?>
<!-- isi -->
<?php echo Form::label('ekonomi', 'Isi Keadaan Ekonomi Desa :', ['class' => 'control-label']); ?>

<?php echo Form::textarea('ekonomi', null, ['class' => 'form-control']); ?>

<?php if($errors->has('ekonomi')): ?>
  <span><i><b><font color="red"><?php echo e($errors->first('ekonomi')); ?></font></b></i></span><br>
<?php endif; ?>

<!-- tinymce -->
<script src="<?php echo e(URL::to('js/tinymce/js/tinymce/tinymce.min.js')); ?>"></script>
<script>
  var editor_config = {
    path_absolute : "<?php echo e(URL::to('/')); ?>/",
    selector: 'textarea',
    plugins: [
      "advlist autolink lists link image charmap print preview hr anchor pagebreak table",
      "searcheplace wordcount visualblocks visualchars code fullscreen",
      "insertdatetime media nonbreaking save table contextmenu directionality",
      "emoticons template paste textcolor colorpicker textpattern"
    ],
    toolbar: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | table link image media",
    relative_urls: false,
    file_browser_callback : function(field_name, url, type, win) {
      var x = window.innerWidth || document.documentElement.clienWidth || document.getElementsByTagName('body')[0].clientWidth;
      var y = window.innerHeight|| document.documentElement.clienHeight|| document.getElementsByTagName('body')[0].clientHeight;

      var cmsURL = editor_config.path_absolute + 'laravel-filemanager?field_name=' + field_name;
      if (type == 'image') {
        cmsURL = cmsURL + "&type=Images";
      }
      else {
        cmsURL = cmsURL + "&type=files";
      }

      tinymce.activeEditor.windowManager.open({
        file : cmsURL,
        title : 'Filemanager',
        width : x * 0.8,
        height : y * 0.8,
        resizable : "yes",
        close_previous : "no"
      });
    }

  };
  tinymce.init(editor_config);
</script>
<br>
<div class="form-group">
  <?php echo Form::submit('Ubah Keadaan Ekonomi Desa', ['class' => 'btn btn-primary form-control']); ?>

</div>
                  <?php echo Form::close(); ?>

                    
                  </div>
                  
                </div>
              </div>
            </div>
          </div>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>