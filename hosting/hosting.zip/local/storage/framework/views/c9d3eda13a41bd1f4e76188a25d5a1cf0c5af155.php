<?php $__env->startSection('main'); ?>
	
	<div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Ubah Data Pengaturan</h3>
              </div>

              
            </div>
            
            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12">
                <div class="x_panel">
                  
                  <div>
                  <?php echo Form::model($kategori, ['method' => 'PATCH', 'action' => ['DesaController@update_pengaturan', $kategori->id], 'files' => true]); ?>

                     <?php echo csrf_field(); ?>

<?php if(isset($kategori)): ?>
  <?php echo Form::hidden('id',$kategori->id); ?>

<?php endif; ?>

<br><br>
<!-- nama -->
<?php echo Form::label('judul_web', 'Judul Web :', ['class' => 'control-label']); ?>

<?php echo Form::text('judul_web', null, ['class' => 'form-control']); ?>

<?php if($errors->has('judul_web')): ?>
  <span><i><b><font color="red"><?php echo e($errors->first('judul_web')); ?></font></b></i></span><br>
<?php endif; ?>
<br>

<!-- jabatan -->
<?php echo Form::label('nama_desa', 'Nama Desa :', ['class' => 'control-label']); ?>

<?php echo Form::text('nama_desa', null, ['class' => 'form-control']); ?>

<?php if($errors->has('nama_desa')): ?>
  <span><i><b><font color="red"><?php echo e($errors->first('nama_desa')); ?></font></b></i></span><br>
<?php endif; ?>
<br>

<!-- jabatan -->
<?php echo Form::label('copyright', 'Copyright :', ['class' => 'control-label']); ?>

<?php echo Form::text('copyright', null, ['class' => 'form-control']); ?>

<?php if($errors->has('copyright')): ?>
  <span><i><b><font color="red"><?php echo e($errors->first('copyright')); ?></font></b></i></span><br>
<?php endif; ?>
<br>

<br>
<?php echo Form::submit('Ubah Data Pengaturan', ['class' => 'btn btn-primary form-control']); ?>

                  <?php echo Form::close(); ?>

                    
                  </div>
                  
                </div>
              </div>
            </div>
          </div>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>