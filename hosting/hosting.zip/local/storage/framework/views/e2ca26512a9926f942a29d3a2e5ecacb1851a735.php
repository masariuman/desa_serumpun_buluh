<?php $__env->startSection('main'); ?>
	
	<div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Ubah Kontak</h3>
              </div>

              
            </div>
            
            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12">
                <div class="x_panel">
                  
                  <div>
                  <?php echo Form::model($kategori, ['method' => 'PATCH', 'action' => ['KontakController@update', $kategori->id],'files' => true ]); ?>

<?php if(isset($kategori)): ?>
  <?php echo Form::hidden('id',$kategori->id); ?>

<?php endif; ?>

<?php echo Form::label('gambar', 'Foto/Gambar Kantor Desa :', ['class' => 'control-label']); ?>

<?php echo Form::file('gambar'); ?>

<?php if($errors->has('gambar')): ?>
  <span><i><b><font color="red"><?php echo e($errors->first('gambar')); ?></font></b></i></span><br>
<?php endif; ?>
<br><br>

<?php echo Form::label('nama', 'Nama :', ['class' => 'control-label']); ?>

<?php echo Form::text('nama', null, ['class' => 'form-control']); ?>

<?php if($errors->has('nama')): ?>
  <span><i><b><font color="red"><?php echo e($errors->first('nama')); ?></font></b></i></span><br>
<?php endif; ?>
<br>

<?php echo Form::label('alamat', 'Alamat :', ['class' => 'control-label']); ?>

<?php echo Form::text('alamat', null, ['class' => 'form-control']); ?>

<?php if($errors->has('alamat')): ?>
  <span><i><b><font color="red"><?php echo e($errors->first('alamat')); ?></font></b></i></span><br>
<?php endif; ?>
<br>

<?php echo Form::label('telepon', 'Telepon :', ['class' => 'control-label']); ?>

<?php echo Form::text('telepon', null, ['class' => 'form-control']); ?>

<?php if($errors->has('telepon')): ?>
  <span><i><b><font color="red"><?php echo e($errors->first('telepon')); ?></font></b></i></span><br>
<?php endif; ?>
<br>

<?php echo Form::label('email', 'Email :', ['class' => 'control-label']); ?>

<?php echo Form::text('email', null, ['class' => 'form-control']); ?>

<?php if($errors->has('email')): ?>
  <span><i><b><font color="red"><?php echo e($errors->first('email')); ?></font></b></i></span><br>
<?php endif; ?>
<br>

<br>
<div class="form-group">
  <?php echo Form::submit('Ubah Kontak', ['class' => 'btn btn-primary form-control']); ?>

</div>
                  <?php echo Form::close(); ?>

                    
                  </div>
                  
                </div>
              </div>
            </div>
          </div>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>