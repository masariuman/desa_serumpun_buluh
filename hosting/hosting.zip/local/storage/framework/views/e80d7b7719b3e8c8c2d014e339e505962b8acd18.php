<?php echo csrf_field(); ?>

<!-- nama	 -->
<div>
	<?php echo Form::label('nama', 'Nama :', ['class' => 'control-label']); ?>

	<?php echo Form::text('nama', null, ['class' => 'form-control']); ?>


<?php if($errors->has('nama')): ?>
  <span><i><b><font color="red"><?php echo e($errors->first('nama')); ?></font></b></i></span><br>
<?php endif; ?>

</div><br>
<div>
	<?php echo Form::label('isi', 'Isi Komentar :', ['class' => 'control-label']); ?>

	<?php echo Form::textarea('isi', null, ['class' => 'form-control']); ?>


<?php if($errors->has('isi')): ?>
  <span><i><b><font color="red"><?php echo e($errors->first('isi')); ?></font></b></i></span><br>
<?php endif; ?>

</div>
<div class="form-group">
	<?php echo Form::submit($submitButtonText, ['class' => 'btn btn-primary form-control']); ?>

</div>
<?php echo Form::hidden('id_artikel',$kategori->id); ?>

<?php echo Form::hidden('status','belum dibaca'); ?>



                  <?php echo Form::close(); ?>


<br><br><br>
<div class="komhead">

	

																			<h4>
																				<?php echo e($jumlah_kategori); ?>

																				komentar
																				:

																			</h4>
																			<div class="stripe-line"></div>
																		</div><br>
<div class="komentarbg">
																		
<?php foreach($komentar as $komentator): ?>			

<div class="x_panel">
                  <div class="x_title">
                    <h2><?php echo e($komentator->nama); ?> <small>berkata :</small></h2>
                    
                  <!-- <div class="x_content"> -->

                    <!-- end pop-over -->

                  <!-- </div> -->

                </div>

<?php echo e($komentator->isi); ?>

                </div>
					<!-- 														
<p><i><b> </b></i></p>
<hr> -->
<?php endforeach; ?>		

</div>


