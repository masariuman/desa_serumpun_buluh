<?php echo csrf_field(); ?>

<!-- nama	 -->
<div>
	<?php echo Form::label('nama_warga', 'Nama :', ['class' => 'control-label']); ?>

	<?php echo Form::text('nama_warga', null, ['class' => 'form-control']); ?>


<?php if($errors->has('nama_warga')): ?>
  <span><i><b><font color="red"><?php echo e($errors->first('nama_warga')); ?></font></b></i></span><br>
<?php endif; ?>

</div><br>
<div>
	<?php echo Form::label('isi', 'Isi Komentar :', ['class' => 'control-label']); ?>

	<?php echo Form::textarea('isi', null, ['class' => 'form-control']); ?>


<?php if($errors->has('isi')): ?>
  <span><i><b><font color="red"><?php echo e($errors->first('isi')); ?></font></b></i></span><br>
<?php endif; ?>

	<?php echo Form::hidden('status','belum dibaca'); ?>

</div>
<div class="form-group">
	<?php echo Form::submit($submitButtonText, ['class' => 'btn btn-primary form-control']); ?>

</div>

<br><br><br>
<br>
<div class="komentarbg">
																		
<?php foreach($kategori_list as $komentator): ?>			

<div class="x_panel">
                  <div class="x_title">
                    <h2><?php echo e($komentator->nama_warga); ?> <small>berkata :</small></h2>
                    
                  <!-- <div class="x_content"> -->

                    <!-- end pop-over -->

                  <!-- </div> -->

                </div>

<?php echo e($komentator->isi); ?>

                </div>
					<!-- 														
<p><i><b> </b></i></p>
<hr> -->
<?php endforeach; ?>		

</div>


