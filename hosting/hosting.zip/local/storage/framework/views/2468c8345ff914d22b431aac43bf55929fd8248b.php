<?php echo csrf_field(); ?>

<!-- nama	 -->
<?php if(isset($kategori)): ?>
	<?php echo Form::hidden('id',$kategori->id); ?>

<?php else: ?>
	<?php echo Form::hidden('status','aktif'); ?>

<?php endif; ?>
<div>
	<?php echo Form::label('judul_event', 'Judul Event :', ['class' => 'control-label']); ?>

	<?php echo Form::text('judul_event', null, ['class' => 'form-control']); ?>


<?php if($errors->has('judul_event')): ?>
  <span><i><b><font color="red"><?php echo e($errors->first('judul_event')); ?></font></b></i></span><br>
<?php endif; ?>

</div><br>
<div>
	<?php echo Form::label('isi_event', 'Isi Event :', ['class' => 'control-label']); ?>

	<?php echo Form::textarea('isi_event', null, ['class' => 'form-control']); ?>


<?php if($errors->has('isi_event')): ?>
  <span><i><b><font color="red"><?php echo e($errors->first('isi_event')); ?></font></b></i></span><br>
<?php endif; ?>

</div><br>
<?php echo Form::label('tanggal_event', 'Tanggal Event :', ['class' => 'control-label']); ?>

	<?php echo Form::date('tanggal_event', null, ['class' => 'form-control', 'id' => 'tanggal_lahir']); ?>


<?php if($errors->has('tanggal_event')): ?>
  <span><i><b><font color="red"><?php echo e($errors->first('tanggal_event')); ?></font></b></i></span><br>
<?php endif; ?>
<br>
<div class="form-group">
	<?php echo Form::submit($submitButtonText, ['class' => 'btn btn-primary form-control']); ?>

</div>
